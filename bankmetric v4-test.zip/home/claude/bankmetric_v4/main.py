"""BankMetric v4 — FastAPI entry point"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

from db.database import get_connection
from parser.llm_parser import parse, check_ollama
from api.resolver import build_and_execute
try:
    from api.graphql_api import graphql_router
except ImportError:
    graphql_router = None

app = FastAPI(title="BankMetric v4", version="4.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])
if graphql_router:
    app.include_router(graphql_router, prefix="/graphql")


class AskRequest(BaseModel):
    question:           str
    conversation_context: list[dict] = []
    previous_summary:   dict         = {}


class AskResponse(BaseModel):
    success:          bool
    intent:           str             = "data"
    question:         str             = ""
    # Data fields
    metric:           Optional[str]   = None
    display_name:     Optional[str]   = None
    time_range:       Optional[str]   = None
    date_from:        Optional[str]   = None
    date_to:          Optional[str]   = None
    group_by:         list[str]       = []
    results:          list[dict]      = []
    total:            Optional[float] = None
    formatted_total:  Optional[str]   = None
    row_count:        int             = 0
    sql_generated:    Optional[str]   = None
    empty_note:       str             = ""
    # UI command fields
    ui_action:        Optional[str]   = None
    ui_message:       Optional[str]   = None
    # Clarification fields
    clarify_question: Optional[str]   = None
    clarify_options:  list[dict]      = []
    # Error / unclear fields
    error:            Optional[str]   = None
    suggestion:       Optional[str]   = None
    # Meta
    query_object:     dict            = {}
    parser_used:      str             = "llm"
    confidence:       float           = 1.0


@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    q = parse(req.question, req.conversation_context, req.previous_summary or None)

    base = AskResponse(
        success      = False,
        intent       = q.intent,
        question     = req.question,
        parser_used  = q.parser,
        confidence   = q.confidence,
        query_object = {
            "metric":     q.metric,
            "time_range": q.time_range,
            "group_by":   q.group_by,
            "filters":    q.filters,
            "confidence": q.confidence,
        },
    )

    # UI command — return immediately, no resolver needed
    if q.intent == "ui_command":
        base.success    = True
        base.ui_action  = q.ui_action
        return base

    # Clarification needed
    if q.intent == "clarify":
        base.success          = True
        base.clarify_question = q.clarify_question
        base.clarify_options  = [
            {"label": o.label, "metric": o.metric,
             "time_range": o.time_range, "group_by": o.group_by,
             "filters": o.filters}
            for o in q.clarify_options
        ]
        return base

    # Unclear / error
    if q.intent == "unclear":
        base.error      = q.unclear_message
        base.suggestion = "Try: 'revenue by region last quarter' or 'top 5 customers by revenue'"
        return base

    # Data query
    result = build_and_execute(q)
    if not result.success:
        base.error      = result.error.message if result.error else "Query failed"
        base.suggestion = result.error.suggestion if result.error else ""
        return base

    r = result.response
    base.success         = True
    base.metric          = r.metric_name
    base.display_name    = r.display_name
    base.time_range      = r.time_range
    base.date_from       = r.date_from
    base.date_to         = r.date_to
    base.group_by        = r.group_by
    base.results         = [{"dimension": row.dimension, "value": row.value,
                              "formatted_value": row.formatted_value}
                             for row in r.results]
    base.total           = r.total
    base.formatted_total = r.formatted_total
    base.row_count       = r.row_count
    base.sql_generated   = r.sql_generated
    base.empty_note      = r.empty_note
    return base


@app.get("/ollama/status")
def ollama_status(): return check_ollama()


@app.get("/metrics")
def list_metrics():
    conn = get_connection()
    rows = conn.execute(
        "SELECT metric_name, display_name, description, formula, "
        "source_table, allowed_dims, owner FROM metric_registry "
        "WHERE status='published' ORDER BY metric_name"
    ).fetchall()
    return [dict(r) for r in rows]


@app.get("/health")
def health():
    conn = get_connection()
    return {
        "status":   "healthy",
        "database": "in-memory SQLite",
        "counts": {
            "transactions": conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0],
            "customers":    conn.execute("SELECT COUNT(*) FROM customers").fetchone()[0],
            "loans":        conn.execute("SELECT COUNT(*) FROM loans").fetchone()[0],
            "metrics":      conn.execute("SELECT COUNT(*) FROM metric_registry").fetchone()[0],
        },
        "ollama": check_ollama(),
    }


if __name__ == "__main__":
    import uvicorn
    print("\n🚀 BankMetric v4")
    print("   API:     http://localhost:8000")
    print("   Docs:    http://localhost:8000/docs")
    ollama = check_ollama()
    if ollama.get("running") and ollama.get("model_available"):
        print(f"✅ Ollama ready — {ollama['target_model']}")
    elif ollama.get("running"):
        print(f"⚠️  Ollama running but model not pulled")
        print(f"   Run: ollama pull {ollama.get('target_model')}")
    else:
        print("❌ Ollama not running — start with: ollama serve")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
