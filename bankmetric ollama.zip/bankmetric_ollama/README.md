# BankMetric — Ollama LLM Version
## Local Mac Setup for Visual Studio Code

```
User types question (any phrasing)
        ↓
Streamlit UI
        ↓  POST /ask
FastAPI (main.py)
        ↓
LLM Parser → Ollama (localhost:11434)
             llama3.2:3b model
             returns structured JSON
        ↓
GraphQL API (Strawberry)
        ↓
Metric Resolver + dynamic SQL
        ↓
In-memory SQLite (5000 txns, 2000 customers, 1000 loans)
        ↓
Results → Streamlit → User
```

---

## Mac Setup (One Time)

### Step 1 — Install Ollama
```bash
brew install ollama
```
Or download from https://ollama.com/download/mac

### Step 2 — Pull the model (~2GB download, once only)
```bash
ollama pull llama3.2:3b
```
This downloads the model to your Mac. After this, no internet needed.

**Alternative smaller/faster models to try:**
```bash
ollama pull phi3:mini        # Microsoft — very fast, great at JSON
ollama pull llama3.2:1b      # Tiny — fastest, slightly less accurate
ollama pull mistral:7b       # Bigger — slower but best quality
```

To switch models, change `OLLAMA_MODEL` in `parser/llm_parser.py`.

### Step 3 — Clone / open project in VS Code
```
Open folder: bankmetric_ollama/
```

### Step 4 — Create virtual environment
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

---

## Running (Every Time)

You need **3 terminals** in VS Code:

### Terminal 1 — Start Ollama
```bash
ollama serve
```
Leave this running. You'll see: `Listening on 127.0.0.1:11434`

### Terminal 2 — Start the API
```bash
source venv/bin/activate
python main.py
```
You'll see startup output including Ollama status.

### Terminal 3 — Start the UI
```bash
source venv/bin/activate
streamlit run streamlit_app/app.py
```
Open http://localhost:8501 in your browser.

---

## What You'll See

The Streamlit UI shows:
- **LLM** badge (green) when Ollama parsed the question
- **Rule-based fallback** badge (amber) when Ollama is offline
- **Confidence score** — how certain the LLM was
- **Query details** expander — shows exactly what the LLM understood

---

## Try These Questions to Test the LLM

These would have broken the old rule-based parser:
```
"Which region performed best last quarter?"
"Show me who our most valuable customers are"
"What's driving our delinquency numbers?"
"Give me a breakdown of income by geography"
"How are our loans performing?"
"Are customers churning more in any particular region?"
"What does our mortgage book look like?"
"Top customers by how much they've spent"
```

---

## Changing the Model

Edit `parser/llm_parser.py`, line 20:
```python
OLLAMA_MODEL = "llama3.2:3b"   # change this
```

Models ranked by speed vs quality on CPU:
| Model | Speed | Quality | RAM |
|-------|-------|---------|-----|
| llama3.2:1b | Very fast (< 1s) | Good | 2 GB |
| phi3:mini | Fast (1-2s) | Very good | 4 GB |
| llama3.2:3b | Medium (2-3s) | Excellent | 4 GB |
| mistral:7b | Slow (5-10s) | Best | 8 GB |

---

## Project Structure

```
bankmetric_ollama/
├── main.py                     # FastAPI entry point
├── requirements.txt
├── README.md
├── db/
│   ├── __init__.py
│   └── database.py             # SQLite in-memory DB (unchanged)
├── parser/
│   ├── __init__.py
│   └── llm_parser.py           # NEW — Ollama LLM parser + rule-based fallback
├── api/
│   ├── __init__.py
│   └── graphql_api.py          # GraphQL schema + resolvers (unchanged)
└── streamlit_app/
    └── app.py                  # Chat UI with LLM status indicators
```

---

## How the LLM Parsing Works

1. User types: *"which region had the highest revenue growth?"*
2. FastAPI sends to Ollama with this prompt:
   ```
   Available metrics: ["total_revenue", "active_customers", ...]
   Available dimensions: region, product, channel, customer
   Question: "which region had the highest revenue growth?"
   Return ONLY valid JSON: {"metric":..., "time_range":..., "group_by":[], "filters":{}}
   ```
3. Ollama returns: `{"metric": "total_revenue", "time_range": "last_30_days", "group_by": ["region"], "filters": {"order": "DESC"}}`
4. FastAPI validates the metric exists, executes via GraphQL resolver
5. SQL Server (SQLite in dev) returns results
6. Streamlit renders table + chart

---

## Roadmap for Production

| Step | Action |
|------|--------|
| Local Mac | This prototype — SQLite, no auth |
| Bank server | Swap SQLite → SQL Server (pyodbc) |
| Auth | Add AD middleware (see Implementation Guide) |
| Teams | Add Bot Framework or Copilot Studio |
| Model | Move Ollama to dedicated server if needed |
