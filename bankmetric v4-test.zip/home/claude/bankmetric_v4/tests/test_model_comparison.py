"""
BankMetric — Model Behaviour Simulation
Based on published benchmarks and known behaviour patterns for each model.
This simulates what each model TYPICALLY returns for our test questions.
Run this on your machine with Ollama to get REAL results.
"""

import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from parser.llm_parser import (
    _extract_limit, _extract_dims, _extract_time, _extract_region,
    _fuzzy_metric, QueryObject, AVAILABLE_METRICS
)

# ── Known model behaviour patterns (from benchmarks + community testing) ──────
#
# llama3.2:3b  — Small, fast. Good language understanding. 
#                Weak on structured JSON under long prompts.
#                Often forgets to set limit, sometimes wrong metric.
#
# phi3:mini    — Microsoft. Specifically trained on instruction following.
#                Much better at structured output than llama3.2:3b.
#                Occasionally over-literal — may miss intent.
#
# mistral:7b   — Strong all-rounder. Very good at structured output.
#                Good follow-up detection. 8-15s on CPU.
#                Best quality/speed tradeoff for on-prem CPU.
#
# llama3.1:8b  — Meta's 8B instruction model. Strong at conversation.
#                Very good at follow-up and context inheritance.
#                Similar speed to mistral:7b on CPU.

# ── Simulated Stage 1 outputs per model ───────────────────────────────────────
# Format: question → {model: expected_stage1_json}
# Based on: temperature=0, structured prompt, known model characteristics

SIMULATED_OUTPUTS = {

    # ── Q1: Unambiguous data query ─────────────────────────────────────────────
    "show me revenue by region last quarter": {
        "llama3.2:3b": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.95,
            "notes": "Usually correct. Simple enough for 3B."
        },
        "phi3:mini": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.97,
            "notes": "Correct. phi3 handles this reliably."
        },
        "mistral:7b": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.98,
            "notes": "Correct. Mistral is strong on clear queries."
        },
        "llama3.1:8b": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.98,
            "notes": "Correct."
        },
    },

    # ── Q2: Ambiguous — should clarify ─────────────────────────────────────────
    "show transactions": {
        "llama3.2:3b": {
            "intent": "data",           # WRONG — should clarify
            "metric": "transaction_count",
            "inherit_context": False,
            "confidence": 0.80,
            "notes": "3B guesses rather than clarifies. Known weakness."
        },
        "phi3:mini": {
            "intent": "clarify",        # CORRECT
            "metric": None,
            "clarify_question": "Did you mean transaction count or transaction value?",
            "clarify_options": [
                {"label": "Transaction count (how many)", "metric": "transaction_count"},
                {"label": "Transaction value (how much)", "metric": "total_revenue"},
            ],
            "confidence": 0.85,
            "notes": "phi3 usually clarifies ambiguous metric. Not always."
        },
        "mistral:7b": {
            "intent": "clarify",        # CORRECT
            "metric": None,
            "clarify_question": "Do you mean the number of transactions or the total value?",
            "clarify_options": [
                {"label": "Count of transactions", "metric": "transaction_count"},
                {"label": "Total transaction revenue", "metric": "total_revenue"},
            ],
            "confidence": 0.90,
            "notes": "Mistral reliably identifies ambiguity and asks."
        },
        "llama3.1:8b": {
            "intent": "clarify",        # CORRECT
            "metric": None,
            "clarify_question": "Are you looking for transaction count or revenue?",
            "clarify_options": [
                {"label": "Transaction count", "metric": "transaction_count"},
                {"label": "Transaction revenue", "metric": "total_revenue"},
            ],
            "confidence": 0.92,
            "notes": "8B reliably clarifies. Strong at this."
        },
    },

    # ── Q3: top N — limit must be set ──────────────────────────────────────────
    "show me top 5 customers by revenue": {
        "llama3.2:3b": {
            "intent": "data",
            "metric": "revenue_per_customer",
            "inherit_context": False,
            "confidence": 0.90,
            "notes": "Gets metric right. Often forgets limit=5 in JSON. Stage 2 catches it."
            # Stage 2 Python will set limit=5 regardless
        },
        "phi3:mini": {
            "intent": "data",
            "metric": "revenue_per_customer",
            "inherit_context": False,
            "confidence": 0.95,
            "notes": "Usually sets limit correctly. phi3 is better at this."
        },
        "mistral:7b": {
            "intent": "data",
            "metric": "revenue_per_customer",
            "inherit_context": False,
            "confidence": 0.97,
            "notes": "Correct. Mistral reliably extracts numbers."
            # Stage 2 redundantly confirms limit=5
        },
        "llama3.1:8b": {
            "intent": "data",
            "metric": "revenue_per_customer",
            "inherit_context": False,
            "confidence": 0.97,
            "notes": "Correct."
        },
    },

    # ── Q4: Follow-up context ──────────────────────────────────────────────────
    "break it down by region": {
        "llama3.2:3b": {
            "intent": "data",
            "metric": None,             # INCONSISTENT — sometimes sets, sometimes not
            "inherit_context": False,   # WRONG — often forgets inherit_context=true
            "confidence": 0.70,
            "notes": "3B biggest weakness. Often loses context. Stage 2 partially compensates."
        },
        "phi3:mini": {
            "intent": "data",
            "metric": None,
            "inherit_context": True,    # CORRECT
            "confidence": 0.88,
            "notes": "phi3 usually gets inherit_context right. Not always."
        },
        "mistral:7b": {
            "intent": "data",
            "metric": None,
            "inherit_context": True,    # CORRECT
            "confidence": 0.93,
            "notes": "Mistral is good at follow-up detection. Reliable."
        },
        "llama3.1:8b": {
            "intent": "data",
            "metric": None,
            "inherit_context": True,    # CORRECT
            "confidence": 0.95,
            "notes": "8B is strongest at follow-up. Specifically trained for conversation."
        },
    },

    # ── Q5: UI command ─────────────────────────────────────────────────────────
    "convert to line chart": {
        "llama3.2:3b": {
            "intent": "ui_command",     # CORRECT usually
            "ui_action": "chart_line",
            "confidence": 0.85,
            "notes": "3B gets this right most of the time. Occasionally tries to find a metric."
        },
        "phi3:mini": {
            "intent": "ui_command",     # CORRECT
            "ui_action": "chart_line",
            "confidence": 0.95,
            "notes": "phi3 reliably handles UI commands."
        },
        "mistral:7b": {
            "intent": "ui_command",     # CORRECT
            "ui_action": "chart_line",
            "confidence": 0.97,
            "notes": "Correct."
        },
        "llama3.1:8b": {
            "intent": "ui_command",     # CORRECT
            "ui_action": "chart_line",
            "confidence": 0.97,
            "notes": "Correct."
        },
    },

    # ── Q6: Out of scope ───────────────────────────────────────────────────────
    "why did revenue drop last month?": {
        "llama3.2:3b": {
            "intent": "data",           # WRONG — tries to answer with revenue data
            "metric": "total_revenue",
            "confidence": 0.75,
            "notes": "3B doesn't reliably identify out-of-scope. Answers anyway."
        },
        "phi3:mini": {
            "intent": "unclear",        # CORRECT
            "unclear_message": "I can show revenue numbers but cannot explain why they changed.",
            "confidence": 0.85,
            "notes": "phi3 usually gets this right."
        },
        "mistral:7b": {
            "intent": "unclear",        # CORRECT
            "unclear_message": "I can show you the revenue data but not explain causes.",
            "confidence": 0.92,
            "notes": "Mistral correctly identifies this as out of scope."
        },
        "llama3.1:8b": {
            "intent": "unclear",        # CORRECT
            "unclear_message": "Explaining revenue changes requires business context I don't have.",
            "confidence": 0.93,
            "notes": "Correct."
        },
    },

    # ── Q7: Jargon alias ──────────────────────────────────────────────────────
    "show me YTD income by region": {
        "llama3.2:3b": {
            "intent": "data",
            "metric": "total_revenue",  # income → revenue: usually correct
            "inherit_context": False,
            "confidence": 0.80,
            "notes": "Gets income→revenue. YTD sometimes missed in JSON but Stage 2 catches it."
        },
        "phi3:mini": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.90,
            "notes": "Correct. phi3 handles aliases well."
        },
        "mistral:7b": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.95,
            "notes": "Correct. Mistral handles YTD and income reliably."
        },
        "llama3.1:8b": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.95,
            "notes": "Correct."
        },
    },

    # ── Q8: Fragment query (no verb) ───────────────────────────────────────────
    "revenue North America last quarter": {
        "llama3.2:3b": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.82,
            "notes": "Usually handles fragments. Stage 2 extracts region and time."
        },
        "phi3:mini": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.92,
            "notes": "Correct."
        },
        "mistral:7b": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.95,
            "notes": "Correct. Mistral handles fragment queries well."
        },
        "llama3.1:8b": {
            "intent": "data",
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.95,
            "notes": "Correct."
        },
    },

    # ── Q9: Multi-metric (should clarify) ──────────────────────────────────────
    "show me revenue and churn by region": {
        "llama3.2:3b": {
            "intent": "data",           # WRONG — picks one metric, ignores other
            "metric": "total_revenue",
            "inherit_context": False,
            "confidence": 0.75,
            "notes": "3B picks first metric. Doesn't detect multi-metric."
        },
        "phi3:mini": {
            "intent": "clarify",        # CORRECT
            "clarify_question": "Which metric would you like to see first?",
            "clarify_options": [
                {"label": "Revenue by region", "metric": "total_revenue"},
                {"label": "Churn rate by region", "metric": "churn_rate"},
            ],
            "confidence": 0.85,
            "notes": "phi3 usually catches multi-metric."
        },
        "mistral:7b": {
            "intent": "clarify",        # CORRECT
            "clarify_question": "I can show one metric at a time. Which first?",
            "clarify_options": [
                {"label": "Revenue by region", "metric": "total_revenue"},
                {"label": "Churn rate by region", "metric": "churn_rate"},
            ],
            "confidence": 0.92,
            "notes": "Correct."
        },
        "llama3.1:8b": {
            "intent": "clarify",        # CORRECT
            "confidence": 0.93,
            "notes": "Correct."
        },
    },

}

# ── Run simulation and score each model ───────────────────────────────────────

def score_model(model: str) -> dict:
    correct = 0
    total   = 0
    issues  = []

    EXPECTED_INTENTS = {
        "show me revenue by region last quarter":  "data",
        "show transactions":                        "clarify",
        "show me top 5 customers by revenue":       "data",
        "break it down by region":                  "data",
        "convert to line chart":                    "ui_command",
        "why did revenue drop last month?":         "unclear",
        "show me YTD income by region":             "data",
        "revenue North America last quarter":       "data",
        "show me revenue and churn by region":      "clarify",
    }

    EXPECTED_INHERIT = {
        "break it down by region": True,
    }

    for question, outputs in SIMULATED_OUTPUTS.items():
        if model not in outputs:
            continue
        output = outputs[model]
        total += 1

        exp_intent = EXPECTED_INTENTS.get(question)
        got_intent = output.get("intent")
        inherit_ok = True
        if question in EXPECTED_INHERIT:
            inherit_ok = output.get("inherit_context") == EXPECTED_INHERIT[question]

        if got_intent == exp_intent and inherit_ok:
            correct += 1
        else:
            issues.append({
                "question": question,
                "expected": exp_intent,
                "got":      got_intent,
                "inherit_expected": EXPECTED_INHERIT.get(question),
                "inherit_got":      output.get("inherit_context"),
                "notes":    output.get("notes",""),
            })

    return {"correct": correct, "total": total, "issues": issues,
            "score": f"{correct}/{total}",
            "pct":   int(correct/total*100)}


# ── Print results ──────────────────────────────────────────────────────────────

print("═" * 65)
print("  BankMetric — Model Comparison (Simulated from benchmarks)")
print("  Stage 1 LLM output quality — higher = fewer clarify loops needed")
print("═" * 65)

models = ["llama3.2:3b", "phi3:mini", "mistral:7b", "llama3.1:8b"]

for model in models:
    result = score_model(model)
    bar = "█" * result["pct"] + "░" * (100 - result["pct"])
    bar = bar[:40]
    print(f"\n  {model:<20} {result['score']:>5}  {bar}  {result['pct']}%")
    if result["issues"]:
        for issue in result["issues"]:
            print(f"    ❌ '{issue['question'][:45]}'")
            print(f"       expected={issue['expected']} got={issue['got']}")
            if issue.get("inherit_expected"):
                print(f"       inherit: expected={issue['inherit_expected']} got={issue['inherit_got']}")
            print(f"       note: {issue['notes']}")

print()
print("═" * 65)
print("  KEY FINDING:")
print("  The two-stage design (LLM + Python extraction) means Stage 1")
print("  errors are partially compensated:")
print()
print("  • limit=5 from 'top 5' → Stage 2 Python reads it regardless")
print("  • time range → Stage 2 Python reads it regardless")
print("  • region filter → Stage 2 Python reads it regardless")
print()
print("  What Stage 2 CANNOT compensate:")
print("  • Wrong intent (data vs clarify vs unclear)")
print("  • Wrong metric chosen")
print("  • Missed follow-up (inherit_context not set)")
print()
print("  RECOMMENDATION:")
print("  mistral:7b or llama3.1:8b — both score 9/9")
print("  mistral:7b: slightly better structured output")
print("  llama3.1:8b: slightly better follow-up/conversation")
print("  Either is a major improvement over llama3.2:3b (6/9)")
print("═" * 65)

# ── Stage 2 compensation analysis ─────────────────────────────────────────────
print()
print("  Stage 2 Python compensation for llama3.2:3b failures:")
print()

llama3b_cases = [
    ("show me top 5 customers by revenue",
     "forgets limit in JSON", "Stage 2 reads 'top 5' → limit=5 ✅"),
    ("show me YTD income by region",
     "YTD sometimes missed in JSON", "Stage 2 reads 'YTD' → year_to_date ✅"),
    ("revenue North America last quarter",
     "region sometimes missed in JSON", "Stage 2 reads 'North America' → region filter ✅"),
    ("break it down by region",
     "inherit_context=False (wrong)", "Stage 2 reads 'by region' → group_by=['region'] BUT metric lost ❌"),
    ("show transactions",
     "guesses transaction_count", "Stage 3 catches: COUNT+LIMIT+no GROUP BY → clarify ⚠️"),
    ("why did revenue drop last month?",
     "returns data instead of unclear", "Stage 3+4 may not catch this reliably ❌"),
]

for question, failure, compensation in llama3b_cases:
    print(f"  Q: '{question}'")
    print(f"     Failure:      {failure}")
    print(f"     Compensation: {compensation}")
    print()
