"""BankMetric v5 — FastAPI"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

from db.database import get_connection
from db.registry import MetricRegistry
from api.resolver import execute
from parser.llm_parser import parse, check_ollama, generate_narrative

app = FastAPI(title="BankMetric v5", version="5.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])


class AskRequest(BaseModel):
    question:         str
    context:          list[dict] = []
    previous_summary: dict       = {}

@app.post("/ask")
def ask(req: AskRequest):
    result = parse(req.question, req.context, req.previous_summary or None)

    if result.intent == "ui_command":
        return {"success":True,"intent":"ui_command","ui_action":result.ui_action}

    if result.intent == "clarify":
        return {"success":True,"intent":"clarify",
                "clarify_question": result.clarify_question,
                "clarify_options": [
                    {"label":o.label,"metric_id":o.metric_id,
                     "time_range":o.time_range,"group_by":o.group_by,
                     "filters":o.filters,"computation":o.computation}
                    for o in result.clarify_options
                ]}

    if result.intent == "unclear":
        return {"success":False,"intent":"unclear",
                "error": result.unclear_message,
                "suggestions": result.unclear_suggestions}

    # data
    qr = execute(result.descriptor)
    if not qr.success:
        return {"success":False,"intent":"data","error":qr.error}

    # Generate narrative
    narrative = ""
    try:
        narrative = generate_narrative(
            req.question, qr.display_name, qr.time_range,
            qr.rows, qr.format_type
        )
    except: pass

    return {
        "success":         True,
        "intent":          "data",
        "metric_id":       qr.metric_id,
        "display_name":    qr.display_name,
        "time_range":      qr.time_range,
        "date_from":       qr.date_from,
        "date_to":         qr.date_to,
        "group_by":        qr.group_by,
        "computation":     qr.computation,
        "rows":            qr.rows,
        "total":           qr.total,
        "formatted_total": qr.formatted_total,
        "row_count":       qr.row_count,
        "sql_preview":     qr.sql_preview,
        "empty_note":      qr.empty_note,
        "format_type":     qr.format_type,
        "narrative":       narrative,
        "stage_used":      result.stage_used,
        "confidence":      result.confidence,
        "feasibility_note": result.feasibility_note,
    }


@app.get("/metrics")
def list_metrics():
    return [m.to_dict() for m in MetricRegistry.get_all()]

@app.get("/metrics/{metric_id}")
def get_metric(metric_id: str):
    spec = MetricRegistry.get(metric_id)
    if not spec: return {"error": "Not found"}, 404
    return spec.to_dict()

@app.put("/metrics/{metric_id}")
def update_metric(metric_id: str, data: dict):
    data["metric_id"] = metric_id
    ok, msg = MetricRegistry.save(data)
    return {"success": ok, "message": msg}

@app.post("/metrics")
def create_metric(data: dict):
    ok, msg = MetricRegistry.save(data)
    return {"success": ok, "message": msg}

@app.delete("/metrics/{metric_id}")
def delete_metric(metric_id: str):
    ok, msg = MetricRegistry.delete(metric_id)
    return {"success": ok, "message": msg}

@app.get("/history")
def query_history(limit: int = 50):
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM query_audit ORDER BY queried_at DESC LIMIT ?", (limit,)
    ).fetchall()
    return [dict(r) for r in rows]

@app.get("/health")
def health():
    conn = get_connection()
    return {
        "status":  "healthy",
        "version": "5.0.0",
        "counts": {
            "metrics":      len(MetricRegistry.get_all()),
            "transactions": conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0],
            "customers":    conn.execute("SELECT COUNT(*) FROM customers").fetchone()[0],
            "loans":        conn.execute("SELECT COUNT(*) FROM loans").fetchone()[0],
        },
        "ollama": check_ollama(),
    }

if __name__ == "__main__":
    import uvicorn
    get_connection()
    print("\n🚀 BankMetric v5")
    print("   API:  http://localhost:8000")
    print("   Docs: http://localhost:8000/docs\n")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
