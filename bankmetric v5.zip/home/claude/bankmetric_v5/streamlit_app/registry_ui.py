"""
BankMetric v5 — Metric Registry UI

The administrative control plane. Every metric definition lives here.
This IS the source of truth the entire system runs from.

Features:
  - Browse all 100 metrics by category
  - View full definition including SQL expression
  - Edit: description, owner, questions, tier, status
  - Edit: alert thresholds, benchmarks, related metrics (agent fields)
  - Add new metrics with full form
  - Publish / draft / deprecate workflow
  - Version history
  - Validate metric (test SQL against live DB)
  - Search across all fields
"""

import streamlit as st
import requests
import json
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

API = "http://localhost:8000"

# ── Colour + badge helpers ─────────────────────────────────────────────────────

CATEGORY_CONFIG = {
    "revenue":    {"icon": "💰", "label": "Revenue & Income",     "color": "#00B4A2"},
    "customers":  {"icon": "👥", "label": "Customers",            "color": "#6366F1"},
    "loans":      {"icon": "🏦", "label": "Loans & Credit",       "color": "#DC2626"},
    "deposits":   {"icon": "🏧", "label": "Deposits & Liquidity", "color": "#059669"},
    "operations": {"icon": "⚙️", "label": "Operations",           "color": "#D97706"},
    "risk":       {"icon": "🛡️", "label": "Risk & Compliance",    "color": "#B91C1C"},
    "digital":    {"icon": "📱", "label": "Digital & Channels",   "color": "#7C3AED"},
    "other":      {"icon": "📊", "label": "Other",                "color": "#6B7280"},
}

TIER_CONFIG = {
    1: {"label": "Tier 1 — Regulatory",    "color": "#DC2626", "bg": "#FEF2F2"},
    2: {"label": "Tier 2 — Financial",     "color": "#D97706", "bg": "#FFFBEB"},
    3: {"label": "Tier 3 — Operational",   "color": "#059669", "bg": "#F0FDF4"},
    4: {"label": "Tier 4 — Experimental",  "color": "#6B7280", "bg": "#F9FAFB"},
}

STATUS_CONFIG = {
    "published":  {"icon": "✅", "color": "#059669"},
    "draft":      {"icon": "🔵", "color": "#2563EB"},
    "deprecated": {"icon": "🔴", "color": "#DC2626"},
    "deleted":    {"icon": "⚫", "color": "#6B7280"},
}

FORMAT_OPTIONS  = ["currency", "percent", "integer", "decimal"]
TIER_OPTIONS    = [1, 2, 3, 4]
STATUS_OPTIONS  = ["published", "draft", "deprecated"]
CATEGORY_OPTIONS= list(CATEGORY_CONFIG.keys())

DIM_HELP = 'JSON: {"region": "t.region", "product": "t.product"}'
JOIN_HELP = 'JSON: {"customer": "JOIN customers c ON c.id=t.customer_id"}'


def api_get(path):
    try:
        return requests.get(f"{API}{path}", timeout=5).json()
    except:
        return None

def api_put(path, data):
    try:
        return requests.put(f"{API}{path}", json=data, timeout=5).json()
    except Exception as e:
        return {"success": False, "message": str(e)}

def api_post(path, data):
    try:
        return requests.post(f"{API}{path}", json=data, timeout=5).json()
    except Exception as e:
        return {"success": False, "message": str(e)}

def api_delete(path):
    try:
        return requests.delete(f"{API}{path}", timeout=5).json()
    except Exception as e:
        return {"success": False, "message": str(e)}

def safe_json_parse(val, default):
    if isinstance(val, (dict, list)):
        return val
    try:
        return json.loads(val) if val else default
    except:
        return default


# ── Main render function ───────────────────────────────────────────────────────

def render_registry():
    """Main entry point — called from app.py tab."""

    st.markdown("## 📐 Metric Registry")
    st.caption(
        "The single source of truth for all metrics. "
        "Every definition here drives the parser, SQL builder, agent, and display layer. "
        "Changes take effect immediately — no restart needed."
    )

    # ── Toolbar ───────────────────────────────────────────────────────────────
    col_search, col_cat, col_tier, col_status, col_add = st.columns([3, 1.5, 1, 1, 1.2])

    with col_search:
        search = st.text_input("🔍 Search", placeholder="Search metrics, descriptions, tags, owners...",
                               label_visibility="collapsed", key="reg_search")
    with col_cat:
        cat_filter = st.selectbox("Category", ["All"] + CATEGORY_OPTIONS,
                                  label_visibility="collapsed", key="reg_cat")
    with col_tier:
        tier_filter = st.selectbox("Tier", ["All"] + [str(t) for t in TIER_OPTIONS],
                                   label_visibility="collapsed", key="reg_tier")
    with col_status:
        status_filter = st.selectbox("Status", ["All"] + STATUS_OPTIONS,
                                     label_visibility="collapsed", key="reg_status")
    with col_add:
        if st.button("➕ New Metric", use_container_width=True, type="primary"):
            st.session_state["reg_show_add"] = True

    st.divider()

    # ── Load metrics ──────────────────────────────────────────────────────────
    metrics = api_get("/metrics")
    if not metrics:
        st.error("Cannot reach API. Make sure `python main.py` is running.")
        return
    if not isinstance(metrics, list):
        st.error("Unexpected response from API.")
        return

    # ── Apply filters ─────────────────────────────────────────────────────────
    filtered = metrics
    if search:
        sl = search.lower()
        filtered = [m for m in filtered if
                    sl in m.get("display_name", "").lower() or
                    sl in m.get("description", "").lower() or
                    sl in m.get("metric_id", "").lower() or
                    sl in " ".join(m.get("tags", [])).lower() or
                    sl in (m.get("business_owner") or "").lower() or
                    sl in (m.get("data_steward") or "").lower() or
                    any(sl in q.lower() for q in m.get("business_questions", []))]

    if cat_filter != "All":
        filtered = [m for m in filtered if m.get("category") == cat_filter]
    if tier_filter != "All":
        filtered = [m for m in filtered if str(m.get("tier", "")) == tier_filter]
    if status_filter != "All":
        filtered = [m for m in filtered if m.get("status") == status_filter]

    # ── Summary stats ─────────────────────────────────────────────────────────
    total = len(metrics)
    published = sum(1 for m in metrics if m.get("status") == "published")
    draft = sum(1 for m in metrics if m.get("status") == "draft")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total metrics",     total)
    c2.metric("Published",         published)
    c3.metric("Draft",             draft)
    c4.metric("Showing",           len(filtered))

    st.divider()

    # ── Add new metric form ───────────────────────────────────────────────────
    if st.session_state.get("reg_show_add"):
        _render_add_form()
        st.divider()

    # ── Metric list grouped by category ──────────────────────────────────────
    if not filtered:
        st.info("No metrics match your search. Try clearing filters.")
        return

    # Group by category
    categories = {}
    for m in filtered:
        cat = m.get("category", "other")
        categories.setdefault(cat, []).append(m)

    for cat, cat_metrics in sorted(categories.items()):
        cfg = CATEGORY_CONFIG.get(cat, CATEGORY_CONFIG["other"])
        st.markdown(
            f"### {cfg['icon']} {cfg['label']} "
            f"<span style='font-size:13px;font-weight:400;color:#6B7280'>{len(cat_metrics)} metrics</span>",
            unsafe_allow_html=True,
        )

        for m in cat_metrics:
            _render_metric_card(m)

        st.markdown("")


# ── Metric card ────────────────────────────────────────────────────────────────

def _render_metric_card(m: dict):
    """Render a single metric as an expandable card."""

    mid     = m.get("metric_id", "")
    tier    = m.get("tier", 3)
    status  = m.get("status", "published")
    t_cfg   = TIER_CONFIG.get(tier, TIER_CONFIG[3])
    s_cfg   = STATUS_CONFIG.get(status, STATUS_CONFIG["published"])
    dims    = m.get("allowed_dimensions", [])
    if isinstance(dims, dict): dims = list(dims.keys())

    # Expander title with badges
    expander_title = (
        f"{s_cfg['icon']}  **{m.get('display_name', mid)}**  "
        f"`{mid}`  ·  "
        f"{t_cfg['label']}  ·  "
        f"{m.get('format_type', '')} ({m.get('unit', '')})"
    )

    with st.expander(expander_title, expanded=False):

        # ── Main content: 3 columns ───────────────────────────────────────────
        col_def, col_meta, col_tech = st.columns([2.5, 1.5, 2])

        with col_def:
            st.markdown("**Definition**")
            st.markdown(m.get("description", ""))
            if m.get("long_description"):
                st.caption(m["long_description"])

            if m.get("business_questions"):
                st.markdown("**Example questions:**")
                for q in m["business_questions"][:4]:
                    st.markdown(f"  *• {q}*")

        with col_meta:
            st.markdown("**Ownership**")
            st.markdown(f"Owner: **{m.get('business_owner', '—')}**")
            st.markdown(f"Steward: **{m.get('data_steward', '—')}**")
            st.markdown(f"Version: **{m.get('version', 1)}**")

            if m.get("tags"):
                tags = m["tags"] if isinstance(m["tags"], list) else safe_json_parse(m["tags"], [])
                st.markdown("**Tags:**")
                st.markdown(" ".join([f"`{t}`" for t in tags]))

        with col_tech:
            st.markdown("**Technical spec**")
            st.markdown(f"Dimensions: `{'`, `'.join(dims) if dims else 'none'}`")
            if m.get("default_limit"):
                st.markdown(f"Default limit: `{m['default_limit']}`")

            # Alert / agent fields
            if m.get("alert_threshold") is not None:
                direction = m.get("alert_direction", "above")
                st.markdown(
                    f"⚠️ Alert: {direction} `{m['alert_threshold']}`"
                    + (f" (benchmark: `{m['benchmark_value']}`)" if m.get("benchmark_value") else "")
                )
            if m.get("related_metrics"):
                related = safe_json_parse(m["related_metrics"], [])
                if related:
                    st.markdown(f"🔗 Related: `{'`, `'.join(related)}`")
            if m.get("is_agent_enabled"):
                st.markdown("🤖 **Agent-enabled**")

        # ── Action buttons ────────────────────────────────────────────────────
        st.markdown("")
        b1, b2, b3, b4, b5 = st.columns([2, 1.2, 1.2, 1.2, 1.2])

        with b1:
            if st.button(f"💬 Ask about this metric",
                         key=f"ask_{mid}", use_container_width=True):
                # Switch to chat tab with this metric pre-loaded
                st.session_state["reg_prefill"] = f"show me {m.get('display_name','').lower()} last quarter"
                st.session_state["active_tab"] = "chat"
                st.rerun()

        with b2:
            if st.button("✏️ Edit definition", key=f"edit_{mid}", use_container_width=True):
                st.session_state[f"editing_{mid}"] = "definition"
                st.rerun()

        with b3:
            if st.button("⚙️ Edit tech spec", key=f"tech_{mid}", use_container_width=True):
                st.session_state[f"editing_{mid}"] = "technical"
                st.rerun()

        with b4:
            # Quick status toggle
            if status == "published":
                if st.button("📥 Set draft", key=f"draft_{mid}", use_container_width=True):
                    _update_metric(mid, {"status": "draft"})
                    st.rerun()
            elif status == "draft":
                if st.button("✅ Publish", key=f"pub_{mid}", use_container_width=True,
                             type="primary"):
                    _update_metric(mid, {"status": "published"})
                    st.rerun()

        with b5:
            if st.button("🗑 Delete", key=f"del_{mid}", use_container_width=True):
                st.session_state[f"confirm_del_{mid}"] = True

        # Delete confirmation
        if st.session_state.get(f"confirm_del_{mid}"):
            st.warning(f"Are you sure you want to delete **{m.get('display_name')}**? This cannot be undone.")
            dc1, dc2 = st.columns(2)
            with dc1:
                if st.button("Yes, delete", key=f"del_confirm_{mid}", type="primary"):
                    r = api_delete(f"/metrics/{mid}")
                    if r and r.get("success"):
                        st.success("Deleted")
                        del st.session_state[f"confirm_del_{mid}"]
                        st.rerun()
                    else:
                        st.error(r.get("message", "Failed") if r else "API error")
            with dc2:
                if st.button("Cancel", key=f"del_cancel_{mid}"):
                    del st.session_state[f"confirm_del_{mid}"]
                    st.rerun()

        # ── Edit form: Definition tab ─────────────────────────────────────────
        if st.session_state.get(f"editing_{mid}") == "definition":
            st.divider()
            st.markdown("#### ✏️ Edit Definition")
            _render_edit_definition_form(m)

        # ── Edit form: Technical spec ─────────────────────────────────────────
        elif st.session_state.get(f"editing_{mid}") == "technical":
            st.divider()
            st.markdown("#### ⚙️ Edit Technical Spec")
            _render_edit_technical_form(m)


# ── Edit forms ─────────────────────────────────────────────────────────────────

def _render_edit_definition_form(m: dict):
    """Edit business definition fields — for data stewards."""
    mid = m.get("metric_id", "")

    with st.form(f"form_def_{mid}"):
        st.caption("These fields define what the metric means. They drive the LLM vocabulary and user-facing display.")

        col1, col2 = st.columns(2)
        with col1:
            display_name  = st.text_input("Display name *",
                                          value=m.get("display_name", ""))
            description   = st.text_area("Short description *",
                                         value=m.get("description", ""),
                                         help="One sentence. Shown to users and used by the LLM to identify this metric.")
            long_desc     = st.text_area("Long description",
                                         value=m.get("long_description", "") or "",
                                         help="Full business definition. Shown in the registry and used for training data generation.")
        with col2:
            owner         = st.text_input("Business owner", value=m.get("business_owner", "") or "")
            steward       = st.text_input("Data steward",   value=m.get("data_steward", "") or "")
            category      = st.selectbox("Category", CATEGORY_OPTIONS,
                                         index=CATEGORY_OPTIONS.index(m.get("category", "other"))
                                         if m.get("category") in CATEGORY_OPTIONS else 0)
            tier          = st.selectbox("Tier", TIER_OPTIONS,
                                         index=TIER_OPTIONS.index(m.get("tier", 3))
                                         if m.get("tier") in TIER_OPTIONS else 2,
                                         help="1=Regulatory  2=Financial  3=Operational  4=Experimental")
            status        = st.selectbox("Status", STATUS_OPTIONS,
                                         index=STATUS_OPTIONS.index(m.get("status", "published"))
                                         if m.get("status") in STATUS_OPTIONS else 0)

        bq_default = "\n".join(m.get("business_questions", []))
        bq = st.text_area("Example questions (one per line) *",
                           value=bq_default,
                           height=120,
                           help="These are used by the LLM to match user questions to this metric. More = more accurate.")

        tags_default = ", ".join(
            m["tags"] if isinstance(m.get("tags"), list)
            else safe_json_parse(m.get("tags", "[]"), [])
        )
        tags_input = st.text_input("Tags (comma-separated)",
                                   value=tags_default,
                                   help="Keywords for search and training data categorisation.")

        # Agent fields
        st.markdown("**Agent & Alert fields** *(for agentic investigation — optional)*")
        a1, a2, a3 = st.columns(3)
        with a1:
            alert_threshold = st.number_input("Alert threshold",
                                              value=float(m.get("alert_threshold") or 0),
                                              help="Value that triggers agent investigation. 0 = no alert.")
            alert_direction = st.selectbox("Alert direction",
                                           ["above", "below", "change"],
                                           index=["above","below","change"].index(
                                               m.get("alert_direction","above")))
        with a2:
            benchmark_value = st.number_input("Benchmark value",
                                              value=float(m.get("benchmark_value") or 0),
                                              help="Industry benchmark for comparison in display.")
            benchmark_source = st.text_input("Benchmark source",
                                             value=m.get("benchmark_source") or "",
                                             help="e.g. 'Banking Association 2025 Report'")
        with a3:
            is_agent = st.checkbox("Enable for agent",
                                   value=bool(m.get("is_agent_enabled")),
                                   help="Allow the investigative agent to query this metric automatically.")
            display_template = st.text_input("Display template",
                                             value=m.get("display_template") or "",
                                             help='e.g. "{metric} was {value} for {period}" — overrides default display.')

        related_default = ", ".join(
            safe_json_parse(m.get("related_metrics", "[]"), [])
        )
        related_input = st.text_input("Related metrics (comma-separated metric IDs)",
                                      value=related_default,
                                      help="Metrics the agent investigates next if this metric triggers an alert.")

        inv_path_default = "\n".join(
            safe_json_parse(m.get("investigation_path", "[]"), [])
        )
        inv_path = st.text_area("Investigation path (one step per line)",
                                value=inv_path_default,
                                height=80,
                                help='Steps the agent follows when alert triggered. e.g. "group_by=region" then "group_by=product"')

        col_save, col_cancel, col_validate = st.columns([1, 1, 1])
        with col_save:
            save = st.form_submit_button("💾 Save definition", type="primary")
        with col_cancel:
            cancel = st.form_submit_button("Cancel")
        with col_validate:
            validate = st.form_submit_button("🔍 Validate SQL")

        if cancel:
            if f"editing_{mid}" in st.session_state:
                del st.session_state[f"editing_{mid}"]
            st.rerun()

        if save or validate:
            tags_list    = [t.strip() for t in tags_input.split(",") if t.strip()]
            related_list = [r.strip() for r in related_input.split(",") if r.strip()]
            inv_list     = [s.strip() for s in inv_path.split("\n") if s.strip()]
            bq_list      = [q.strip() for q in bq.split("\n") if q.strip()]

            update = {
                "display_name":       display_name,
                "description":        description,
                "long_description":   long_desc,
                "business_owner":     owner,
                "data_steward":       steward,
                "category":           category,
                "tier":               tier,
                "status":             status,
                "business_questions": bq_list,
                "tags":               tags_list,
                "alert_threshold":    alert_threshold if alert_threshold > 0 else None,
                "alert_direction":    alert_direction,
                "benchmark_value":    benchmark_value if benchmark_value > 0 else None,
                "benchmark_source":   benchmark_source or None,
                "is_agent_enabled":   1 if is_agent else 0,
                "display_template":   display_template or None,
                "related_metrics":    related_list,
                "investigation_path": inv_list,
            }

            if validate:
                # Test the current SQL against live DB
                r = api_post(f"/metrics/{mid}/validate", {})
                if r and r.get("success"):
                    st.success(f"✅ SQL valid — {r.get('row_count', '?')} rows returned")
                else:
                    st.error(f"❌ SQL error: {r.get('error','unknown') if r else 'API error'}")
            else:
                r = api_put(f"/metrics/{mid}", update)
                if r and r.get("success"):
                    st.success("✅ Saved — version incremented")
                    if f"editing_{mid}" in st.session_state:
                        del st.session_state[f"editing_{mid}"]
                    st.rerun()
                else:
                    st.error(f"❌ {r.get('message','Save failed') if r else 'API error'}")


def _render_edit_technical_form(m: dict):
    """Edit technical/SQL fields — for data engineers."""
    mid = m.get("metric_id", "")

    with st.form(f"form_tech_{mid}"):
        st.caption(
            "⚠️ These fields define HOW the metric is computed. "
            "Changes affect all live queries immediately. "
            "Test with Validate SQL before saving to production."
        )

        col1, col2 = st.columns(2)
        with col1:
            select_expr = st.text_area("Select expression *",
                                       value=m.get("select_expression", ""),
                                       height=80,
                                       help="The SQL aggregate. e.g. ROUND(SUM(t.amount),2) — never shown to LLM")
            primary_table = st.text_input("Source table *",
                                          value=m.get("primary_table", ""),
                                          help="Table the metric queries. e.g. transactions")
            primary_alias = st.text_input("Table alias *",
                                          value=m.get("primary_alias", ""),
                                          help="Short alias. e.g. t")
            date_column   = st.text_input("Date column *",
                                          value=m.get("date_column", ""),
                                          help="e.g. t.transaction_date — used for all time filters")

        with col2:
            base_filter   = st.text_input("Base filter",
                                          value=m.get("base_filter", "1=1"),
                                          help="Always applied. e.g. t.status='completed'")
            format_type   = st.selectbox("Format type", FORMAT_OPTIONS,
                                         index=FORMAT_OPTIONS.index(m.get("format_type","number"))
                                         if m.get("format_type") in FORMAT_OPTIONS else 0)
            unit          = st.text_input("Unit", value=m.get("unit", "") or "",
                                          help="e.g. USD, %, count, days")
            default_limit = st.number_input("Default limit (0 = none)",
                                            value=int(m.get("default_limit") or 0),
                                            min_value=0)
            default_sort  = st.selectbox("Default sort", ["DESC", "ASC"],
                                         index=0 if m.get("default_sort","DESC")=="DESC" else 1)

        # Allowed dimensions
        dims_val = m.get("allowed_dimensions", {})
        if not isinstance(dims_val, str):
            dims_val = json.dumps(dims_val, indent=2)
        dims = st.text_area("Allowed dimensions (JSON) *",
                             value=dims_val,
                             height=100,
                             help=DIM_HELP)

        djoin_val = m.get("dimension_joins", {})
        if not isinstance(djoin_val, str):
            djoin_val = json.dumps(djoin_val, indent=2)
        dim_joins = st.text_area("Dimension joins (JSON)",
                                 value=djoin_val,
                                 height=80,
                                 help=JOIN_HELP)

        base_joins_val = m.get("base_joins", [])
        if not isinstance(base_joins_val, str):
            base_joins_val = json.dumps(base_joins_val, indent=2)
        base_joins = st.text_area("Base joins (JSON array)",
                                  value=base_joins_val,
                                  height=60,
                                  help='[{"alias":"c","sql":"JOIN customers c ON c.id=t.customer_id"}]')

        fg_val = m.get("force_group_by", [])
        if not isinstance(fg_val, str):
            fg_val = json.dumps(fg_val)
        force_gb = st.text_input("Force group by (JSON array)",
                                 value=fg_val,
                                 help='["customer"] — always group by this dimension even if user doesn\'t specify')

        is_ratio = st.checkbox("Is a ratio metric",
                               value=bool(m.get("is_ratio")),
                               help="Tick if select_expression is already a ratio/percentage (affects total calculation)")

        col_save, col_cancel, col_validate = st.columns([1, 1, 1])
        with col_save:
            save = st.form_submit_button("💾 Save technical spec", type="primary")
        with col_cancel:
            cancel = st.form_submit_button("Cancel")
        with col_validate:
            validate_btn = st.form_submit_button("🔍 Validate SQL")

        if cancel:
            if f"editing_{mid}" in st.session_state:
                del st.session_state[f"editing_{mid}"]
            st.rerun()

        if save or validate_btn:
            try:
                dims_dict     = json.loads(dims) if isinstance(dims, str) else dims
                djoin_dict    = json.loads(dim_joins) if isinstance(dim_joins, str) else dim_joins
                base_join_list= json.loads(base_joins) if isinstance(base_joins, str) else base_joins
                force_gb_list = json.loads(force_gb) if isinstance(force_gb, str) else force_gb
            except json.JSONDecodeError as e:
                st.error(f"❌ JSON error: {e}")
                return

            update = {
                "select_expression":  select_expr,
                "primary_table":      primary_table,
                "primary_alias":      primary_alias,
                "date_column":        date_column,
                "base_filter":        base_filter,
                "format_type":        format_type,
                "unit":               unit,
                "default_limit":      default_limit if default_limit > 0 else None,
                "default_sort":       default_sort,
                "allowed_dimensions": dims_dict,
                "dimension_joins":    djoin_dict,
                "base_joins":         base_join_list,
                "force_group_by":     force_gb_list,
                "is_ratio":           1 if is_ratio else 0,
            }

            if validate_btn:
                r = api_post(f"/metrics/{mid}/validate", update)
                if r and r.get("success"):
                    st.success(f"✅ SQL valid — {r.get('row_count','?')} rows for last 30 days")
                else:
                    st.error(f"❌ {r.get('error','unknown') if r else 'API error'}")
            else:
                r = api_put(f"/metrics/{mid}", update)
                if r and r.get("success"):
                    st.success("✅ Saved — version incremented")
                    if f"editing_{mid}" in st.session_state:
                        del st.session_state[f"editing_{mid}"]
                    st.rerun()
                else:
                    st.error(f"❌ {r.get('message','Save failed') if r else 'API error'}")


# ── Add new metric form ────────────────────────────────────────────────────────

def _render_add_form():
    """Full form to add a brand new metric."""

    st.markdown("### ➕ Add New Metric")
    st.caption(
        "New metrics start as **draft**. Test them in the Chat tab before publishing. "
        "Publishing makes the metric immediately available to all users and the agent."
    )

    with st.form("add_metric_form"):
        st.markdown("**Identity**")
        row1a, row1b, row1c = st.columns([2, 2, 1])
        with row1a:
            new_id      = st.text_input("Metric ID *",
                                        placeholder="net_interest_margin",
                                        help="Unique identifier. lowercase_with_underscores. Cannot be changed after creation.")
            new_display = st.text_input("Display name *",
                                        placeholder="Net Interest Margin")
        with row1b:
            new_cat     = st.selectbox("Category *", CATEGORY_OPTIONS)
            new_owner   = st.text_input("Business owner", placeholder="CFO Office")
        with row1c:
            new_tier    = st.selectbox("Tier *", TIER_OPTIONS, index=2)
            new_steward = st.text_input("Data steward", placeholder="Finance Team")

        st.markdown("**Definition** *(drives LLM accuracy)*")
        new_desc    = st.text_area("Short description *",
                                   placeholder="One sentence: what this metric measures and what it excludes.",
                                   help="Used by LLM to identify this metric. Be precise.")
        new_long    = st.text_area("Long description",
                                   placeholder="Full business definition, methodology, benchmarks, caveats...")
        new_bq      = st.text_area("Example questions * (one per line)",
                                   placeholder="What is our net interest margin?\nShow NIM by product\nHow does NIM compare to last year?\nWhich region has the best NIM?",
                                   height=100,
                                   help="The more examples, the more accurately the LLM identifies this metric.")
        new_tags    = st.text_input("Tags (comma-separated)",
                                    placeholder="nim, interest, margin, profitability")

        st.markdown("**Technical spec** *(how the metric is computed — never shown to LLM)*")
        t1, t2 = st.columns(2)
        with t1:
            new_sel   = st.text_area("Select expression *",
                                     placeholder="ROUND((SUM(interest_income) - SUM(interest_expense)) / AVG(earning_assets) * 100, 2)",
                                     height=80,
                                     help="The SQL aggregate expression.")
            new_table = st.text_input("Source table *", placeholder="transactions")
            new_alias = st.text_input("Table alias *", placeholder="t")
            new_date  = st.text_input("Date column *", placeholder="t.transaction_date")
        with t2:
            new_filter = st.text_input("Base filter", value="1=1",
                                       placeholder="t.status='completed'")
            new_fmt    = st.selectbox("Format type *", FORMAT_OPTIONS)
            new_unit   = st.text_input("Unit", placeholder="%, USD, count, days")
            new_limit  = st.number_input("Default limit (0 = none)", min_value=0, value=0)

        new_dims = st.text_area("Allowed dimensions (JSON)",
                                value='{"region": "t.region", "product": "t.product"}',
                                height=60,
                                help=DIM_HELP)

        st.markdown("**Agent fields** *(optional — for investigative agent)*")
        ag1, ag2, ag3 = st.columns(3)
        with ag1:
            new_threshold = st.number_input("Alert threshold (0 = none)", value=0.0)
            new_direction = st.selectbox("Alert direction", ["above", "below", "change"])
        with ag2:
            new_benchmark = st.number_input("Benchmark value (0 = none)", value=0.0)
            new_bench_src = st.text_input("Benchmark source", placeholder="Industry Report 2025")
        with ag3:
            new_agent_en  = st.checkbox("Enable for agent")
            new_related   = st.text_input("Related metrics", placeholder="total_deposits, churn_rate")

        st.divider()
        c_save, c_cancel = st.columns(2)
        with c_save:
            submitted = st.form_submit_button("➕ Add metric (save as draft)", type="primary")
        with c_cancel:
            cancelled = st.form_submit_button("Cancel")

        if cancelled:
            st.session_state["reg_show_add"] = False
            st.rerun()

        if submitted:
            # Validate required fields
            errors = []
            if not new_id.strip():       errors.append("Metric ID is required")
            if not new_display.strip():  errors.append("Display name is required")
            if not new_desc.strip():     errors.append("Description is required")
            if not new_sel.strip():      errors.append("Select expression is required")
            if not new_table.strip():    errors.append("Source table is required")
            if not new_date.strip():     errors.append("Date column is required")
            if not new_bq.strip():       errors.append("At least one example question is required")

            if errors:
                for e in errors:
                    st.error(e)
                return

            # Validate ID format
            import re
            if not re.match(r'^[a-z][a-z0-9_]*$', new_id.strip()):
                st.error("Metric ID must be lowercase letters, numbers, underscores only. Must start with a letter.")
                return

            # Parse JSON fields
            try:
                dims_dict = json.loads(new_dims) if new_dims.strip() else {}
            except json.JSONDecodeError as e:
                st.error(f"Invalid JSON in allowed dimensions: {e}")
                return

            related_list = [r.strip() for r in new_related.split(",") if r.strip()]

            data = {
                "metric_id":          new_id.strip(),
                "display_name":       new_display.strip(),
                "description":        new_desc.strip(),
                "long_description":   new_long.strip() or None,
                "business_questions": [q.strip() for q in new_bq.split("\n") if q.strip()],
                "tags":               [t.strip() for t in new_tags.split(",") if t.strip()],
                "category":           new_cat,
                "business_owner":     new_owner.strip() or None,
                "data_steward":       new_steward.strip() or None,
                "tier":               new_tier,
                "status":             "draft",
                "select_expression":  new_sel.strip(),
                "primary_table":      new_table.strip(),
                "primary_alias":      new_alias.strip(),
                "date_column":        new_date.strip(),
                "base_filter":        new_filter.strip() or "1=1",
                "allowed_dimensions": dims_dict,
                "dimension_joins":    {},
                "base_joins":         [],
                "force_group_by":     [],
                "default_limit":      int(new_limit) if new_limit > 0 else None,
                "default_sort":       "DESC",
                "format_type":        new_fmt,
                "unit":               new_unit.strip() or None,
                "is_ratio":           0,
                "alert_threshold":    float(new_threshold) if new_threshold > 0 else None,
                "alert_direction":    new_direction,
                "benchmark_value":    float(new_benchmark) if new_benchmark > 0 else None,
                "benchmark_source":   new_bench_src.strip() or None,
                "is_agent_enabled":   1 if new_agent_en else 0,
                "related_metrics":    related_list,
                "investigation_path": [],
            }

            r = api_post("/metrics", data)
            if r and r.get("success"):
                st.success(
                    f"✅ **{new_display}** added as draft. "
                    f"Test it in the Chat tab, then publish when ready."
                )
                st.session_state["reg_show_add"] = False
                st.rerun()
            else:
                st.error(f"❌ {r.get('message','Failed') if r else 'API error'}")


# ── Helpers ────────────────────────────────────────────────────────────────────

def _update_metric(metric_id: str, fields: dict):
    """Quick update of specific fields."""
    r = api_put(f"/metrics/{metric_id}", fields)
    if r and r.get("success"):
        st.success(f"Updated")
    else:
        st.error(f"Failed: {r.get('message','') if r else 'API error'}")
