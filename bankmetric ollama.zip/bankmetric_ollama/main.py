"""
BankMetric (Ollama version) — FastAPI Application
LLM-powered natural language parsing via local Ollama instance.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

from db.database import get_connection
from parser.llm_parser import parse, check_ollama
from api.graphql_api import graphql_router, build_and_execute

app = FastAPI(
    title="BankMetric API (Ollama LLM Parser)",
    description="Conversational analytics with on-prem LLM parsing",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(graphql_router, prefix="/graphql")


class AskRequest(BaseModel):
    question: str
    conversation_context: list[dict] = []


class AskResponse(BaseModel):
    success: bool
    question: str
    metric: Optional[str] = None
    display_name: Optional[str] = None
    time_range: Optional[str] = None
    date_from: Optional[str] = None
    date_to: Optional[str] = None
    group_by: list[str] = []
    results: list[dict] = []
    total: Optional[float] = None
    formatted_total: Optional[str] = None
    row_count: int = 0
    sql_generated: Optional[str] = None
    error: Optional[str] = None
    suggestion: Optional[str] = None
    query_object: dict = {}
    parser_used: str = "llm"   # "llm" or "rule_based" — tells UI which parser ran


@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest):
    """Main conversational endpoint — LLM parses the question."""
    query_obj = parse(req.question, req.conversation_context)

    parser_used = "llm" if not any(
        t in (query_obj.error or "") for t in ["Ollama is offline", "Could not identify"]
    ) else "rule_based"

    if query_obj.error and not query_obj.metric:
        return AskResponse(
            success=False,
            question=req.question,
            error=query_obj.error,
            suggestion="Try: 'Show revenue by region last quarter' or 'Top 5 customers by revenue'",
            parser_used=parser_used,
        )

    response = build_and_execute(query_obj)

    if not response.success:
        return AskResponse(
            success=False,
            question=req.question,
            error=response.error.message if response.error else "Unknown error",
            suggestion=response.error.suggestion if response.error else "",
            parser_used=parser_used,
        )

    r = response.response
    return AskResponse(
        success=True,
        question=req.question,
        metric=r.metric_name,
        display_name=r.display_name,
        time_range=r.time_range,
        date_from=r.date_from,
        date_to=r.date_to,
        group_by=r.group_by,
        results=[{
            "dimension": row.dimension,
            "value": row.value,
            "formatted_value": row.formatted_value,
        } for row in r.results],
        total=r.total,
        formatted_total=r.formatted_total,
        row_count=r.row_count,
        sql_generated=r.sql_generated,
        parser_used=parser_used,
        query_object={
            "metric":     query_obj.metric,
            "time_range": query_obj.time_range,
            "group_by":   query_obj.group_by,
            "filters":    query_obj.filters,
            "confidence": query_obj.confidence,
        },
    )


@app.get("/ollama/status")
def ollama_status():
    """Check Ollama health — shown in Streamlit sidebar."""
    return check_ollama()


@app.get("/metrics")
def list_metrics():
    conn = get_connection()
    rows = conn.execute(
        "SELECT metric_name, display_name, description, source_table, "
        "allowed_dims, owner FROM metric_registry WHERE status='published' "
        "ORDER BY metric_name"
    ).fetchall()
    return [dict(r) for r in rows]


@app.get("/health")
def health():
    conn = get_connection()
    counts = {
        "transactions": conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0],
        "customers":    conn.execute("SELECT COUNT(*) FROM customers").fetchone()[0],
        "loans":        conn.execute("SELECT COUNT(*) FROM loans").fetchone()[0],
        "metrics":      conn.execute("SELECT COUNT(*) FROM metric_registry").fetchone()[0],
    }
    ollama = check_ollama()
    return {
        "status": "healthy",
        "database": "in-memory SQLite",
        "counts": counts,
        "ollama": ollama,
    }


if __name__ == "__main__":
    import uvicorn
    print("\n🚀 BankMetric API (Ollama LLM Parser)")
    print("   API:      http://localhost:8000")
    print("   GraphQL:  http://localhost:8000/graphql")
    print("   Docs:     http://localhost:8000/docs")
    print("   Ollama:   http://localhost:8000/ollama/status\n")

    ollama = check_ollama()
    if ollama["running"] and ollama.get("model_available"):
        print(f"✅ Ollama ready — model: {ollama['target_model']}")
    elif ollama["running"]:
        print(f"⚠️  Ollama running but model not pulled.")
        print(f"   Run: ollama pull {ollama['target_model']}")
    else:
        print("⚠️  Ollama not running — will use rule-based fallback parser")
        print("   To enable LLM: ollama serve  (in a separate terminal)")

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
