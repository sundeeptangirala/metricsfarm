"""
BankMetric v4 — Conversation Manager

Handles:
  - Turn counting (warning at 8, force reset at 12)
  - Context window (last 3 turns for LLM — not full history)
  - Session summary generation
  - Cross-session context carry-forward
"""

import json
import requests
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2:3b"

WARN_AT  = 8
LIMIT_AT = 12


@dataclass
class ConversationState:
    # Turn tracking
    turn_count:       int   = 0
    # Context window — last 3 data queries for LLM
    context_window:   list  = field(default_factory=list)
    # Full display history — all messages
    messages:         list  = field(default_factory=list)
    # Session summary — generated when limit reached
    session_summary:  dict  = field(default_factory=dict)
    # Previous session summary — injected as context in new session
    previous_summary: dict  = field(default_factory=dict)
    # Chart state
    last_chart_type:  str   = "bar"
    # Last successful data result (for chart type switching)
    last_data:        dict  = field(default_factory=dict)


def add_turn(state: ConversationState, query_context: dict) -> None:
    """Record a completed data query turn."""
    state.turn_count += 1
    state.context_window.append(query_context)
    # Keep only last 3 turns for LLM context window
    if len(state.context_window) > 3:
        state.context_window = state.context_window[-3:]


def should_warn(state: ConversationState) -> bool:
    return state.turn_count == WARN_AT


def should_force_reset(state: ConversationState) -> bool:
    return state.turn_count >= LIMIT_AT


def get_turn_status(state: ConversationState) -> dict:
    remaining = LIMIT_AT - state.turn_count
    return {
        "turn_count":  state.turn_count,
        "warn":        state.turn_count >= WARN_AT,
        "force_reset": state.turn_count >= LIMIT_AT,
        "remaining":   max(0, remaining),
        "pct":         min(100, int(state.turn_count / LIMIT_AT * 100)),
    }


# ── Summary generation ─────────────────────────────────────────────────────────

SUMMARY_PROMPT = """You are summarising a banking analytics conversation.
Given the conversation history, produce a JSON summary of the KEY FINDINGS.
Be specific — include actual numbers, regions, products, customer names.
Maximum 5 findings. Focus on what was most significant.

CONVERSATION:
{history}

Return ONLY this JSON (no explanation):
{{
  "key_findings": [
    {{
      "metric": "metric_name",
      "time_range": "time_range",
      "value": "formatted value e.g. $37.95M",
      "breakdown": "optional: key detail e.g. North America leads at $10.15M",
      "insight": "one sentence insight"
    }}
  ],
  "last_question": "the last question asked",
  "session_date": "{date}"
}}"""


def generate_summary(state: ConversationState) -> dict:
    """Generate a structured summary of the conversation for carry-forward."""
    from datetime import date

    # Build history string from successful data queries
    history_lines = []
    for msg in state.messages:
        if msg.get("role") == "user":
            history_lines.append(f"Q: {msg['content']}")
        elif msg.get("role") == "assistant" and msg.get("type") == "data":
            data = msg.get("data", {})
            if data.get("success"):
                history_lines.append(
                    f"A: {data.get('display_name')} = {data.get('formatted_total')} "
                    f"({data.get('time_range')}, "
                    f"by {', '.join(data.get('group_by', [])) or 'total'})"
                )

    if not history_lines:
        return {}

    history = "\n".join(history_lines[-20:])  # last 20 lines
    prompt  = SUMMARY_PROMPT.format(
        history = history,
        date    = date.today().isoformat(),
    )

    try:
        r = requests.post(
            OLLAMA_URL,
            json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False,
                  "options": {"temperature": 0.0, "num_predict": 600}},
            timeout=30,
        )
        raw = r.json().get("response", "").strip()
        import re
        m = re.search(r'\{.*\}', raw, re.DOTALL)
        if m:
            summary = json.loads(m.group())
            logger.info(f"Summary generated: {len(summary.get('key_findings', []))} findings")
            return summary
    except Exception as e:
        logger.warning(f"Summary generation failed: {e}")

    # Fallback: simple summary from messages
    return _simple_summary(state, date.today().isoformat())


def _simple_summary(state: ConversationState, today: str) -> dict:
    """Build a basic summary without LLM if generation fails."""
    findings = []
    for msg in state.messages:
        if msg.get("role") == "assistant" and msg.get("type") == "data":
            data = msg.get("data", {})
            if data.get("success") and len(findings) < 5:
                findings.append({
                    "metric":     data.get("metric", ""),
                    "time_range": data.get("query_object", {}).get("time_range", ""),
                    "value":      data.get("formatted_total", ""),
                    "breakdown":  "",
                    "insight":    f"{data.get('display_name')} was {data.get('formatted_total')}",
                })

    last_q = ""
    for msg in reversed(state.messages):
        if msg.get("role") == "user":
            last_q = msg["content"]
            break

    return {
        "key_findings":  findings,
        "last_question": last_q,
        "session_date":  today,
    }


def reset_conversation(state: ConversationState,
                       carry_summary: bool = True) -> ConversationState:
    """
    Reset conversation state.
    If carry_summary=True, the session summary becomes the previous_summary
    for the new conversation — giving the LLM background context.
    """
    new_state = ConversationState()
    if carry_summary and state.session_summary:
        new_state.previous_summary = state.session_summary
    return new_state


def format_summary_for_display(summary: dict) -> str:
    """Format summary as readable markdown for display in UI."""
    if not summary or not summary.get("key_findings"):
        return "No significant findings to summarise."

    lines = ["**Session findings:**\n"]
    for f in summary["key_findings"]:
        metric_label = f.get("metric", "").replace("_", " ").title()
        value = f.get("value", "")
        breakdown = f.get("breakdown", "")
        insight = f.get("insight", "")

        line = f"• **{metric_label}**: {value}"
        if breakdown:
            line += f" — {breakdown}"
        lines.append(line)

    if summary.get("last_question"):
        lines.append(f"\n*Last question: \"{summary['last_question']}\"*")

    return "\n".join(lines)
