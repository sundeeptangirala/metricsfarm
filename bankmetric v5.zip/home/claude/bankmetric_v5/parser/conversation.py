"""
BankMetric v5 — Conversation Manager

Handles:
  - Turn counting (warning at 8, force reset at 12)
  - Context window (last 3 turns sent to LLM)
  - Session summary generation
  - Cross-session context carry-forward (summary injected as background)

Three conversation modes:
  Mode 1 — Fresh start: no context
  Mode 2 — Continue with summary: previous findings as background
  Mode 3 — Drill deeper: specific finding pre-loaded as context
"""

import json
import requests
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

OLLAMA_URL = "http://localhost:11434/api/generate"
WARN_AT    = 8
LIMIT_AT   = 12


@dataclass
class ConversationState:
    turn_count:       int  = 0
    context_window:   list = field(default_factory=list)   # last 3 queries for LLM
    messages:         list = field(default_factory=list)   # full display history
    session_summary:  dict = field(default_factory=dict)   # generated at limit
    previous_summary: dict = field(default_factory=dict)   # from last session
    last_chart_type:  str  = "bar"
    show_chart:       bool = True
    warn_dismissed:   bool = False


def add_turn(state: ConversationState, query_context: dict) -> None:
    """Record a completed data query turn. Keep context window at max 3."""
    state.turn_count += 1
    state.context_window.append(query_context)
    if len(state.context_window) > 3:
        state.context_window = state.context_window[-3:]


def should_warn(state: ConversationState) -> bool:
    return state.turn_count >= WARN_AT and state.turn_count < LIMIT_AT


def should_force_reset(state: ConversationState) -> bool:
    return state.turn_count >= LIMIT_AT


def get_turn_status(state: ConversationState) -> dict:
    remaining = max(0, LIMIT_AT - state.turn_count)
    return {
        "turn_count":  state.turn_count,
        "warn":        state.turn_count >= WARN_AT,
        "force_reset": state.turn_count >= LIMIT_AT,
        "remaining":   remaining,
        "pct":         min(100, int(state.turn_count / LIMIT_AT * 100)),
    }


# ── Summary generation ─────────────────────────────────────────────────────────

SUMMARY_PROMPT = """Summarise this banking analytics conversation into key findings.

CONVERSATION:
{history}

Return ONLY this JSON (no explanation, no markdown):
{{
  "key_findings": [
    {{
      "metric": "metric_name",
      "time_range": "period",
      "value": "formatted value e.g. $37.95M or 12.4%",
      "breakdown": "key detail e.g. North America leads at $10.15M",
      "insight": "one sentence plain English insight"
    }}
  ],
  "last_question": "the last data question asked",
  "session_date": "{date}"
}}

Maximum 5 findings. Include specific numbers. Focus on most significant results."""


def generate_summary(state: ConversationState) -> dict:
    """Generate structured summary of session for carry-forward."""
    from datetime import date

    # Build conversation history from successful data results only
    history_lines = []
    for msg in state.messages:
        if msg.get("role") == "user":
            history_lines.append(f"Q: {msg['content']}")
        elif (msg.get("role") == "assistant" and
              msg.get("type") == "data" and
              msg.get("data", {}).get("success")):
            d = msg["data"]
            line = (f"A: {d.get('display_name','')} = {d.get('formatted_total','')} "
                    f"({d.get('time_range','')}")
            if d.get("group_by"):
                line += f", by {', '.join(d['group_by'])}"
            line += ")"
            # Add top result if available
            rows = d.get("rows", [])
            if rows and rows[0].get("dimension"):
                top = rows[0]
                line += f" — top: {top['dimension']} at {top.get('formatted', top.get('value',''))}"
            history_lines.append(line)

    if not history_lines:
        return {}

    history = "\n".join(history_lines[-30:])
    prompt = SUMMARY_PROMPT.format(
        history = history,
        date    = date.today().isoformat(),
    )

    try:
        from parser.llm_parser import _get_best_model, _extract_json
        model = _get_best_model()
        r = requests.post(OLLAMA_URL, json={
            "model": model, "prompt": prompt, "stream": False,
            "options": {"temperature": 0.0, "num_predict": 600}
        }, timeout=30)
        raw = r.json().get("response", "").strip()
        data = _extract_json(raw)
        if data and data.get("key_findings"):
            logger.info(f"Summary: {len(data['key_findings'])} findings")
            return data
    except Exception as e:
        logger.warning(f"Summary generation failed: {e}")

    # Fallback: build simple summary without LLM
    return _simple_summary(state, date.today().isoformat())


def _simple_summary(state: ConversationState, today: str) -> dict:
    """
    Build a summary from message history.
    Deduplicates by metric — keeps the most informative result per metric.
    Prioritises results that have a breakdown (group_by) over totals.
    """
    from datetime import date

    # Collect one best result per metric
    best_per_metric = {}
    last_q = ""

    for msg in state.messages:
        if msg.get("role") == "user":
            last_q = msg["content"]
        elif (msg.get("role") == "assistant" and
              msg.get("type") == "data" and
              msg.get("data", {}).get("success")):
            d = msg["data"]
            mid = d.get("metric_id", "")
            if not mid: continue
            rows = d.get("rows", [])
            has_breakdown = bool(d.get("group_by")) and rows and rows[0].get("dimension")

            # Keep this result if: no existing, or this has breakdown and existing doesn't
            existing = best_per_metric.get(mid)
            if not existing:
                best_per_metric[mid] = d
            elif has_breakdown and not (existing.get("group_by") and
                                        existing.get("rows") and
                                        existing["rows"][0].get("dimension")):
                best_per_metric[mid] = d  # upgrade to breakdown version

    # Build findings list — max 5, most recent metrics first
    findings = []
    for mid, d in list(best_per_metric.items())[-5:]:
        rows = d.get("rows", [])
        breakdown = ""
        if rows and rows[0].get("dimension"):
            top = rows[0]
            breakdown = f"{top['dimension']} at {top.get('formatted', top.get('value',''))}"
        findings.append({
            "metric":     mid,
            "time_range": d.get("time_range", ""),
            "value":      d.get("formatted_total", ""),
            "breakdown":  breakdown,
            "insight":    f"{d.get('display_name','')} was {d.get('formatted_total','')}",
        })

    return {
        "key_findings":  findings,
        "last_question": last_q,
        "session_date":  today,
    }


def reset_conversation(state: ConversationState,
                       carry_summary: bool = True) -> ConversationState:
    """
    Reset to fresh state.
    carry_summary=True: session_summary becomes previous_summary for new session.
    """
    new_state = ConversationState()
    if carry_summary and state.session_summary:
        new_state.previous_summary = state.session_summary
    elif carry_summary and state.messages:
        # Generate summary from messages if not already done
        summary = _simple_summary(state, "")
        if summary.get("key_findings"):
            new_state.previous_summary = summary
    return new_state


def format_summary_for_display(summary: dict) -> str:
    """Format summary as readable markdown for UI display."""
    if not summary or not summary.get("key_findings"):
        return "No significant findings to summarise."

    lines = ["**Session findings:**\n"]
    for f in summary["key_findings"]:
        metric_label = f.get("metric", "").replace("_", " ").title()
        value        = f.get("value", "")
        breakdown    = f.get("breakdown", "")
        line = f"• **{metric_label}**: {value}"
        if breakdown:
            line += f" — {breakdown}"
        lines.append(line)

    if summary.get("last_question"):
        lines.append(f"\n*Last question: \"{summary['last_question']}\"*")

    return "\n".join(lines)


def is_likely_followup(question: str, has_context: bool) -> bool:
    """
    Heuristic: is this question likely a follow-up to the previous one?
    Used to hint to the LLM — LLM makes final decision.

    Key principle: if the question contains an explicit metric name or
    starts with "show me X / what is X" with a specific topic, it is
    a new question even if it contains dimension words like "by region".
    """
    if not has_context:
        return False

    lower = question.lower().strip()

    # ── NEW QUESTION signals — override everything ──────────────────────────
    # If question contains explicit metric vocabulary it's a new question
    # These phrases override "show me" — they are clearly follow-ups
    FOLLOWUP_OVERRIDES = [
        "show me the same", "show me that", "show me this",
        "show me those", "show me it",
    ]
    for override in FOLLOWUP_OVERRIDES:
        if lower.startswith(override):
            return True

    NEW_QUESTION_STARTERS = [
        "show me ", "what is our ", "what is the ", "what are our ",
        "how many ", "how much ", "tell me ", "give me ", "display ",
        "what was our ", "what were our ", "calculate ", "get me ",
    ]
    for starter in NEW_QUESTION_STARTERS:
        if lower.startswith(starter):
            return False   # Definitely a new question

    # ── STRONG follow-up signals ────────────────────────────────────────────
    # These phrases almost never appear in new questions
    STRONG_FOLLOWUP = [
        "break it down", "what about",    "how does that", "same for",
        "the same for",  "same thing",    "now by",        "also by",
        "show that",     "show this",     "which one is",  "which is the",
        "that compare",  "as a percentage","as percentage", "% of total",
        "pct of",         "show as pct",   "percentage of total",
        "those",         "them",          "just for",      "only in",
        "filter to",     "top 5 of",      "top 10 of",     "instead",
        "rather",        "how about that","trend by",      "show trend",
        "show the trend",
    ]
    for s in STRONG_FOLLOWUP:
        if s in lower:
            return True

    # ── Short referential questions ─────────────────────────────────────────
    # Short questions that reference "it/that/those" are follow-ups
    REFERENTIAL = ["it", "that", "those", "them", "this"]
    word_count = len(lower.split())
    if word_count <= 5 and any(r in lower.split() for r in REFERENTIAL):
        return True

    # ── Dimension-only questions (pure "by X" with nothing else) ─────────────
    import re as _re_dim
    is_pure_dim_phrase = bool(_re_dim.match(
        r"^(by|per) (region|product|channel|customer)$", lower.strip()
    ))
    if is_pure_dim_phrase:
        return True

    # "by X" as the WHOLE question — no metric context
    # Check that no metric name appears in the question
    from db.registry import MetricRegistry as _MR
    metric_ids = _MR.get_ids()
    has_explicit_metric = any(
        mid.replace("_", " ") in lower for mid in metric_ids
    )
    DIMENSION_PHRASES = [
        "by region", "by product", "by channel", "by customer",
        "per region", "per product", "per channel",
    ]
    is_dim_phrase = any(lower == d or lower.startswith(d + " ") for d in DIMENSION_PHRASES)
    if is_dim_phrase and not has_explicit_metric:
        return True

    # ── Time-only changes ────────────────────────────────────────────────────
    TIME_CHANGES = [
        "last year", "this year", "last quarter", "this quarter",
        "last month", "this month", "ytd", "this week", "last week",
    ]
    import re
    time_words = [t for t in TIME_CHANGES if t in lower]
    if time_words and word_count <= 5:
        return True

    return False


def is_likely_new_question(question: str) -> bool:
    """
    Heuristic: does this look like a completely new question?
    """
    lower = question.lower().strip()

    # Starting a new topic
    NEW_SIGNALS = [
        "show me", "what is", "what are", "how many", "tell me",
        "give me", "display", "what was", "what were",
    ]

    # Contains a specific metric name that's different
    from db.registry import MetricRegistry
    metric_ids = MetricRegistry.get_ids()
    has_metric_word = any(mid.replace("_"," ") in lower for mid in metric_ids)

    starts_new = any(lower.startswith(s) for s in NEW_SIGNALS)

    return starts_new and has_metric_word
