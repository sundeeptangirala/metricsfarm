"""
BankMetric v5 — Streamlit UI
4 tabs: Chat | Metric Registry | Query History | System Health
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st
import requests
import pandas as pd
import json
from datetime import datetime
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from streamlit_app.registry_ui import render_registry
from parser.conversation import (
    ConversationState, add_turn, should_warn, should_force_reset,
    get_turn_status, reset_conversation, generate_summary,
    format_summary_for_display, is_likely_followup
)

API = "http://localhost:8000"
WARN_AT  = 8
LIMIT_AT = 12

st.set_page_config(page_title="BankMetric", page_icon="📊",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""<style>
.user-msg{background:#E8F4FD;border-left:4px solid #0A8F8F;padding:12px 16px;
          border-radius:0 10px 10px 0;margin:8px 0}
.bot-card{background:#F8F9FA;border-left:4px solid #6C757D;padding:12px 16px;
          border-radius:0 10px 10px 0;margin:8px 0 4px 0}
.clarify-card{background:#FFF8E8;border-left:4px solid #BA7517;padding:12px 16px;
              border-radius:0 10px 10px 0;margin:8px 0;color:#633806}
.unclear-card{background:#F3F0FF;border-left:4px solid #534AB7;padding:12px 16px;
              border-radius:0 10px 10px 0;margin:8px 0;color:#3C3489}
.narrative{background:#E1F5EE;border-left:3px solid #0F6E56;padding:10px 14px;
           border-radius:0 8px 8px 0;margin:6px 0;font-style:italic;color:#0A4030}
.metric-total{font-size:32px;font-weight:700;color:#0A8F8F}
.metric-label{font-size:11px;color:#6B7D99;text-transform:uppercase;letter-spacing:0.5px}
.pill-llm{background:#E1F5EE;color:#085041;padding:2px 8px;border-radius:12px;
          font-size:11px;font-weight:600}
.pill-python{background:#E6F1FB;color:#0C447C;padding:2px 8px;border-radius:12px;
             font-size:11px;font-weight:600}
.warn-banner{background:#FAEEDA;border:1px solid #BA7517;padding:10px 14px;
             border-radius:8px;margin:8px 0}
.registry-card{background:white;border:1px solid #E2E8F0;padding:16px;
               border-radius:10px;margin:8px 0;box-shadow:0 1px 3px rgba(0,0,0,0.08)}
.tier-badge{padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600}
</style>""", unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────────
for k, v in {
    "messages":          [],
    "context":           [],
    "turn_count":        0,
    "prev_summary":      {},
    "last_chart_type":   "bar",
    "show_chart":        True,
    "warn_dismissed":    False,
}.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ── API helpers ────────────────────────────────────────────────────────────────
def api_ask(question: str) -> dict:
    try:
        return requests.post(f"{API}/ask", json={
            "question": question,
            "context":  st.session_state.context,
            "previous_summary": st.session_state.prev_summary,
        }, timeout=60).json()
    except requests.exceptions.Timeout:
        return {"success":False,"intent":"unclear",
                "error":"Ollama is taking too long. Try again in a few seconds."}
    except Exception as e:
        return {"success":False,"intent":"unclear","error":str(e)}

def api_get(path: str) -> dict | list:
    try: return requests.get(f"{API}{path}", timeout=5).json()
    except: return {}

def api_put(path: str, data: dict) -> dict:
    try: return requests.put(f"{API}{path}", json=data, timeout=5).json()
    except Exception as e: return {"success":False,"message":str(e)}

def api_post(path: str, data: dict) -> dict:
    try: return requests.post(f"{API}{path}", json=data, timeout=5).json()
    except Exception as e: return {"success":False,"message":str(e)}

def api_delete(path: str) -> dict:
    try: return requests.delete(f"{API}{path}", timeout=5).json()
    except Exception as e: return {"success":False,"message":str(e)}


# ── Render helpers ─────────────────────────────────────────────────────────────
def render_data_result(data: dict, chart_type: str = "bar", show_chart: bool = True):
    rows      = data.get("rows", [])
    group_by  = data.get("group_by", [])
    comp      = data.get("computation","simple")
    has_dims  = bool(group_by) and rows and rows[0].get("dimension")
    glabel    = " × ".join(group_by) if group_by else "Total"
    stage     = data.get("stage_used","llm")
    conf      = data.get("confidence", 1.0)
    pbadge    = (f'<span class="pill-llm">LLM</span>'
                 if "llm" in stage else
                 f'<span class="pill-python">Python</span>')

    st.markdown(f"""
    <div class="bot-card">
      <div style="margin-bottom:4px">{pbadge}
        <span style="font-size:11px;color:#9CA3AF;margin-left:8px">
          {int(conf*100)}% confidence · {stage}
        </span>
      </div>
      <span class="metric-label">{data.get('display_name','')} · {data.get('time_range','')}
        &nbsp;|&nbsp; {data.get('date_from','')} → {data.get('date_to','')}
        {"&nbsp;|&nbsp; " + comp.replace("_"," ").title() if comp != "simple" else ""}
      </span><br>
      <span class="metric-total">{data.get('formatted_total','')}</span>
      <span style="font-size:12px;color:#9CA3AF;margin-left:12px">
        {data.get('row_count',0)} {'rows' if has_dims else 'result'} · by {glabel}
      </span>
    </div>""", unsafe_allow_html=True)

    if data.get("empty_note"):
        st.info(f"💡 {data['empty_note']}")
        return

    if data.get("narrative"):
        st.markdown(f'<div class="narrative">💡 {data["narrative"]}</div>',
                    unsafe_allow_html=True)

    if has_dims and rows:
        # Build display dataframe
        if comp == "compare_periods" and rows[0].get("current_value") is not None:
            df = pd.DataFrame([{
                glabel.title():  r.get("dimension","-"),
                "Current":       r.get("formatted_current", r.get("formatted","")),
                "Previous":      r.get("formatted_previous",""),
                "Change %":      (f"+{r['change_pct']}%" if r.get("change_pct") and r["change_pct"] >= 0
                                   else f"{r.get('change_pct','')}%") if r.get("change_pct") is not None else "-",
            } for r in rows])
            st.dataframe(df, use_container_width=True, hide_index=True)
        elif comp == "pct_of_total" and rows[0].get("pct_of_total") is not None:
            df = pd.DataFrame([{
                glabel.title():   r.get("dimension","-"),
                data.get("display_name","Value"): r.get("formatted",""),
                "% of Total":     f"{r.get('pct_of_total',0)}%",
            } for r in rows])
            st.dataframe(df, use_container_width=True, hide_index=True)
        elif comp == "trend":
            df = pd.DataFrame([{
                "Period": r.get("dimension","-"),
                "Value":  r.get("value",0),
            } for r in rows]).set_index("Period")
            if chart_type == "line": st.line_chart(df)
            else: st.bar_chart(df)
        else:
            c1, c2 = st.columns([1,1])
            with c1:
                df = pd.DataFrame([{
                    glabel.title():             r.get("dimension","-"),
                    data.get("display_name",""): r.get("formatted",""),
                } for r in rows])
                st.dataframe(df, use_container_width=True, hide_index=True)
            with c2:
                cdf = pd.DataFrame([{
                    "dim":   r.get("dimension","-"),
                    "value": r.get("value",0),
                } for r in rows]).set_index("dim")
                cdf.columns = [data.get("display_name","Value")]
                if chart_type == "line": st.line_chart(cdf, height=250)
                else: st.bar_chart(cdf, height=250)

    with st.expander("🔍 Query details", expanded=False):
        c1,c2,c3,c4 = st.columns(4)
        c1.markdown(f"**Metric**\n`{data.get('metric_id','')}`")
        c2.markdown(f"**Time**\n`{data.get('time_range','')}`")
        c3.markdown(f"**Computation**\n`{data.get('computation','simple')}`")
        c4.markdown(f"**Group by**\n`{', '.join(data.get('group_by',[]) or ['total'])}`")
        if data.get("sql_preview"):
            st.caption("SQL structure (schema-safe preview):")
            st.code(data["sql_preview"], language="sql")
        if data.get("feasibility_note"):
            st.caption(f"Computation: {data['feasibility_note']}")


def render_clarify(data: dict, idx: int):
    q    = data.get("clarify_question","Did you mean one of these?")
    opts = data.get("clarify_options",[])
    st.markdown(f'<div class="clarify-card">🤔 <strong>{q}</strong></div>',
                unsafe_allow_html=True)
    if opts:
        cols = st.columns(min(len(opts),3))
        for i,opt in enumerate(opts):
            with cols[i%3]:
                if st.button(opt.get("label",f"Option {i+1}"),
                             key=f"cl_{idx}_{i}", use_container_width=True):
                    handle_question(opt.get("label",""))
                    st.rerun()


def render_follow_up_chips(data: dict):
    metric   = data.get("metric_id","")
    group_by = data.get("group_by",[])
    comp     = data.get("computation","simple")
    sugg     = []
    if "region"   not in group_by: sugg.append("Break it down by region")
    if "product"  not in group_by: sugg.append("Break it down by product")
    if "channel"  not in group_by: sugg.append("Which channel is most used?")
    if comp == "simple":
        sugg.append("How does this compare to last quarter?")
        sugg.append("Show this as a percentage of total")
    sugg.append("Show trend by month")
    sugg = list(dict.fromkeys(sugg))[:4]
    if sugg:
        st.markdown("**💡 Follow-up:**")
        cols = st.columns(len(sugg))
        for i,s in enumerate(sugg):
            if cols[i].button(s, key=f"sugg_{len(st.session_state.messages)}_{i}"):
                handle_question(s); st.rerun()


def handle_question(question: str):
    st.session_state.messages.append({"role":"user","content":question})

    # Handle UI commands locally before calling API
    lower = question.lower().strip()
    if any(p in lower for p in ["line chart","show as line","convert to line","switch to line"]):
        st.session_state.last_chart_type = "line"
        _update_last_chart()
        st.session_state.messages.append({"role":"assistant","type":"ui_msg",
            "text":"✅ Chart changed to line."})
        return
    if any(p in lower for p in ["bar chart","show as bar","convert to bar","switch to bar"]):
        st.session_state.last_chart_type = "bar"
        _update_last_chart()
        st.session_state.messages.append({"role":"assistant","type":"ui_msg",
            "text":"✅ Chart changed to bar."})
        return
    if any(p in lower for p in ["show table","hide chart","table only","table view"]):
        st.session_state.show_chart = False
        st.session_state.messages.append({"role":"assistant","type":"ui_msg",
            "text":"✅ Showing table only."})
        return
    if any(p in lower for p in ["show chart","hide table","chart only","chart view"]):
        st.session_state.show_chart = True
        st.session_state.messages.append({"role":"assistant","type":"ui_msg",
            "text":"✅ Showing chart."})
        return
    if any(p in lower for p in ["start over","new conversation","clear","reset","start fresh"]):
        do_reset(); st.rerun(); return

    with st.spinner("🧠 Thinking..."):
        data = api_ask(question)
    intent = data.get("intent","unclear")
    if intent == "ui_command":
        action = data.get("ui_action","")
        if action == "chart_line":
            st.session_state.last_chart_type = "line"; _update_last_chart()
        elif action == "chart_bar":
            st.session_state.last_chart_type = "bar"; _update_last_chart()
        elif action == "clear":
            do_reset(); st.rerun(); return
        st.session_state.messages.append({
            "role":"assistant","type":"ui_msg",
            "text": _ui_action_message(action)
        })
        return
    st.session_state.messages.append({
        "role":"assistant","type":intent,"data":data,
        "chart_type": st.session_state.last_chart_type,
    })
    if intent in ("data","unclear"):
        st.session_state.turn_count += 1
    if intent == "data" and data.get("success"):
        ctx_entry = {
            "metric_id":  data.get("metric_id"),
            "time_range": data.get("time_range","last_30_days"),
            "group_by":   data.get("group_by",[]),
            "filters":    {},
        }
        st.session_state.context.append(ctx_entry)
        if len(st.session_state.context) > 3:
            st.session_state.context = st.session_state.context[-3:]


def _update_last_chart():
    """Update chart type on the most recent data message."""
    for msg in reversed(st.session_state.messages):
        if msg.get("type") == "data" and msg.get("data",{}).get("success"):
            msg["chart_type"] = st.session_state.last_chart_type
            break

def _ui_action_message(action: str) -> str:
    msgs = {
        "chart_line":     "✅ Chart changed to line.",
        "chart_bar":      "✅ Chart changed to bar.",
        "export":         "Export coming in a future version. Use the download button in the chart toolbar.",
        "display_change": "Display layout changes aren't supported yet. Try asking a data question.",
        "clear":          "✅ Conversation cleared.",
    }
    return msgs.get(action, f"✅ {action.replace('_',' ').title()} done.")

def do_reset(carry_summary: bool = True):
    # Generate summary before clearing if we have messages
    if carry_summary and st.session_state.get("messages"):
        with st.spinner("📝 Summarising session..."):
            try:
                state = ConversationState(
                    messages=st.session_state.messages,
                    turn_count=st.session_state.turn_count,
                )
                summary = generate_summary(state)
                if summary and summary.get("key_findings"):
                    st.session_state.prev_summary = summary
            except: pass

    st.session_state.messages        = []
    st.session_state.context         = []
    st.session_state.turn_count      = 0
    st.session_state.warn_dismissed  = False
    st.session_state.last_chart_type = "bar"
    st.session_state.show_chart      = True


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("📊 BankMetric")
    st.caption("Conversational Analytics · v5")

    col1, col2 = st.columns([3,1])
    with col1:
        if st.button("🔄 New conversation", use_container_width=True, type="primary"):
            do_reset(); st.rerun()
    with col2:
        tc    = st.session_state.turn_count
        color = "#DC3545" if tc >= WARN_AT else "#28A745"
        st.markdown(f'<div style="text-align:center;padding:6px;background:{color};'
                    f'color:white;border-radius:6px;font-size:12px;font-weight:600;">'
                    f'{tc}/{LIMIT_AT}</div>', unsafe_allow_html=True)

    st.divider()
    try:
        h = api_get("/health")
        st.success("✅ API connected")
        c = h.get("counts",{})
        st.caption(f"{c.get('transactions',0):,} txns · "
                   f"{c.get('customers',0):,} customers · "
                   f"{c.get('loans',0):,} loans")
        ol = h.get("ollama",{})
        st.divider()
        st.markdown("**🧠 Ollama LLM**")
        if ol.get("running") and ol.get("models"):
            st.success(f"✅ Ready — `{ol.get('active_model','')}`")
        elif ol.get("running"):
            st.warning("⚠️ No models pulled")
            st.code("ollama pull mistral:7b")
        else:
            st.error("❌ Not running")
            st.code("ollama serve")
    except:
        st.error("❌ API not running\n`python main.py`")

    # Previous session summary
    if st.session_state.get("prev_summary") and st.session_state["prev_summary"].get("key_findings"):
        st.divider()
        st.markdown("**📋 Previous session context:**")
        summary_text = format_summary_for_display(st.session_state["prev_summary"])
        st.markdown(summary_text)
        col_a, col_b = st.columns(2)
        with col_a:
            if st.button("🔍 Use this context", key="use_ctx", use_container_width=True):
                st.rerun()
        with col_b:
            if st.button("🗑 Clear context", key="clear_ctx", use_container_width=True):
                st.session_state.prev_summary = {}
                st.rerun()

    st.divider()
    st.markdown("**Try asking:**")
    st.markdown("""
- Revenue by region last quarter
- Which channel grew the most?
- Show delinquency as % of total
- Top 5 customers by revenue
- How does churn compare to last year?
- Show revenue trend by month
- Active customers by region this year
    """)



# ══════════════════════════════════════════════════════════════════════════════
# DISCOVERY UI — shown before user asks anything
# ══════════════════════════════════════════════════════════════════════════════

SUBJECT_AREAS = {
    "💰 Revenue & Income": {
        "color":       "#0A8F8F",
        "description": "Revenue totals, transaction volumes, channel performance, fee income",
        "count_hint":  "15 metrics",
        "examples": [
            "Show me revenue by region last quarter",
            "Which channel generates the most revenue?",
            "Revenue trend by month last year",
            "Fee income by product this year",
            "Top 5 customers by revenue",
        ],
    },
    "👥 Customers": {
        "color":       "#6366F1",
        "description": "Active customers, churn, retention, NPS, digital adoption, segmentation",
        "count_hint":  "15 metrics",
        "examples": [
            "What is our churn rate by region?",
            "How many new customers did we acquire last quarter?",
            "Show NPS score by product",
            "Digital adoption rate by region",
            "How many multi-product customers do we have?",
        ],
    },
    "🏦 Loans & Credit": {
        "color":       "#DC2626",
        "description": "Loan portfolio, delinquency, product breakdown, approval rates, risk",
        "count_hint":  "20 metrics",
        "examples": [
            "What is our delinquency rate by product?",
            "Show total loan value by region",
            "How does delinquency compare to last year?",
            "Average loan size by product",
            "Which region has the highest NPL ratio?",
        ],
    },
    "🏧 Deposits & Liquidity": {
        "color":       "#059669",
        "description": "Total deposits, savings vs term, deposit growth, average balances",
        "count_hint":  "10 metrics",
        "examples": [
            "What is our total deposit base?",
            "Show deposits by type and region",
            "Savings vs term deposit split",
            "Average deposit balance by region",
            "New deposit accounts this quarter",
        ],
    },
    "⚙️ Operations": {
        "color":       "#D97706",
        "description": "Complaints, fraud, digital rate, channel mix, failure rates, efficiency",
        "count_hint":  "15 metrics",
        "examples": [
            "How many complaints did we receive last month?",
            "What is our fraud loss amount?",
            "Digital transaction rate by region",
            "Transaction failure rate by channel",
            "Complaint resolution rate by product",
        ],
    },
    "📱 Digital & Channels": {
        "color":       "#7C3AED",
        "description": "Digital adoption, mobile usage, channel revenue, online banking metrics",
        "count_hint":  "10 metrics",
        "examples": [
            "What is our digital adoption rate?",
            "Mobile vs online transaction volume",
            "Digital revenue share by region",
            "How many customers use the mobile app?",
            "Digital onboarding count this year",
        ],
    },
    "🛡️ Risk & Compliance": {
        "color":       "#B91C1C",
        "description": "AML alerts, KYC completion, fraud detection, credit exposure, regulatory",
        "count_hint":  "15 metrics",
        "examples": [
            "How many AML alerts did we generate?",
            "What is our KYC completion rate?",
            "Credit risk exposure by product",
            "High value transaction count this month",
            "Suspicious activity reports filed",
        ],
    },
}

def _render_discovery():
    """Discovery UI — shown before user asks anything."""

    st.markdown("### 📊 What would you like to explore?")
    st.caption(f"100 governed metrics across 7 subject areas · Ask in plain English")

    # Quick example buttons at top
    st.markdown("**Popular questions:**")
    QUICK = [
        "Show revenue by region last quarter",
        "What is our delinquency rate?",
        "Top 5 customers by revenue",
        "Churn rate by region this year",
        "Digital adoption rate",
        "Show fraud losses by channel",
    ]
    cols = st.columns(3)
    for i, q in enumerate(QUICK):
        if cols[i%3].button(q, key=f"quick_{i}", use_container_width=True):
            handle_question(q); st.rerun()

    st.markdown("---")
    st.markdown("**Or explore by subject area:**")

    # Subject area cards — 2 columns
    areas = list(SUBJECT_AREAS.items())
    for row_start in range(0, len(areas), 2):
        col1, col2 = st.columns(2)
        for col_idx, col in enumerate([col1, col2]):
            idx = row_start + col_idx
            if idx >= len(areas): break
            area_name, area_data = areas[idx]
            color = area_data["color"]
            with col:
                with st.expander(
                    f"{area_name}  `{area_data['count_hint']}`",
                    expanded=False
                ):
                    st.caption(area_data["description"])
                    st.markdown("**Try asking:**")
                    for ex in area_data["examples"]:
                        if st.button(ex, key=f"disc_{idx}_{ex[:20]}",
                                     use_container_width=True):
                            handle_question(ex); st.rerun()

    st.markdown("---")
    # UI command hints
    st.markdown("**💡 You can also:**")
    hint_cols = st.columns(4)
    hint_cols[0].info("📈 Ask follow-up questions

*'Break that down by region'*")
    hint_cols[1].info("📊 Change chart type

*'Convert to line chart'*")
    hint_cols[2].info("📋 Compare periods

*'How does that compare to last year?'*")
    hint_cols[3].info("📐 See metrics

*Go to Metric Registry tab*")

# ══════════════════════════════════════════════════════════════════════════════
# MAIN TABS
# ══════════════════════════════════════════════════════════════════════════════
tab1, tab2, tab3, tab4 = st.tabs(["💬 Chat", "📐 Metric Registry", "📋 History", "🔧 Health"])


# ── TAB 1: CHAT ────────────────────────────────────────────────────────────────
with tab1:
    st.markdown("## Ask anything about your metrics")
    st.caption("Powered by local Ollama LLM · No data leaves your machine")

    # Turn limit warning
    tc = st.session_state.turn_count
    if tc >= LIMIT_AT:
        st.markdown(f'<div class="warn-banner">🛑 <strong>Conversation limit reached.'
                    f'</strong> Start fresh to continue.</div>', unsafe_allow_html=True)
        if st.button("🔄 Start new conversation", type="primary"):
            do_reset(); st.rerun()
        st.stop()
    elif tc >= WARN_AT and not st.session_state.warn_dismissed:
        c1,c2,c3 = st.columns([3,1,1])
        with c1:
            st.markdown(f'<div class="warn-banner">⚠️ <strong>Conversation getting long'
                        f' ({tc}/{LIMIT_AT} turns).</strong></div>',
                        unsafe_allow_html=True)
        with c2:
            if st.button("Start fresh"): do_reset(); st.rerun()
        with c3:
            if st.button("Keep going"):
                st.session_state.warn_dismissed=True; st.rerun()

    # ── Discovery UI — shown before user asks anything ────────────────────────
    if not st.session_state.messages:
        _render_discovery()
        st.divider()

    # Chat history
    for i, msg in enumerate(st.session_state.messages):
        if msg["role"] == "user":
            st.markdown(f'<div class="user-msg">👤 <strong>You:</strong> {msg["content"]}</div>',
                        unsafe_allow_html=True)
        else:
            mtype = msg.get("type","data")
            data  = msg.get("data",{})
            if mtype == "ui_msg":
                st.info(msg.get("text",""))
            elif mtype == "clarify":
                render_clarify(data, i)
            elif mtype == "unclear":
                err  = data.get("error","")
                sugg = data.get("suggestions",[])
                st.markdown(f'<div class="unclear-card">💭 {err}</div>',
                            unsafe_allow_html=True)
                if sugg:
                    st.markdown("**You could ask:**")
                    cols = st.columns(min(len(sugg),4))
                    for j,s in enumerate(sugg):
                        spec = None
                        try:
                            from db.registry import MetricRegistry
                            spec = MetricRegistry.get(s)
                        except: pass
                        label = spec.display_name if spec else s.replace("_"," ").title()
                        if cols[j%4].button(label, key=f"sugg_unc_{i}_{j}"):
                            handle_question(f"show {label}")
                            st.rerun()
            elif mtype == "data":
                if data.get("success"):
                    st.markdown("**📊 BankMetric:**")
                    chart_type = msg.get("chart_type","bar")
                    if i == len(st.session_state.messages)-1:
                        chart_type = st.session_state.last_chart_type
                    render_data_result(data, chart_type,
                                              show_chart=st.session_state.show_chart)
                    if i == len(st.session_state.messages)-1:
                        render_follow_up_chips(data)
                else:
                    st.error(f"❌ {data.get('error','Something went wrong.')}")

    # Input
    st.divider()
    disabled = st.session_state.turn_count >= LIMIT_AT
    with st.form("chat_form", clear_on_submit=True):
        c1,c2 = st.columns([5,1])
        with c1:
            q = st.text_input("Ask...",
                placeholder="e.g. Show revenue trend by month last year",
                label_visibility="collapsed", disabled=disabled)
        with c2:
            sub = st.form_submit_button("Ask →", use_container_width=True,
                                        disabled=disabled)
        if sub and q.strip():
            handle_question(q.strip()); st.rerun()


# ── TAB 2: METRIC REGISTRY ─────────────────────────────────────────────────────
with tab2:
    # Handle prefill from registry "Ask about this metric" button
    if st.session_state.get("reg_prefill"):
        prefill = st.session_state.pop("reg_prefill")
        handle_question(prefill)
        st.rerun()
    render_registry()


# ── TAB 3: HISTORY ─────────────────────────────────────────────────────────────
with tab3:
    st.markdown("## 📋 Query History")
    st.caption("All questions asked this session with full audit trail.")

    history = api_get("/history?limit=100")
    if not isinstance(history, list): history = []

    if not history:
        st.info("No queries yet. Ask something in the Chat tab.")
    else:
        # Summary stats
        c1,c2,c3,c4 = st.columns(4)
        c1.metric("Total queries", len(history))
        feasible = sum(1 for h in history if h.get("feasible") != 0)
        c2.metric("Successful", feasible)
        metrics_used = len(set(h.get("metric_id","") for h in history if h.get("metric_id")))
        c3.metric("Metrics used", metrics_used)
        avg_rows = sum(h.get("row_count",0) for h in history) / max(len(history),1)
        c4.metric("Avg rows returned", f"{avg_rows:.0f}")

        st.divider()

        # History table
        rows_for_df = []
        for h in history:
            rows_for_df.append({
                "Time":       h.get("queried_at","")[:16],
                "Question":   (h.get("question",""))[:60],
                "Metric":     h.get("metric_id",""),
                "Time Range": h.get("time_range",""),
                "Group by":   h.get("group_by",""),
                "Computation":h.get("computation","simple"),
                "Rows":       h.get("row_count",""),
            })
        st.dataframe(pd.DataFrame(rows_for_df), use_container_width=True,
                     hide_index=True)

        # Re-run any query
        st.divider()
        st.markdown("**Re-run a previous question:**")
        q_options = [h.get("question","") for h in history[:20] if h.get("question")]
        if q_options:
            selected = st.selectbox("Select question", q_options, key="rerun_q")
            if st.button("▶ Run again", key="rerun_btn"):
                st.session_state["active_tab"] = "chat"
                handle_question(selected)
                st.rerun()


# ── TAB 4: HEALTH ──────────────────────────────────────────────────────────────
with tab4:
    st.markdown("## 🔧 System Health")

    if st.button("🔄 Refresh", key="health_refresh"):
        st.rerun()

    health = api_get("/health")
    if not isinstance(health, dict):
        st.error("❌ Cannot reach API — run `python main.py`")
    else:
        # Overall status
        st.success(f"✅ API healthy — v{health.get('version','')}")

        c1,c2,c3,c4 = st.columns(4)
        counts = health.get("counts",{})
        c1.metric("Metrics in registry", counts.get("metrics",0))
        c2.metric("Transactions",        f"{counts.get('transactions',0):,}")
        c3.metric("Customers",           f"{counts.get('customers',0):,}")
        c4.metric("Loans",               f"{counts.get('loans',0):,}")

        st.divider()

        # Ollama status
        st.markdown("### 🧠 LLM Status")
        ol = health.get("ollama",{})
        if ol.get("running"):
            st.success(f"✅ Ollama running · Active model: `{ol.get('active_model','')}`")
            models = ol.get("models",[])
            if models:
                st.markdown("**Available models:**")
                for m in models:
                    st.markdown(f"  • `{m}`")
        else:
            st.error("❌ Ollama not running")
            st.code("ollama serve")
            st.markdown("**Fallback chain:**")
            st.markdown("1. ~~External/Ollama LLM~~ (offline)")
            st.markdown("2. ✅ Python extraction (always available)")
            st.markdown("3. ✅ Clarification questions (always available)")

        st.divider()

        # Fallback chain
        st.markdown("### 🔗 Parser Fallback Chain")
        col1,col2,col3 = st.columns(3)
        with col1:
            if ol.get("running") and ol.get("models"):
                st.success("✅ Stage 1: LLM Intent")
                st.caption(f"Model: {ol.get('active_model','')}")
            else:
                st.error("❌ Stage 1: LLM Intent")
                st.caption("Ollama not running")
        with col2:
            st.success("✅ Stage 2: Python Extraction")
            st.caption("Always available — reads explicit values")
        with col3:
            st.success("✅ Stage 3: Clarification")
            st.caption("Always available — asks when unsure")

        st.divider()

        # Registry summary
        st.markdown("### 📐 Registry Summary")
        metrics = api_get("/metrics")
        if isinstance(metrics, list):
            cats = {}
            for m in metrics:
                c = m.get("category","other")
                cats.setdefault(c,[]).append(m.get("display_name",""))
            for cat, names in sorted(cats.items()):
                st.markdown(f"**{cat.title()}:** {', '.join(names)}")
