"""
BankMetric v5 — Parser

Two LLM roles, cleanly separated:

EXTERNAL LLM (small/fast — Copilot or small Ollama):
  Sees: question + metric descriptions (no schema)
  Does: intent classification, metric identification
  Returns: metric_id, dimension, time_range, confidence

ON-PREM LLM (larger — mistral:7b or llama3.1:8b):
  Sees: question + feasibility question
  Does: feasibility check, computation description, SQL self-check, narrative
  Never sees: table names, column names, actual data

FALLBACK CHAIN:
  External LLM → Internal LLM → Python extraction → Clarify

Python extraction (Stage 2) always runs — fills gaps LLM misses.
"""

import re
import json
import requests
import logging
from datetime import date, timedelta
from dataclasses import dataclass, field
from typing import Optional

from db.registry import MetricRegistry
from db.sql_builder import QueryDescriptor, resolve_date_range

logger = logging.getLogger(__name__)

OLLAMA_URL = "http://localhost:11434/api/generate"
TIMEOUT    = 30

# ── Output types ───────────────────────────────────────────────────────────────

@dataclass
class ClarifyOption:
    label:       str
    metric_id:   Optional[str] = None
    time_range:  Optional[str] = None
    group_by:    list[str]     = field(default_factory=list)
    filters:     dict          = field(default_factory=dict)
    computation: str           = "simple"

@dataclass
class ParseResult:
    # Intent
    intent:           str           = "data"   # data|clarify|unclear|ui_command
    # Data query
    descriptor:       Optional[QueryDescriptor] = None
    # Clarification
    clarify_question: Optional[str] = None
    clarify_options:  list[ClarifyOption] = field(default_factory=list)
    # Unclear
    unclear_message:  Optional[str] = None
    unclear_suggestions: list[str]  = field(default_factory=list)
    # UI
    ui_action:        Optional[str] = None
    # Meta
    raw_question:     str           = ""
    stage_used:       str           = "llm"
    confidence:       float         = 1.0
    feasibility_note: Optional[str] = None


# ── Model selection ────────────────────────────────────────────────────────────

def _get_best_model() -> str:
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        models = [m["name"] for m in r.json().get("models", [])]
        for pref in ["mistral", "llama3.1", "phi3", "llama3.2"]:
            m = next((x for x in models if pref in x), None)
            if m: return m
        return models[0] if models else "llama3.2:3b"
    except:
        return "llama3.2:3b"

def _call_ollama(prompt: str, model: str, max_tokens: int = 400) -> Optional[dict]:
    try:
        r = requests.post(OLLAMA_URL, json={
            "model": model, "prompt": prompt, "stream": False,
            "options": {"temperature": 0.0, "num_predict": max_tokens}
        }, timeout=TIMEOUT)
        r.raise_for_status()
        raw = r.json().get("response", "").strip()
        return _extract_json(raw)
    except:
        return None

def _extract_json(raw: str) -> Optional[dict]:
    if not raw: return None
    raw = re.sub(r"```json\s*", "", raw)
    raw = re.sub(r"```\s*", "", raw)
    m = re.search(r'\{.*\}', raw, re.DOTALL)
    if not m: return None
    try: return json.loads(m.group())
    except: return None

def check_ollama() -> dict:
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        models = [m["name"] for m in r.json().get("models", [])]
        best   = _get_best_model()
        return {"running": True, "models": models, "active_model": best,
                "status": "ready" if models else "no_models"}
    except requests.exceptions.ConnectionError:
        return {"running": False, "status": "ollama_not_running"}
    except Exception as e:
        return {"running": False, "status": "error", "error": str(e)}


# ══════════════════════════════════════════════════════════════════════════════
# STAGE 2 — Python precision extraction
# Reads what the user literally typed.
# Always runs — fills in what the LLM might miss.
# ══════════════════════════════════════════════════════════════════════════════

NUMBER_WORDS = {
    "one":1,"two":2,"three":3,"four":4,"five":5,"six":6,"seven":7,
    "eight":8,"nine":9,"ten":10,"fifteen":15,"twenty":20,"fifty":50,
}

REGIONS = {
    "north america": "North America", "na": "North America",
    "us": "North America", "usa": "North America", "united states": "North America",
    "europe": "Europe", "uk": "Europe", "emea": "Europe",
    "apac": "APAC", "asia pacific": "APAC", "asia": "APAC",
    "latin america": "Latin America", "latam": "Latin America",
    "latin am": "Latin America", "south america": "Latin America",
}
PRODUCTS = {
    "mortgage": "Mortgage", "home loan": "Mortgage",
    "personal loan": "Personal Loan", "personal loans": "Personal Loan",
    "auto loan": "Auto Loan", "car loan": "Auto Loan",
    "business loan": "Business Loan", "corporate loan": "Business Loan",
    "credit card": "Credit Card", "cc": "Credit Card",
}
TIME_PATTERNS = [
    (r"\byear\s+to\s+date\b|\bytd\b",         "year_to_date"),
    (r"\bthis\s+quarter\b|\bqtd\b",           "this_quarter"),
    (r"\blast\s+quarter\b",                    "last_quarter"),
    (r"\bthis\s+month\b|\bmtd\b",             "this_month"),
    (r"\blast\s+month\b",                      "last_month"),
    (r"\bthis\s+year\b",                       "this_year"),
    (r"\blast\s+year\b|\bttm\b|\bltm\b",      "last_year"),
    (r"\blast\s+90\s+days?\b",                "last_90_days"),
    (r"\blast\s+30\s+days?\b",                "last_30_days"),
    (r"\blast\s+week\b",                       "last_week"),
    (r"\bthis\s+week\b",                       "this_week"),
    (r"\btoday\b",                             "today"),
]
DIM_PATTERNS = {
    "region":   [r"\bby\s+region\b", r"\bper\s+region\b", r"\bwhich\s+region\b",
                 r"\btop\s+\d+\s+regions?\b", r"\btop\s+\w+\s+regions?\b",
                 r"\bacross\s+regions?\b", r"\bregion\s+breakdown\b"],
    "product":  [r"\bby\s+product\b", r"\bper\s+product\b", r"\bwhich\s+product\b",
                 r"\btop\s+\d+\s+products?\b", r"\bproduct\s+breakdown\b",
                 r"\bacross\s+products?\b"],
    "channel":  [r"\bby\s+channel\b", r"\bper\s+channel\b", r"\bwhich\s+channel\b",
                 r"\bmost\s+used\s+channel\b", r"\bbest\s+channel\b",
                 r"\bchannel\s+breakdown\b", r"\bmost\s+popular\s+channel\b"],
    "customer": [r"\bby\s+customer\b", r"\btop\s+\d+\s+customers?\b",
                 r"\btop\s+\w+\s+customers?\b", r"\b\d+\s+customers?\b",
                 r"\bmost\s+valuable\s+customers?\b", r"\btop\s+customers?\b",
                 r"\bcustomers?\s+by\s+revenue\b", r"\bcustomer\s+breakdown\b"],
}
COMPARISON_PATTERNS = [
    r"\bgrew?\s+the\s+most\b", r"\bgrowth\b", r"\bchange\b", r"\bvs\b",
    r"\bversus\b", r"\bcompared?\s+to\b", r"\bperiod\s+over\s+period\b",
    r"\bqoq\b", r"\bmom\b", r"\byoy\b", r"\bquarter\s+over\s+quarter\b",
    r"\bmonth\s+over\s+month\b", r"\byear\s+over\s+year\b",
    r"\bbetter\s+than\s+last\b", r"\bworse\s+than\s+last\b",
]
TREND_PATTERNS = [
    r"\btrend\b", r"\bover\s+time\b", r"\bby\s+month\b", r"\bmonthly\b",
    r"\bby\s+quarter\b", r"\bquarterly\b", r"\bhistory\b", r"\bhistorical\b",
    r"\bover\s+the\s+(last|past)\b",
]
PCT_PATTERNS = [
    r"\bwhat\s+percent\w*\b", r"\bshare\b", r"\bproportion\b",
    r"\bpercentage\s+of\s+total\b", r"\bcontribut\w+\b", r"\bbreakdown\s+as\s+percent\b",
]

def _extract_limit(text: str) -> Optional[int]:
    lower = text.lower()
    m = re.search(r'\btop\s+(\d+)\b', lower)
    if m: return int(m.group(1))
    m = re.search(r'\btop\s+(' + '|'.join(NUMBER_WORDS) + r')\b', lower)
    if m: return NUMBER_WORDS[m.group(1)]
    m = re.search(r'\b(\d+)\s+(?:customers?|regions?|products?|channels?)\b', lower)
    if m: return int(m.group(1))
    return None

def _extract_time(text: str) -> Optional[str]:
    lower = text.lower()
    for pattern, tr in TIME_PATTERNS:
        if re.search(pattern, lower): return tr
    return None

def _extract_dims(text: str) -> list[str]:
    lower = text.lower()
    return [dim for dim, patterns in DIM_PATTERNS.items()
            if any(re.search(p, lower) for p in patterns)]

def _extract_region(text: str) -> Optional[str]:
    lower = text.lower()
    if re.search(r'\bby\s+region\b|\bacross\s+regions?\b', lower): return None
    for alias, canonical in REGIONS.items():
        if f" {alias} " in f" {lower} ": return canonical
    return None

def _extract_product(text: str) -> Optional[str]:
    lower = text.lower()
    if re.search(r'\bby\s+product\b|\bacross\s+products?\b', lower): return None
    for alias, canonical in PRODUCTS.items():
        if alias in lower: return canonical
    return None

def _extract_order(text: str) -> str:
    lower = text.lower()
    if any(w in lower for w in ["lowest","worst","least","smallest","bottom","worst"]):
        return "ASC"
    return "DESC"

def _detect_computation_hint(text: str) -> str:
    """Detect what type of computation the question implies."""
    lower = text.lower()
    if any(re.search(p, lower) for p in COMPARISON_PATTERNS):
        return "compare_periods"
    if any(re.search(p, lower) for p in TREND_PATTERNS):
        return "trend"
    if any(re.search(p, lower) for p in PCT_PATTERNS):
        return "pct_of_total"
    return "simple"


# ══════════════════════════════════════════════════════════════════════════════
# STAGE 1 — LLM intent classification
# Short prompt — just identifies metric and intent.
# ══════════════════════════════════════════════════════════════════════════════

def _stage1_prompt(question: str, context: list[dict],
                   prev_summary: Optional[dict]) -> str:

    vocab = MetricRegistry.get_llm_vocabulary()

    ctx_str = ""
    if context:
        last = context[-1]
        ctx_str = f"""
Previous query (for follow-up detection):
  metric={last.get('metric_id')}, time={last.get('time_range')}, group_by={last.get('group_by')}
If this is a follow-up (break down, what about, same for, now by, which is highest/lowest),
set inherit_context=true and only specify what changed.
"""

    summary_str = ""
    if prev_summary and prev_summary.get("key_findings"):
        summary_str = f"""
Context from previous session (background knowledge):
{json.dumps(prev_summary['key_findings'][:3], indent=2)}
"""

    metric_ids = MetricRegistry.get_ids()

    return f"""You are a banking analytics query classifier.
{summary_str}
{vocab}
{ctx_str}
Classify the user question into one of:
- "data": user wants a metric answer — identify which metric
- "ui_command": chart change, export, reset/clear/start over
- "clarify": metric is genuinely ambiguous (e.g. "show transactions" = count or value?)
- "unclear": question is outside available metrics scope

For "data": return the exact metric_id from this list: {metric_ids}
For "clarify": provide 2-3 options with metric_id for each
For "unclear": explain what's out of scope and suggest 2-3 alternatives
For "ui_command": set ui_action (chart_line|chart_bar|export|clear|display_change)

inherit_context=true when this is clearly a follow-up to the previous query.

Return ONLY valid JSON:
{{
  "intent": "data",
  "metric_id": null,
  "inherit_context": false,
  "ui_action": null,
  "clarify_question": null,
  "clarify_options": null,
  "unclear_message": null,
  "confidence": 0.95
}}

QUESTION: "{question}"
"""


# ══════════════════════════════════════════════════════════════════════════════
# FEASIBILITY CHECK — on-prem LLM
# Checks if the question can be answered from the metric definition.
# Returns whether to proceed and what alternatives to offer if not.
# ══════════════════════════════════════════════════════════════════════════════

def _feasibility_prompt(question: str, spec_description: str,
                        all_metrics_summary: str) -> str:
    return f"""You are a banking analytics feasibility checker.

A user asked: "{question}"

The system identified this metric:
{spec_description}

All available metrics:
{all_metrics_summary}

Can this question be answered using the identified metric and its allowed dimensions?

Consider:
1. Does the metric definition cover what the user is asking?
2. Are the dimensions needed available?
3. Is external data required (competitor data, employee counts, market data)?
4. Is this a forecast/prediction (not supported)?
5. Is this a "why" question requiring causal analysis (not supported)?

If feasible, describe HOW to compute it in plain terms (no SQL, no table names).
If not feasible, explain why and suggest 2-3 alternatives from available metrics.

Return ONLY this JSON:
{{
  "feasible": true,
  "reason": "brief explanation",
  "computation_description": "what to compute in plain terms",
  "needs_comparison": false,
  "needs_trend": false,
  "needs_pct_of_total": false,
  "compare_to_period": null,
  "trend_grain": "month",
  "alternatives": []
}}"""


# ══════════════════════════════════════════════════════════════════════════════
# NARRATIVE — on-prem LLM
# Generates plain English summary from formatted results.
# Sees numbers only — no schema, no SQL.
# ══════════════════════════════════════════════════════════════════════════════

def _narrative_prompt(question: str, metric_name: str,
                      time_range: str, results_text: str) -> str:
    return f"""You are a banking analyst summarising data results.

The user asked: "{question}"

Results for {metric_name} ({time_range}):
{results_text}

Write a 1-2 sentence plain English summary of the key finding.
Be specific — mention the top value, any notable pattern, or significant comparison.
Do not mention SQL, databases, or technical details.
Do not start with "Based on" or "According to".

Return ONLY the summary text, nothing else."""


# ══════════════════════════════════════════════════════════════════════════════
# MAIN PARSE FUNCTION
# ══════════════════════════════════════════════════════════════════════════════

def parse(question: str,
          context: Optional[list[dict]] = None,
          prev_summary: Optional[dict] = None) -> ParseResult:
    """
    Full 4-stage parse pipeline.
    Returns ParseResult with descriptor ready for SQLBuilder.
    """
    ctx   = context or []
    model = _get_best_model()

    # ── Stage 1: LLM intent classification ────────────────────────────────────
    stage1_data = None
    try:
        prompt      = _stage1_prompt(question, ctx, prev_summary)
        stage1_data = _call_ollama(prompt, model)
    except: pass

    # ── Handle non-data intents ────────────────────────────────────────────────
    if stage1_data:
        intent = stage1_data.get("intent", "data")

        if intent == "ui_command":
            return ParseResult(intent="ui_command",
                               ui_action=stage1_data.get("ui_action"),
                               raw_question=question, stage_used="llm",
                               confidence=0.99)

        if intent == "clarify":
            opts = []
            for o in (stage1_data.get("clarify_options") or []):
                mid = o.get("metric_id") or o.get("metric")
                opts.append(ClarifyOption(
                    label      = o.get("label", ""),
                    metric_id  = mid if mid in MetricRegistry.get_ids() else None,
                    time_range = _extract_time(question) or "last_30_days",
                    group_by   = _extract_dims(question),
                    filters    = {},
                ))
            return ParseResult(intent="clarify",
                               clarify_question=stage1_data.get("clarify_question",
                                   "Did you mean one of these?"),
                               clarify_options=opts,
                               raw_question=question, stage_used="llm")

        if intent == "unclear":
            msg  = stage1_data.get("unclear_message", "That question is outside my scope.")
            alts = _generate_alternatives(question)
            return ParseResult(intent="unclear",
                               unclear_message=msg,
                               unclear_suggestions=alts,
                               raw_question=question, stage_used="llm")

    # ── Stage 2: Python precision extraction ──────────────────────────────────
    inherit    = bool((stage1_data or {}).get("inherit_context", False))
    last       = ctx[-1] if (inherit and ctx) else {}

    raw_metric = (stage1_data or {}).get("metric_id") or (stage1_data or {}).get("metric")
    metric_id  = (raw_metric if raw_metric in MetricRegistry.get_ids()
                  else _fuzzy_metric(raw_metric))
    if not metric_id and inherit:
        metric_id = last.get("metric_id")

    time_range = (_extract_time(question)
                  or (last.get("time_range") if inherit else None)
                  or "last_30_days")

    dims       = _extract_dims(question)
    group_by   = (dims if dims
                  else list(last.get("group_by") or []) if inherit
                  else [])

    region  = _extract_region(question)
    product = _extract_product(question)
    limit   = _extract_limit(question)
    order   = _extract_order(question)

    base_filters = {k:v for k,v in (last.get("filters") or {}).items()
                    if inherit and k not in ("limit",)} if inherit else {}
    filters = dict(base_filters)
    if region:  filters["region"]  = region
    if product: filters["product"] = product
    if limit:   filters["limit"]   = limit
    filters["order"] = order

    # If no metric found — ask for clarification
    if not metric_id:
        alts = _generate_alternatives(question)
        return ParseResult(
            intent           = "clarify",
            clarify_question = "Which metric would you like to see?",
            clarify_options  = [ClarifyOption(label=MetricRegistry.get(m).display_name
                                              if MetricRegistry.get(m) else m,
                                              metric_id=m)
                                 for m in alts[:4]],
            raw_question     = question,
            stage_used       = "python" if not stage1_data else "llm+python",
        )

    # Detect computation hint from question text
    comp_hint = _detect_computation_hint(question)

    # ── Feasibility check (on-prem LLM) ───────────────────────────────────────
    spec = MetricRegistry.get(metric_id)
    feasibility_note = None
    computation      = comp_hint

    if spec:
        valid, err = MetricRegistry.validate_query(metric_id, group_by, filters)
        if not valid:
            alts = _generate_alternatives(question)
            return ParseResult(
                intent           = "unclear",
                unclear_message  = err,
                unclear_suggestions = alts,
                raw_question     = question,
                stage_used       = "validation",
            )

        # Ask on-prem LLM about feasibility and computation type
        try:
            all_metrics = "\n".join(
                f"- {m.metric_id}: {m.description}" for m in MetricRegistry.get_all()
            )
            f_prompt  = _feasibility_prompt(question, spec.to_llm_description(), all_metrics)
            f_result  = _call_ollama(f_prompt, model, max_tokens=300)

            if f_result:
                if not f_result.get("feasible", True):
                    alts = f_result.get("alternatives") or _generate_alternatives(question)
                    return ParseResult(
                        intent              = "unclear",
                        unclear_message     = f_result.get("reason",
                            "I can't answer that from the available metrics."),
                        unclear_suggestions = alts[:4],
                        raw_question        = question,
                        stage_used          = "feasibility",
                    )

                # Use LLM's computation assessment
                if f_result.get("needs_comparison"):  computation = "compare_periods"
                elif f_result.get("needs_trend"):     computation = "trend"
                elif f_result.get("needs_pct_of_total"): computation = "pct_of_total"

                feasibility_note = f_result.get("computation_description")
        except Exception as e:
            logger.debug(f"Feasibility check error (non-fatal): {e}")

    # ── Build descriptor ───────────────────────────────────────────────────────
    compare_to  = filters.pop("compare_to", None) or (
        _extract_compare_to(question) if computation == "compare_periods" else None
    )
    trend_grain = "quarter" if "quarter" in question.lower() else "month"

    descriptor = QueryDescriptor(
        metric_id    = metric_id,
        time_range   = time_range,
        group_by     = group_by,
        filters      = filters,
        computation  = computation,
        compare_to   = compare_to,
        trend_grain  = trend_grain,
        inherit_context = inherit,
        confidence   = float((stage1_data or {}).get("confidence", 0.8)),
        raw_question = question,
    )

    stage = "llm+python" if stage1_data else "python"
    return ParseResult(
        intent           = "data",
        descriptor       = descriptor,
        raw_question     = question,
        stage_used       = stage,
        confidence       = descriptor.confidence,
        feasibility_note = feasibility_note,
    )


def generate_narrative(question: str, metric_name: str,
                       time_range: str, results: list[dict],
                       format_type: str) -> str:
    """Generate plain English summary of results using on-prem LLM."""
    if not results: return ""

    # Format results as readable text (numbers only, no schema)
    from db.sql_builder import format_value
    lines = []
    for r in results[:10]:
        dim = r.get("dimension") or "Total"
        val = format_value(r.get("value", 0), format_type)
        if r.get("change_pct") is not None:
            chg = r["change_pct"]
            lines.append(f"{dim}: {val} ({'+' if chg >= 0 else ''}{chg}%)")
        elif r.get("pct_of_total") is not None:
            lines.append(f"{dim}: {val} ({r['pct_of_total']}% of total)")
        else:
            lines.append(f"{dim}: {val}")

    results_text = "\n".join(lines)
    model = _get_best_model()

    try:
        prompt   = _narrative_prompt(question, metric_name, time_range, results_text)
        response = requests.post(OLLAMA_URL, json={
            "model": model, "prompt": prompt, "stream": False,
            "options": {"temperature": 0.3, "num_predict": 150}
        }, timeout=15)
        return response.json().get("response", "").strip()
    except:
        return ""


# ── Helpers ────────────────────────────────────────────────────────────────────

def _fuzzy_metric(name: str) -> Optional[str]:
    if not name: return None
    n = name.lower().replace(" ","_").replace("-","_")
    metric_ids = MetricRegistry.get_ids()
    if n in metric_ids: return n
    for mid in metric_ids:
        if n in mid or mid in n: return mid
    # Check aliases
    ALIASES = {
        "revenue": "total_revenue", "income": "total_revenue",
        "sales": "total_revenue", "transactions": "transaction_count",
        "volume": "transaction_count", "churn": "churn_rate",
        "attrition": "churn_rate", "delinquency": "delinquency_rate",
        "defaults": "delinquency_rate", "npl": "delinquency_rate",
        "loans": "loan_count", "customers": "active_customers",
    }
    return ALIASES.get(n)


def _extract_compare_to(text: str) -> Optional[str]:
    lower = text.lower()
    if "previous quarter" in lower or "quarter before" in lower:
        return "last_quarter"
    if "previous year" in lower or "last year" in lower or "yoy" in lower:
        return "last_year"
    if "previous month" in lower or "month before" in lower:
        return "last_month"
    return None


def _generate_alternatives(question: str) -> list[str]:
    """Generate relevant metric alternatives based on question text."""
    lower   = question.lower()
    metrics = MetricRegistry.get_all()
    scored  = []

    for m in metrics:
        score = 0
        text  = (m.description + " " + " ".join(m.tags)).lower()
        words = set(re.findall(r'\b\w+\b', lower))
        for w in words:
            if w in text and len(w) > 3: score += 1
        if score > 0: scored.append((score, m.metric_id))

    scored.sort(reverse=True)
    if scored:
        return [m for _, m in scored[:4]]
    # Default: return first 4 metrics
    return [m.metric_id for m in metrics[:4]]
