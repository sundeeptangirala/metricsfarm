"""
BankMetric - GraphQL API (Strawberry + FastAPI)
Defines schema, resolvers, and dynamic SQL builder.
"""
import strawberry
from strawberry.fastapi import GraphQLRouter
from typing import Optional
import sqlite3

from db.database import get_connection
from parser.llm_parser import QueryObject, resolve_date_range


# ── GraphQL Types ──────────────────────────────────────────────────────────────

@strawberry.type
class MetricResult:
    dimension: Optional[str]
    value: float
    formatted_value: str


@strawberry.type
class MetricResponse:
    metric_name: str
    display_name: str
    time_range: str
    date_from: str
    date_to: str
    group_by: list[str]
    results: list[MetricResult]
    total: float
    formatted_total: str
    row_count: int
    sql_generated: str


@strawberry.type
class MetricDefinition:
    metric_name: str
    display_name: str
    description: str
    formula: str
    source_table: str
    allowed_dims: str
    owner: str
    status: str


@strawberry.type
class ValidationError:
    code: str
    message: str
    suggestion: str


@strawberry.type
class QueryResponse:
    success: bool
    response: Optional[MetricResponse]
    error: Optional[ValidationError]


# ── Metric SQL specs ───────────────────────────────────────────────────────────

METRIC_SQL = {
    "total_revenue": {
        "select":       "ROUND(SUM(t.amount), 2)",
        "table":        "transactions t",
        "join":         None,
        "date_col":     "t.transaction_date",
        "where":        "t.status = 'completed'",
        "display_name": "Total Revenue",
        "format":       "currency",
        "dims":         {"region": "t.region", "product": "t.product",
                         "channel": "t.channel",
                         "customer": "c.name JOIN customers c ON c.id = t.customer_id"},
    },
    "transaction_count": {
        "select":       "COUNT(*)",
        "table":        "transactions t",
        "join":         None,
        "date_col":     "t.transaction_date",
        "where":        "t.status = 'completed'",
        "display_name": "Transaction Count",
        "format":       "integer",
        "dims":         {"region": "t.region", "product": "t.product",
                         "channel": "t.channel",
                         "customer": "c.name JOIN customers c ON c.id = t.customer_id"},
    },
    "average_transaction": {
        "select":       "ROUND(AVG(t.amount), 2)",
        "table":        "transactions t",
        "join":         None,
        "date_col":     "t.transaction_date",
        "where":        "t.status = 'completed'",
        "display_name": "Avg Transaction Value",
        "format":       "currency",
        "dims":         {"region": "t.region", "product": "t.product", "channel": "t.channel"},
    },
    "revenue_per_customer": {
        "select":       "ROUND(SUM(t.amount), 2)",
        "table":        "transactions t",
        "join":         "JOIN customers c ON c.id = t.customer_id",
        "date_col":     "t.transaction_date",
        "where":        "t.status = 'completed'",
        "display_name": "Revenue per Customer",
        "format":       "currency",
        "dims":         {"customer": "c.name", "region": "c.region",
                         "product": "t.product", "channel": "t.channel"},
        # Always group by customer — this metric is meaningless without it
        "force_group_by": ["customer"],
        # Default to top 20 if no limit specified — avoid returning 2000 rows
        "default_limit":  20,
    },
    "active_customers": {
        "select":       "COUNT(*)",
        "table":        "customers c",
        "join":         None,
        "date_col":     "c.joined_date",
        "where":        "c.status = 'active'",
        "display_name": "Active Customers",
        "format":       "integer",
        "dims":         {"region": "c.region", "product": "c.product", "channel": "c.channel"},
    },
    "new_customers": {
        "select":       "COUNT(*)",
        "table":        "customers c",
        "join":         None,
        "date_col":     "c.joined_date",
        "where":        "1=1",
        "display_name": "New Customers",
        "format":       "integer",
        "dims":         {"region": "c.region", "product": "c.product", "channel": "c.channel"},
    },
    "churn_rate": {
        "select":       "ROUND(CAST(SUM(CASE WHEN c.status='churned' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) * 100, 2)",
        "table":        "customers c",
        "join":         None,
        "date_col":     "c.joined_date",
        "where":        "1=1",
        "display_name": "Churn Rate (%)",
        "format":       "percent",
        "dims":         {"region": "c.region", "product": "c.product"},
    },
    "total_loan_value": {
        "select":       "ROUND(SUM(l.amount), 2)",
        "table":        "loans l",
        "join":         None,
        "date_col":     "l.origination_date",
        "where":        "1=1",
        "display_name": "Total Loan Value",
        "format":       "currency",
        "dims":         {"region": "l.region", "product": "l.product"},
    },
    "loan_count": {
        "select":       "COUNT(*)",
        "table":        "loans l",
        "join":         None,
        "date_col":     "l.origination_date",
        "where":        "1=1",
        "display_name": "Loan Count",
        "format":       "integer",
        "dims":         {"region": "l.region", "product": "l.product"},
    },
    "delinquency_rate": {
        "select":       "ROUND(CAST(SUM(CASE WHEN l.status='delinquent' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) * 100, 2)",
        "table":        "loans l",
        "join":         None,
        "date_col":     "l.origination_date",
        "where":        "1=1",
        "display_name": "Delinquency Rate (%)",
        "format":       "percent",
        "dims":         {"region": "l.region", "product": "l.product"},
    },
}


def _format_value(v: float, fmt: str) -> str:
    if fmt == "currency":
        if v >= 1_000_000: return f"${v/1_000_000:.2f}M"
        if v >= 1_000:     return f"${v/1_000:.1f}K"
        return f"${v:,.2f}"
    if fmt == "percent":
        return f"{v:.2f}%"
    return f"{v:,.0f}"


# ── Core resolver ─────────────────────────────────────────────────────────────

def build_and_execute(query_obj: QueryObject) -> QueryResponse:
    conn = get_connection()

    if query_obj.metric not in METRIC_SQL:
        return QueryResponse(
            success=False, response=None,
            error=ValidationError(
                code="UNKNOWN_METRIC",
                message=f"Metric '{query_obj.metric}' is not defined.",
                suggestion=f"Available: {', '.join(METRIC_SQL.keys())}",
            ),
        )

    spec       = METRIC_SQL[query_obj.metric]
    table      = spec["table"]
    base_join  = spec["join"] or ""
    date_col   = spec["date_col"]
    base_where = spec["where"]
    fmt        = spec["format"]
    allowed    = spec["dims"]

    # ── Apply metric-level defaults ────────────────────────────────────
    # Some metrics always require a group_by (e.g. revenue_per_customer
    # is meaningless without grouping by customer).
    # Merge forced dims with any the user specified.
    forced_dims = spec.get("force_group_by", [])
    for fd in forced_dims:
        if fd not in query_obj.group_by:
            query_obj.group_by.insert(0, fd)

    # Apply default limit if metric has one and user did not specify one
    default_limit = spec.get("default_limit")
    if default_limit and "limit" not in query_obj.filters:
        query_obj.filters["limit"] = default_limit

    # ── Validate dimensions ────────────────────────────────────────────
    invalid = [d for d in query_obj.group_by if d not in allowed]
    if invalid:
        return QueryResponse(
            success=False, response=None,
            error=ValidationError(
                code="INVALID_DIMENSION",
                message=f"Dimension(s) {invalid} not available for '{query_obj.metric}'.",
                suggestion=f"Allowed: {list(allowed.keys())}",
            ),
        )

    # ── Date range ────────────────────────────────────────────────────
    date_from, date_to = resolve_date_range(
        query_obj.time_range or "last_30_days", query_obj.raw_text
    )

    # ── Build WHERE + params ───────────────────────────────────────────
    conditions = [
        base_where,
        f"{date_col} BETWEEN '{date_from}' AND '{date_to}'",
    ]
    params: list = []
    extra_joins = base_join

    for col, val in query_obj.filters.items():
        if col in ("limit", "order"):
            continue
        if col in allowed:
            dim_expr = allowed[col]
            # Some dims carry a JOIN clause inline (e.g. customer on total_revenue)
            if " JOIN " in dim_expr:
                col_name, join_clause = dim_expr.split(" JOIN ", 1)
                join_clause = "JOIN " + join_clause
                if join_clause not in extra_joins:
                    extra_joins = (extra_joins + " " + join_clause).strip()
                conditions.append(f"{col_name} = ?")
            else:
                conditions.append(f"{dim_expr} = ?")
            params.append(val)

    where_clause = " AND ".join(f"({c})" for c in conditions)

    # ── Build GROUP BY ─────────────────────────────────────────────────
    group_col_exprs = []
    for d in query_obj.group_by:
        dim_expr = allowed[d]
        if " JOIN " in dim_expr:
            col_name, join_clause = dim_expr.split(" JOIN ", 1)
            join_clause = "JOIN " + join_clause
            if join_clause not in extra_joins:
                extra_joins = (extra_joins + " " + join_clause).strip()
            group_col_exprs.append(col_name)
        else:
            group_col_exprs.append(dim_expr)

    order_dir = query_obj.filters.get("order", "DESC")

    if group_col_exprs:
        # Label: concatenate multiple dims with " / "
        if len(group_col_exprs) == 1:
            dim_label = group_col_exprs[0]
        else:
            dim_label = " || ' / ' || ".join(group_col_exprs)

        sql = (
            f"SELECT {dim_label} AS dimension, {spec['select']} AS value "
            f"FROM {table} {extra_joins} "
            f"WHERE {where_clause} "
            f"GROUP BY {', '.join(group_col_exprs)} "
            f"ORDER BY value {order_dir}"
        )
        if "limit" in query_obj.filters:
            sql += f" LIMIT {int(query_obj.filters['limit'])}"
    else:
        sql = (
            f"SELECT NULL AS dimension, {spec['select']} AS value "
            f"FROM {table} {extra_joins} "
            f"WHERE {where_clause}"
        )

    # ── Execute ───────────────────────────────────────────────────────
    try:
        cursor = conn.execute(sql, params)
        rows = cursor.fetchall()
    except sqlite3.Error as e:
        return QueryResponse(
            success=False, response=None,
            error=ValidationError(code="SQL_ERROR", message=str(e),
                                  suggestion="Check metric definition."),
        )

    results = [
        MetricResult(
            dimension=row["dimension"],
            value=row["value"] or 0.0,
            formatted_value=_format_value(row["value"] or 0.0, fmt),
        )
        for row in rows
    ]

    total = sum(r.value for r in results)
    if fmt == "percent" and results:
        total = total / len(results)

    TIME_LABELS = {
        "last_month": "Last Month", "this_month": "This Month",
        "last_quarter": "Last Quarter", "this_quarter": "This Quarter",
        "last_year": "Last Year", "this_year": "This Year",
        "year_to_date": "Year to Date", "last_30_days": "Last 30 Days",
        "last_90_days": "Last 90 Days", "today": "Today",
        "this_week": "This Week", "last_week": "Last Week",
    }
    time_label = TIME_LABELS.get(query_obj.time_range or "", query_obj.time_range or "")

    return QueryResponse(
        success=True, error=None,
        response=MetricResponse(
            metric_name=query_obj.metric,
            display_name=spec["display_name"],
            time_range=time_label,
            date_from=date_from,
            date_to=date_to,
            group_by=query_obj.group_by,
            results=results,
            total=total,
            formatted_total=_format_value(total, fmt),
            row_count=len(results),
            sql_generated=sql,
        ),
    )


# ── GraphQL Schema ─────────────────────────────────────────────────────────────

@strawberry.type
class Query:

    @strawberry.field
    def metric(
        self,
        name: str,
        time_range: str = "last_30_days",
        group_by: list[str] = strawberry.UNSET,
        filters: Optional[strawberry.scalars.JSON] = None,
    ) -> QueryResponse:
        qo = QueryObject(
            metric=name,
            time_range=time_range,
            group_by=group_by if group_by is not strawberry.UNSET else [],
            filters=filters or {},
        )
        return build_and_execute(qo)

    @strawberry.field
    def list_metrics(self) -> list[MetricDefinition]:
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM metric_registry WHERE status='published' ORDER BY metric_name"
        ).fetchall()
        return [
            MetricDefinition(
                metric_name=r["metric_name"], display_name=r["display_name"],
                description=r["description"] or "", formula=r["formula"],
                source_table=r["source_table"], allowed_dims=r["allowed_dims"],
                owner=r["owner"] or "", status=r["status"],
            )
            for r in rows
        ]


schema = strawberry.Schema(query=Query)
graphql_router = GraphQLRouter(schema)
