"""
BankMetric (Ollama) — Streamlit Chat UI
Shows which parser was used (LLM vs fallback) and confidence score.
Run: streamlit run streamlit_app/app.py
"""
import streamlit as st
import requests
import pandas as pd
import json

API_URL = "http://localhost:8000"

st.set_page_config(
    page_title="BankMetric — LLM",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.user-msg {
    background: #E8F4FD;
    border-left: 4px solid #0A8F8F;
    padding: 12px 16px;
    border-radius: 0 10px 10px 0;
    margin: 8px 0;
    font-size: 15px;
}
.bot-header {
    background: #F8F9FA;
    border-left: 4px solid #6C757D;
    padding: 12px 16px;
    border-radius: 0 10px 10px 0;
    margin: 8px 0 4px 0;
}
.error-msg {
    background: #FFF3F3;
    border-left: 4px solid #DC3545;
    padding: 12px 16px;
    border-radius: 0 10px 10px 0;
    margin: 8px 0;
}
.metric-total { font-size: 30px; font-weight: 700; color: #0A8F8F; }
.metric-label { font-size: 12px; color: #6B7D99; text-transform: uppercase; letter-spacing: 0.5px; }
.pill-llm { background: #E1F5EE; color: #085041; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; }
.pill-rule { background: #FAEEDA; color: #633806; padding: 2px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; }
.pill-conf { background: #E6F1FB; color: #0C447C; padding: 2px 8px; border-radius: 12px; font-size: 11px; }
</style>
""", unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────────
if "messages" not in st.session_state:
    st.session_state.messages = []
if "context" not in st.session_state:
    st.session_state.context = []
if "metrics_list" not in st.session_state:
    st.session_state.metrics_list = []


# ── API helpers ────────────────────────────────────────────────────────────────
def ask_api(question: str) -> dict:
    try:
        resp = requests.post(
            f"{API_URL}/ask",
            json={"question": question,
                  "conversation_context": st.session_state.context},
            timeout=35,   # LLM needs up to 30s
        )
        return resp.json()
    except requests.exceptions.Timeout:
        return {"success": False,
                "error": "Request timed out — Ollama is still loading the model.",
                "suggestion": "Wait a few seconds and try again."}
    except requests.exceptions.ConnectionError:
        return {"success": False,
                "error": "Cannot connect to BankMetric API.",
                "suggestion": "Run: python main.py"}
    except Exception as e:
        return {"success": False, "error": str(e), "suggestion": ""}


def get_ollama_status() -> dict:
    try:
        return requests.get(f"{API_URL}/ollama/status", timeout=3).json()
    except:
        return {"running": False, "status": "api_not_running"}


def load_metrics():
    try:
        return requests.get(f"{API_URL}/metrics", timeout=5).json()
    except:
        return []


# ── Render a metric response ───────────────────────────────────────────────────
def render_response(data: dict):
    if not data.get("success"):
        st.markdown(f"""
        <div class="error-msg">
            ❌ <strong>{data.get('error', 'Unknown error')}</strong><br>
            <small>{data.get('suggestion', '')}</small>
        </div>""", unsafe_allow_html=True)
        return

    results  = data.get("results", [])
    group_by = data.get("group_by", [])
    has_dims = bool(group_by) and results and results[0].get("dimension")
    group_label = " × ".join(group_by) if group_by else "Total"

    # Parser badge
    parser = data.get("parser_used", "llm")
    conf   = data.get("query_object", {}).get("confidence", 1.0)
    if parser == "llm":
        parser_badge = f'<span class="pill-llm">LLM</span> <span class="pill-conf">{int(conf*100)}% confidence</span>'
    else:
        parser_badge = '<span class="pill-rule">Rule-based fallback</span>'

    st.markdown(f"""
    <div class="bot-header">
        <div style="margin-bottom:4px">{parser_badge}</div>
        <span class="metric-label">{data.get('display_name','')} · {data.get('time_range','')}
        &nbsp;|&nbsp; {data.get('date_from','')} → {data.get('date_to','')}</span><br>
        <span class="metric-total">{data.get('formatted_total','')}</span>
        <span style="font-size:12px;color:#9CA3AF;margin-left:12px">
            {data.get('row_count',0)} {'rows' if has_dims else 'result'} · by {group_label}
        </span>
    </div>""", unsafe_allow_html=True)

    if has_dims and results:
        df = pd.DataFrame(results)
        df.columns = [group_label.title(), "Value", data.get("display_name", "Value")]
        df = df.sort_values("Value", ascending=False)

        col1, col2 = st.columns([1, 1])
        with col1:
            st.dataframe(
                df[[group_label.title(), data.get("display_name","Value")]],
                use_container_width=True, hide_index=True,
            )
        with col2:
            chart_df = df.set_index(group_label.title())[["Value"]]
            chart_df.columns = [data.get("display_name","Value")]
            st.bar_chart(chart_df, height=260)

    with st.expander("🔍 Query details — what the LLM understood", expanded=False):
        qo = data.get("query_object", {})
        c1, c2, c3, c4 = st.columns(4)
        c1.markdown(f"**Metric**\n`{qo.get('metric','')}`")
        c2.markdown(f"**Time**\n`{qo.get('time_range','')}`")
        c3.markdown(f"**Group by**\n`{', '.join(qo.get('group_by',[])) or 'none'}`")
        c4.markdown(f"**Filters**\n`{json.dumps(qo.get('filters',{}))}`")
        if data.get("sql_generated"):
            st.code(data["sql_generated"], language="sql")


def render_suggestions(data: dict):
    if not data.get("success"):
        return
    metric   = data.get("metric", "")
    group_by = data.get("group_by", [])
    suggestions = []

    if "customer" not in group_by:
        suggestions.append("Show top 10 customers by revenue")
    if "region" not in group_by:
        suggestions.append("Break it down by region")
    if "product" not in group_by:
        suggestions.append("Break it down by product")
    if "channel" not in group_by:
        suggestions.append("Which channel is most used?")

    tr = data.get("time_range", "")
    if "Quarter" in tr:
        suggestions.append("What about this quarter?")
    else:
        suggestions.append("Show me last quarter")

    if metric == "total_revenue":
        suggestions.append("Show transaction count")
    elif metric in ("total_loan_value", "loan_count"):
        suggestions.append("Show delinquency rate")
    elif metric == "active_customers":
        suggestions.append("What is the churn rate?")

    suggestions = suggestions[:4]
    if suggestions:
        st.markdown("**💡 Follow-up:**")
        cols = st.columns(len(suggestions))
        for i, s in enumerate(suggestions):
            if cols[i].button(s, key=f"s_{len(st.session_state.messages)}_{i}"):
                handle_question(s)
                st.rerun()


def handle_question(question: str):
    st.session_state.messages.append({"role": "user", "content": question})
    with st.spinner("🧠 Asking the LLM..."):
        data = ask_api(question)
    st.session_state.messages.append({
        "role": "assistant", "content": question, "data": data
    })
    if data.get("success"):
        st.session_state.context.append({
            "metric":     data.get("metric"),
            "time_range": data.get("query_object", {}).get("time_range"),
            "filters":    data.get("query_object", {}).get("filters", {}),
            "group_by":   data.get("group_by", []),
        })
        st.session_state.context = st.session_state.context[-5:]


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("📊 BankMetric")
    st.caption("Conversational Analytics · Ollama LLM")
    st.divider()

    # API + Ollama status
    try:
        health = requests.get(f"{API_URL}/health", timeout=3).json()
        st.success("✅ API connected")
        counts = health.get("counts", {})
        st.markdown(f"""
**Data:**
- 📊 {counts.get('transactions',0):,} transactions
- 👥 {counts.get('customers',0):,} customers
- 🏦 {counts.get('loans',0):,} loans
        """)

        # Ollama status
        ollama = health.get("ollama", {})
        st.divider()
        st.markdown("**🧠 Ollama LLM**")
        if ollama.get("running") and ollama.get("model_available"):
            st.success(f"✅ Ready — `{ollama.get('target_model')}`")
        elif ollama.get("running"):
            st.warning(f"⚠️ Running but model not pulled")
            st.code(f"ollama pull {ollama.get('target_model','llama3.2:3b')}")
        else:
            st.error("❌ Ollama not running")
            st.markdown("""
**To start Ollama on Mac:**
```bash
# Install (once)
brew install ollama

# Pull the model (once, ~2GB)
ollama pull llama3.2:3b

# Start the server
ollama serve
```
Using rule-based fallback parser until Ollama is running.
""")
    except:
        st.error("❌ API not reachable\n\nRun: `python main.py`")

    st.divider()

    # Model info
    st.markdown("**Parser behaviour**")
    st.markdown("""
- LLM understands any phrasing
- Handles follow-ups naturally  
- Grounded to your metric registry
- Falls back to rules if offline
    """)

    st.divider()

    # Metric registry
    st.markdown("**📐 Governed metrics**")
    if not st.session_state.metrics_list:
        st.session_state.metrics_list = load_metrics()
    for m in st.session_state.metrics_list:
        with st.expander(m.get("display_name", "")):
            st.caption(m.get("description", ""))
            st.code(m.get("formula", ""), language="sql")
            st.caption(f"📁 {m.get('source_table')} · 👤 {m.get('owner')}")

    st.divider()
    if st.button("🗑 Clear conversation"):
        st.session_state.messages = []
        st.session_state.context  = []
        st.rerun()


# ── Main chat area ─────────────────────────────────────────────────────────────
st.markdown("## 💬 Ask anything about your metrics")
st.caption("Powered by local Ollama LLM · No data leaves your machine")

if not st.session_state.messages:
    st.markdown("**Try these — or ask in your own words:**")
    examples = [
        "What was our total revenue last quarter?",
        "Show me the top 5 customers by revenue in North America",
        "Which product has the highest delinquency rate?",
        "How many active customers joined this year by region?",
        "What channel do customers use most?",
        "Show me loan value broken down by product and region",
        "What is our churn rate compared to last year?",
        "Which region grew the most last quarter?",
    ]
    cols = st.columns(3)
    for i, q in enumerate(examples):
        if cols[i % 3].button(q, key=f"ex_{i}", use_container_width=True):
            handle_question(q)
            st.rerun()
    st.divider()

# Chat history
for i, msg in enumerate(st.session_state.messages):
    if msg["role"] == "user":
        st.markdown(
            f'<div class="user-msg">👤 <strong>You:</strong> {msg["content"]}</div>',
            unsafe_allow_html=True
        )
    else:
        st.markdown("**📊 BankMetric:**")
        render_response(msg.get("data", {}))
        if i == len(st.session_state.messages) - 1:
            render_suggestions(msg.get("data", {}))

# Input
st.divider()
with st.form(key="chat_form", clear_on_submit=True):
    col1, col2 = st.columns([5, 1])
    with col1:
        user_input = st.text_input(
            "Ask anything...",
            placeholder="e.g. Which region had the strongest revenue growth last quarter?",
            label_visibility="collapsed",
        )
    with col2:
        submitted = st.form_submit_button("Ask →", use_container_width=True)
    if submitted and user_input.strip():
        handle_question(user_input.strip())
        st.rerun()
