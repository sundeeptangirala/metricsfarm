"""
BankMetric v5 — Test Suite
Tests registry, SQL builder, resolver, and parser.
All offline tests run without Ollama.
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from db.database import get_connection
from db.registry import MetricRegistry
from db.sql_builder import SQLBuilder, QueryDescriptor, resolve_date_range, format_value
from api.resolver import execute

conn = get_connection()
pass_n = fail_n = 0
failures = []

def test(label, cond, detail=""):
    global pass_n, fail_n
    if cond:
        pass_n += 1; print(f"  ✅ {label}")
    else:
        fail_n += 1; failures.append(f"{label}: {detail}"); print(f"  ❌ {label} — {detail}")

print("\n── Registry ──────────────────────────────────────────────────")
metrics = MetricRegistry.get_all()
test("100 metrics loaded",             len(metrics) == 100, f"got {len(metrics)}")
test("All have descriptions",          all(m.description for m in metrics))
test("All have select_expression",     all(m.select_expression for m in metrics))
test("All have allowed_dimensions",    all(m.allowed_dimensions for m in metrics))
test("All have business_questions",    all(m.business_questions for m in metrics))
test("Fuzzy metric lookup",            MetricRegistry.get("total_revenue") is not None)
test("LLM vocabulary has no schema",   "SELECT" not in MetricRegistry.get_llm_vocabulary())
test("LLM vocabulary has descriptions",
     "revenue" in MetricRegistry.get_llm_vocabulary().lower())

vocab = MetricRegistry.get_llm_vocabulary()
# Check that SQL schema constructs are hidden (not English words that happen to match)
# Check SQL column references not in vocab (table aliases ok in example questions)
SQL_COL_REFS = ["t.amount", "t.region", "l.amount", "l.region",
                "c.name", "c.region", "d.amount", "f.amount"]
for bad in SQL_COL_REFS:
    test(f"Schema hidden: '{bad}'", bad not in vocab, f"found in vocab")

print("\n── Date resolution ────────────────────────────────────────────")
for tr in ["last_quarter","last_month","last_year","this_month","this_quarter",
           "this_year","year_to_date","last_30_days","last_90_days","today",
           "this_week","last_week"]:
    d1,d2 = resolve_date_range(tr)
    test(f"Date: {tr}", bool(d1) and bool(d2) and d1 <= d2, f"{d1}→{d2}")

print("\n── SQL Builder: simple aggregates ─────────────────────────────")
for mid in MetricRegistry.get_ids():
    spec = MetricRegistry.get(mid)
    desc = QueryDescriptor(metric_id=mid, time_range="last_quarter")
    sql, params = SQLBuilder.build(spec, desc)
    test(f"SQL builds: {mid}", bool(sql) and "SELECT" in sql)
    # SQL preview must not contain actual table names
    preview = SQLBuilder.preview(spec, desc)
    # Check that table.column references are hidden (e.g. c.region, t.amount)
    # The word itself may appear in metric names/labels which is fine
    alias = spec.primary_alias
    schema_refs = [f"{alias}.region", f"{alias}.amount", f"{alias}.status",
                   f"{alias}.product", f"{alias}.channel"]
    has_schema = any(ref in preview for ref in schema_refs)
    test(f"Preview hides column refs: {mid}", not has_schema,
         f"column reference found in preview")

print("\n── SQL Builder: with dimensions ───────────────────────────────")
dim_tests = [
    ("total_revenue",     "region",   "last_quarter"),
    ("total_revenue",     "product",  "this_year"),
    ("total_revenue",     "channel",  "last_month"),
    ("revenue_per_customer","customer","last_quarter"),
    ("active_customers",  "region",   "this_month"),
    ("delinquency_rate",  "product",  "last_year"),
    ("churn_rate",        "region",   "this_year"),
    ("total_loan_value",  "product",  "last_quarter"),
]
for mid, dim, tr in dim_tests:
    spec = MetricRegistry.get(mid)
    desc = QueryDescriptor(metric_id=mid, time_range=tr, group_by=[dim])
    sql, _ = SQLBuilder.build(spec, desc)
    test(f"SQL: {mid} by {dim}", "GROUP BY" in sql)

print("\n── SQL Builder: computation types ─────────────────────────────")
spec = MetricRegistry.get("total_revenue")

desc_comp = QueryDescriptor(metric_id="total_revenue", time_range="last_quarter",
                             group_by=["region"], computation="compare_periods")
sql, _ = SQLBuilder.build(spec, desc_comp)
test("compare_periods SQL builds", "change_pct" in sql or "current_value" in sql)
test("compare_periods has two date ranges", sql.count("BETWEEN") >= 2)

desc_pct = QueryDescriptor(metric_id="total_revenue", time_range="last_quarter",
                            group_by=["region"], computation="pct_of_total")
sql, _ = SQLBuilder.build(spec, desc_pct)
test("pct_of_total SQL builds", "pct_of_total" in sql or "OVER" in sql)

desc_trend = QueryDescriptor(metric_id="total_revenue", time_range="last_year",
                              computation="trend", trend_grain="month")
sql, _ = SQLBuilder.build(spec, desc_trend)
test("trend SQL builds", "strftime" in sql.lower() or "period" in sql.lower())

print("\n── Resolver: all metrics ──────────────────────────────────────")
for mid in MetricRegistry.get_ids():
    desc = QueryDescriptor(metric_id=mid, time_range="last_quarter")
    r = execute(desc)
    test(f"Resolver: {mid}", r.success, r.error or "")
    if r.success:
        test(f"  Result has rows",    r.row_count >= 0)
        test(f"  Has formatted total", bool(r.formatted_total))
        test(f"  Has display name",   bool(r.display_name))

print("\n── Resolver: revenue_per_customer defaults ─────────────────────")
desc = QueryDescriptor(metric_id="revenue_per_customer", time_range="last_quarter")
r = execute(desc)
test("Default: 20 rows",       r.row_count == 20, f"got {r.row_count}")
test("Default: customer dim",  "customer" in r.group_by, f"got {r.group_by}")
test("No slash in names",      all("/" not in (row.get("dimension") or "") for row in r.rows))

desc5 = QueryDescriptor(metric_id="revenue_per_customer", time_range="last_quarter",
                         filters={"limit":5})
r5 = execute(desc5)
test("User limit=5 respected", r5.row_count == 5, f"got {r5.row_count}")

desc_reg = QueryDescriptor(metric_id="revenue_per_customer", time_range="last_quarter",
                            group_by=["region"])
r_reg = execute(desc_reg)
test("By region: 4 rows",      r_reg.row_count == 4, f"got {r_reg.row_count}")
test("By region: no slash",    all("/" not in (row.get("dimension") or "") for row in r_reg.rows))

print("\n── Resolver: region filter ────────────────────────────────────")
desc_na = QueryDescriptor(metric_id="total_revenue", time_range="last_quarter",
                           filters={"region":"North America"})
r_na = execute(desc_na)
test("Region filter: North America", r_na.success and r_na.row_count == 1,
     r_na.error or f"rows={r_na.row_count}")

print("\n── Resolver: computation types ────────────────────────────────")
desc_cmp = QueryDescriptor(metric_id="total_revenue", time_range="last_quarter",
                            group_by=["region"], computation="compare_periods")
r_cmp = execute(desc_cmp)
test("compare_periods executes", r_cmp.success, r_cmp.error or "")
if r_cmp.success and r_cmp.rows:
    test("compare_periods has current_value",
         "current_value" in r_cmp.rows[0] or "value" in r_cmp.rows[0])

desc_pct = QueryDescriptor(metric_id="total_revenue", time_range="last_quarter",
                            group_by=["region"], computation="pct_of_total")
r_pct = execute(desc_pct)
test("pct_of_total executes", r_pct.success, r_pct.error or "")

desc_trd = QueryDescriptor(metric_id="total_revenue", time_range="last_year",
                            computation="trend", trend_grain="month")
r_trd = execute(desc_trd)
test("trend executes", r_trd.success, r_trd.error or "")
if r_trd.success:
    test("trend has multiple periods", r_trd.row_count > 1, f"got {r_trd.row_count}")

print("\n── Validation ─────────────────────────────────────────────────")
valid, err = MetricRegistry.validate_query("total_revenue", ["region"], {})
test("Valid query passes",    valid)
valid, err = MetricRegistry.validate_query("unknown_metric", [], {})
test("Unknown metric fails",  not valid)
valid, err = MetricRegistry.validate_query("churn_rate", ["channel"], {})
test("Invalid dim fails",     not valid, f"channel not valid for churn_rate")
valid, err = MetricRegistry.validate_query("total_revenue", [], {"region":"Mars"})
test("Invalid region fails",  not valid)

print("\n── Format values ──────────────────────────────────────────────")
test("Currency M",  format_value(1500000, "currency") == "$1.50M")
test("Currency K",  format_value(1500, "currency") == "$1.5K")
test("Currency $",  "$" in format_value(500, "currency"))
test("Percent",     "%" in format_value(12.5, "percent"))
test("Integer",     "," in format_value(1000, "integer") or format_value(1000,"integer")=="1,000")

print("\n── Registry CRUD ──────────────────────────────────────────────")
test_metric = {
    "metric_id":         "test_metric_v5",
    "display_name":      "Test Metric",
    "description":       "A test metric for validation",
    "long_description":  "Extended description",
    "business_questions":["How many tests pass?"],
    "category":          "other",
    "tags":              ["test"],
    "business_owner":    "Test Team",
    "data_steward":      "Test Team",
    "tier":              4,
    "status":            "draft",
    "select_expression": "COUNT(*)",
    "is_ratio":          0,
    "primary_table":     "transactions",
    "primary_alias":     "t",
    "base_filter":       "1=1",
    "date_column":       "t.transaction_date",
    "base_joins":        [],
    "allowed_dimensions":{"region":"t.region"},
    "dimension_joins":   {},
    "force_group_by":    [],
    "default_limit":     None,
    "default_sort":      "DESC",
    "format_type":       "integer",
    "unit":              "count",
}
ok, msg = MetricRegistry.save(test_metric)
test("Save new metric",   ok, msg)
test("Loads after save",  MetricRegistry.get("test_metric_v5") is not None)
# Update
test_metric["description"] = "Updated description"
ok2, _ = MetricRegistry.save(test_metric)
test("Update metric",     ok2)
spec = MetricRegistry.get("test_metric_v5")
test("Version incremented", spec.version >= 2 if spec else False)
# Delete
ok3, _ = MetricRegistry.delete("test_metric_v5")
test("Delete metric",     ok3)
MetricRegistry.invalidate_cache()
test("Gone after delete",
     MetricRegistry.get("test_metric_v5") is None or
     MetricRegistry.get("test_metric_v5").status == "deleted")

print(f"\n{'═'*60}")
print(f"  RESULTS: {pass_n} passed  {fail_n} failed")
print(f"{'═'*60}")
if failures:
    print("\nFailed:")
    for f in failures: print(f"  ❌ {f}")
print()
