"""
BankMetric v5 — Resolver

Executes queries built by SQLBuilder.
The only component that touches the database after parsing.
"""
import sqlite3
import json
from dataclasses import dataclass, field
from typing import Optional

from db.database import get_connection
from db.registry import MetricRegistry
from db.sql_builder import SQLBuilder, QueryDescriptor, format_value


@dataclass
class QueryResult:
    success:         bool
    metric_id:       str              = ""
    display_name:    str              = ""
    time_range:      str              = ""
    date_from:       str              = ""
    date_to:         str              = ""
    group_by:        list[str]        = field(default_factory=list)
    computation:     str              = "simple"
    rows:            list[dict]       = field(default_factory=list)
    total:           float            = 0.0
    formatted_total: str              = ""
    row_count:       int              = 0
    sql_preview:     str              = ""   # schema-safe preview only
    empty_note:      str              = ""
    error:           Optional[str]    = None
    format_type:     str              = "number"


def execute(desc: QueryDescriptor) -> QueryResult:
    """Execute a QueryDescriptor. Returns structured results."""
    conn = get_connection()

    spec = MetricRegistry.get(desc.metric_id)
    if not spec:
        return QueryResult(success=False, metric_id=desc.metric_id,
                           error=f"Metric '{desc.metric_id}' not found in registry.")

    # Validate
    valid, err = MetricRegistry.validate_query(desc.metric_id, desc.group_by, desc.filters)
    if not valid:
        return QueryResult(success=False, metric_id=desc.metric_id, error=err)

    # Build SQL
    try:
        sql, params = SQLBuilder.build(spec, desc)
        sql_preview = SQLBuilder.preview(spec, desc)
    except Exception as e:
        return QueryResult(success=False, metric_id=desc.metric_id,
                           error=f"Failed to build query: {str(e)}")

    # Resolve dates for display
    from db.sql_builder import resolve_date_range
    date_from, date_to = resolve_date_range(desc.time_range)

    # Execute
    try:
        raw_rows = conn.execute(sql, params).fetchall()
    except sqlite3.Error as e:
        return QueryResult(success=False, metric_id=desc.metric_id,
                           error=f"Query execution error: {str(e)}")

    # Handle empty results
    empty_note = ""
    if not raw_rows:
        if desc.time_range in ("today","this_week"):
            empty_note = (f"No data found for '{desc.time_range}'. "
                         f"Demo data is historical — try 'last quarter' or 'last 30 days'.")
        else:
            f_str = ", ".join(f"{k}={v}" for k,v in desc.filters.items()
                              if k not in ("limit","order") and v)
            empty_note = (f"No data found"
                         + (f" for {f_str}" if f_str else "")
                         + f" in {desc.time_range}. "
                         + "Try a different time period or remove filters.")

    # Format rows
    rows = []
    for row in raw_rows:
        r = dict(row)
        row_out = {}
        # Standard columns
        row_out["dimension"]  = r.get("dimension")
        row_out["value"]      = r.get("value") or 0.0
        row_out["formatted"]  = format_value(row_out["value"], spec.format_type)
        # Comparison columns
        if "current_value"  in r: row_out["current_value"]  = r["current_value"]
        if "previous_value" in r: row_out["previous_value"] = r["previous_value"]
        if "change_pct"     in r: row_out["change_pct"]     = r["change_pct"]
        if "pct_of_total"   in r: row_out["pct_of_total"]   = r["pct_of_total"]
        # Format comparison values
        if "current_value"  in row_out:
            row_out["formatted_current"]  = format_value(row_out["current_value"], spec.format_type)
        if "previous_value" in row_out:
            row_out["formatted_previous"] = format_value(row_out["previous_value"], spec.format_type)
        rows.append(row_out)

    # Calculate totals
    if desc.computation == "compare_periods":
        total = sum(r.get("current_value", 0) or 0 for r in rows)
    else:
        total = sum(r["value"] for r in rows)

    if spec.is_ratio and rows:
        total = total / len(rows)

    # Time label
    TIME_LABELS = {
        "last_month":"Last Month","this_month":"This Month",
        "last_quarter":"Last Quarter","this_quarter":"This Quarter",
        "last_year":"Last Year","this_year":"This Year",
        "year_to_date":"Year to Date","last_30_days":"Last 30 Days",
        "last_90_days":"Last 90 Days","today":"Today",
        "this_week":"This Week","last_week":"Last Week",
    }
    time_label = TIME_LABELS.get(desc.time_range, desc.time_range)

    # Log to audit
    _log_audit(desc, len(rows))

    return QueryResult(
        success         = True,
        metric_id       = spec.metric_id,
        display_name    = spec.display_name,
        time_range      = time_label,
        date_from       = date_from,
        date_to         = date_to,
        group_by        = desc.group_by if desc.group_by else list(spec.force_group_by),
        computation     = desc.computation,
        rows            = rows,
        total           = total,
        formatted_total = format_value(total, spec.format_type),
        row_count       = len(rows),
        sql_preview     = sql_preview,
        empty_note      = empty_note,
        format_type     = spec.format_type,
    )


def _log_audit(desc: QueryDescriptor, row_count: int):
    try:
        conn = get_connection()
        conn.execute("""
            INSERT INTO query_audit
            (question, metric_id, time_range, group_by, filters,
             computation, row_count, queried_at)
            VALUES (?,?,?,?,?,?,?,datetime('now'))
        """, (desc.raw_question, desc.metric_id, desc.time_range,
              json.dumps(desc.group_by), json.dumps(desc.filters),
              desc.computation, row_count))
        conn.commit()
    except: pass
