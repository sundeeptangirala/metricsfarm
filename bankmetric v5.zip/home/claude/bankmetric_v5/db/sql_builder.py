"""
BankMetric v5 — SQL Builder

Builds SQL from metric registry spec + query description.
This is the ONLY place SQL is constructed.
Never exposed to any LLM — internal only.

Handles:
  - Simple aggregates (SUM/COUNT/AVG by dimension)
  - Period over period comparison
  - Percentage of total
  - Trend over time (by month/quarter)
  - Ranking within group
  - Any combination of the above
"""
import json
from datetime import date, timedelta
from dataclasses import dataclass, field
from typing import Optional
from db.registry import MetricSpec


# ── Date resolution ────────────────────────────────────────────────────────────

def resolve_date_range(time_range: str) -> tuple[str, str]:
    today = date.today()
    def qs(d): return date(d.year, ((d.month-1)//3)*3+1, 1)
    def ms(d): return date(d.year, d.month, 1)

    if time_range == "last_quarter":
        e = qs(today)-timedelta(1); return qs(e).isoformat(), e.isoformat()
    if time_range == "last_month":
        e = ms(today)-timedelta(1); return ms(e).isoformat(), e.isoformat()
    if time_range == "last_year":
        return date(today.year-1,1,1).isoformat(), date(today.year-1,12,31).isoformat()
    if time_range == "last_week":
        e = today - timedelta(days=today.weekday()+1)
        return (e-timedelta(6)).isoformat(), e.isoformat()

    MAP = {
        "today":        (today, today),
        "this_week":    (today-timedelta(days=today.weekday()), today),
        "this_month":   (ms(today), today),
        "this_quarter": (qs(today), today),
        "this_year":    (date(today.year,1,1), today),
        "year_to_date": (date(today.year,1,1), today),
        "last_30_days": (today-timedelta(30), today),
        "last_90_days": (today-timedelta(90), today),
    }
    if time_range in MAP:
        s, e = MAP[time_range]; return s.isoformat(), e.isoformat()
    return (today-timedelta(30)).isoformat(), today.isoformat()


def get_previous_period(time_range: str) -> str:
    """Get the equivalent previous period for comparison."""
    MAP = {
        "last_quarter":  "last_quarter_prev_year",
        "this_quarter":  "last_quarter",
        "last_month":    "last_month_prev_year",
        "this_month":    "last_month",
        "this_year":     "last_year",
        "last_year":     "two_years_ago",
        "last_30_days":  "prev_30_days",
        "last_90_days":  "prev_90_days",
        "year_to_date":  "year_to_date_prev_year",
    }
    return MAP.get(time_range, "last_year")


def resolve_comparison_dates(time_range: str, compare_to: str) -> tuple[str,str,str,str]:
    """Resolve both current and comparison period date ranges."""
    d_from, d_to = resolve_date_range(time_range)

    if compare_to in ("last_quarter","this_quarter","last_month","this_month",
                       "last_year","this_year","year_to_date","last_30_days","last_90_days"):
        c_from, c_to = resolve_date_range(compare_to)
    elif compare_to == "prev_30_days":
        td = date.today()
        c_to   = (td-timedelta(31)).isoformat()
        c_from = (td-timedelta(60)).isoformat()
    elif compare_to == "prev_90_days":
        td = date.today()
        c_to   = (td-timedelta(91)).isoformat()
        c_from = (td-timedelta(180)).isoformat()
    elif compare_to == "last_quarter_prev_year":
        d1, d2 = resolve_date_range("last_quarter")
        y = date.fromisoformat(d1).year - 1
        m = date.fromisoformat(d1).month
        from datetime import date as dt
        c_from = dt(y, m, 1).isoformat()
        c_to   = (dt(y, m+3, 1) - timedelta(1)).isoformat() if m <= 9 else dt(y,12,31).isoformat()
    else:
        c_from, c_to = resolve_date_range("last_year")

    return d_from, d_to, c_from, c_to


# ── Query descriptor ───────────────────────────────────────────────────────────

@dataclass
class QueryDescriptor:
    """
    Describes what to compute — in governed vocabulary.
    Built by the parser + LLM, executed by SQLBuilder.
    No SQL, no schema, no table names.
    """
    metric_id:      str
    time_range:     str             = "last_30_days"
    group_by:       list[str]       = field(default_factory=list)
    filters:        dict            = field(default_factory=dict)
    # Computation type — described by on-prem LLM from question
    computation:    str             = "simple"
    # "simple" | "compare_periods" | "pct_of_total" | "trend" | "rank_within"
    compare_to:     Optional[str]   = None   # for compare_periods
    trend_grain:    str             = "month" # for trend: month|quarter
    inherit_context: bool           = False
    confidence:     float           = 1.0
    raw_question:   str             = ""


# ── SQL Builder ────────────────────────────────────────────────────────────────

class SQLBuilder:
    """
    Builds SQL from a MetricSpec + QueryDescriptor.
    The only class that knows SQL syntax.
    Never called by any LLM — internal only.
    """

    @staticmethod
    def build(spec: MetricSpec, desc: QueryDescriptor) -> tuple[str, list]:
        """
        Returns (sql, params).
        Dispatches to the appropriate builder based on computation type.
        """
        comp = desc.computation

        if comp == "compare_periods":
            return SQLBuilder._compare_periods(spec, desc)
        elif comp == "pct_of_total":
            return SQLBuilder._pct_of_total(spec, desc)
        elif comp == "trend":
            return SQLBuilder._trend(spec, desc)
        elif comp == "rank_within":
            return SQLBuilder._rank_within(spec, desc)
        else:
            return SQLBuilder._simple(spec, desc)

    @staticmethod
    def _get_dims(spec: MetricSpec) -> dict:
        """Get allowed_dimensions as dict, handling JSON string case."""
        import json as _json
        d = spec.allowed_dimensions
        if isinstance(d, str):
            try: d = _json.loads(d)
            except: d = {}
        return d if isinstance(d, dict) else {}

    @staticmethod
    def _build_base(spec: MetricSpec, desc: QueryDescriptor,
                    time_range: Optional[str] = None) -> tuple[str, str, str, list]:
        """
        Build base SQL components used by all builders.
        Returns (select_expr, from_clause, where_clause, params)
        """
        tr       = time_range or desc.time_range
        d_from, d_to = resolve_date_range(tr)

        # Build FROM + JOINs
        from_clause  = f"{spec.primary_table} {spec.primary_alias}"
        joins_added  = set()

        # Base joins from spec
        for j in spec.base_joins:
            joins_added.add(j["sql"])
            from_clause += f" {j['sql']}"

        # Dimension joins needed
        group_by = desc.group_by if desc.group_by else (list(spec.force_group_by) if isinstance(spec.force_group_by, list) else [])
        for dim in group_by:
            join_sql = spec.dimension_joins.get(dim)
            if join_sql and join_sql not in joins_added:
                joins_added.add(join_sql)
                from_clause += f" {join_sql}"

        # Build WHERE
        conditions = [
            f"({spec.base_filter})",
            f"({spec.date_column} BETWEEN '{d_from}' AND '{d_to}')"
        ]
        params = []
        for col, val in desc.filters.items():
            if col in ("limit", "order", "compare_to"): continue
            sql_expr = SQLBuilder._get_dims(spec).get(col)
            if sql_expr:
                conditions.append(f"({sql_expr} = ?)")
                params.append(val)

        where_clause = " AND ".join(conditions)
        return spec.select_expression, from_clause, where_clause, params

    @staticmethod
    def _simple(spec: MetricSpec, desc: QueryDescriptor) -> tuple[str, list]:
        """Standard aggregate — what we've always had."""
        sel, frm, where, params = SQLBuilder._build_base(spec, desc)

        group_by     = desc.group_by if desc.group_by else (list(spec.force_group_by) if isinstance(spec.force_group_by, list) else [])
        user_limit   = desc.filters.get("limit")
        effective_limit = (int(user_limit) if user_limit is not None
                          else (spec.default_limit if not desc.group_by and spec.default_limit
                                else None))
        order = str(desc.filters.get("order", spec.default_sort)).upper()
        if order not in ("ASC","DESC"): order = "DESC"

        group_exprs = [SQLBuilder._get_dims(spec)[d] for d in group_by
                      if d in SQLBuilder._get_dims(spec)]

        if group_exprs:
            dim = (group_exprs[0] if len(group_exprs)==1
                   else " || ' / ' || ".join(group_exprs))
            sql = (f"SELECT {dim} AS dimension, {sel} AS value "
                  f"FROM {frm} WHERE {where} "
                  f"GROUP BY {', '.join(group_exprs)} ORDER BY value {order}")
            if effective_limit: sql += f" LIMIT {effective_limit}"
        else:
            sql = f"SELECT NULL AS dimension, {sel} AS value FROM {frm} WHERE {where}"

        return sql, params

    @staticmethod
    def _compare_periods(spec: MetricSpec, desc: QueryDescriptor) -> tuple[str, list]:
        """Compare current period to previous period."""
        compare_to = desc.compare_to or get_previous_period(desc.time_range)
        d_from, d_to, c_from, c_to = resolve_comparison_dates(desc.time_range, compare_to)

        group_by    = desc.group_by if desc.group_by else (list(spec.force_group_by) if isinstance(spec.force_group_by, list) else [])
        group_exprs = [SQLBuilder._get_dims(spec)[d] for d in group_by
                      if d in SQLBuilder._get_dims(spec)]

        # Build joins
        base_joins  = " ".join(j["sql"] for j in spec.base_joins)
        dim_joins   = " ".join(spec.dimension_joins.get(d, "")
                               for d in group_by if d in spec.dimension_joins)
        all_joins   = f"{base_joins} {dim_joins}".strip()

        # Filters
        filter_conditions = []
        params_curr = []
        params_prev = []
        for col, val in desc.filters.items():
            if col in ("limit","order","compare_to"): continue
            sql_expr = SQLBuilder._get_dims(spec).get(col)
            if sql_expr:
                filter_conditions.append(f"({sql_expr} = ?)")
                params_curr.append(val)
                params_prev.append(val)

        base_where = f"({spec.base_filter})"
        extra      = (" AND " + " AND ".join(filter_conditions)) if filter_conditions else ""

        if group_exprs:
            dim_sql  = (group_exprs[0] if len(group_exprs)==1
                       else " || ' / ' || ".join(group_exprs))
            group_sql = ", ".join(group_exprs)

            sql = f"""
SELECT
    COALESCE(curr.dimension, prev.dimension) AS dimension,
    COALESCE(curr.value, 0)                  AS current_value,
    COALESCE(prev.value, 0)                  AS previous_value,
    CASE WHEN COALESCE(prev.value, 0) = 0 THEN NULL
         ELSE ROUND((COALESCE(curr.value,0) - COALESCE(prev.value,0))
                    / prev.value * 100, 1)
    END AS change_pct
FROM (
    SELECT {dim_sql} AS dimension, {spec.select_expression} AS value
    FROM {spec.primary_table} {spec.primary_alias} {all_joins}
    WHERE {base_where}
      AND ({spec.date_column} BETWEEN '{d_from}' AND '{d_to}')
      {extra}
    GROUP BY {group_sql}
) curr
FULL OUTER JOIN (
    SELECT {dim_sql} AS dimension, {spec.select_expression} AS value
    FROM {spec.primary_table} {spec.primary_alias} {all_joins}
    WHERE {base_where}
      AND ({spec.date_column} BETWEEN '{c_from}' AND '{c_to}')
      {extra}
    GROUP BY {group_sql}
) prev ON curr.dimension = prev.dimension
ORDER BY COALESCE(curr.value, 0) DESC
"""
        else:
            sql = f"""
SELECT
    'Total' AS dimension,
    curr.value  AS current_value,
    prev.value  AS previous_value,
    CASE WHEN prev.value = 0 THEN NULL
         ELSE ROUND((curr.value - prev.value) / prev.value * 100, 1)
    END AS change_pct
FROM (
    SELECT {spec.select_expression} AS value
    FROM {spec.primary_table} {spec.primary_alias} {all_joins}
    WHERE {base_where}
      AND ({spec.date_column} BETWEEN '{d_from}' AND '{d_to}')
) curr,
(
    SELECT {spec.select_expression} AS value
    FROM {spec.primary_table} {spec.primary_alias} {all_joins}
    WHERE {base_where}
      AND ({spec.date_column} BETWEEN '{c_from}' AND '{c_to}')
) prev
"""
        return sql.strip(), params_curr + params_prev

    @staticmethod
    def _pct_of_total(spec: MetricSpec, desc: QueryDescriptor) -> tuple[str, list]:
        """Each dimension's value as % of grand total."""
        sel, frm, where, params = SQLBuilder._build_base(spec, desc)
        group_by    = desc.group_by if desc.group_by else (list(spec.force_group_by) if isinstance(spec.force_group_by, list) else [])
        group_exprs = [SQLBuilder._get_dims(spec)[d] for d in group_by
                      if d in SQLBuilder._get_dims(spec)]

        if not group_exprs:
            return SQLBuilder._simple(spec, desc)

        dim  = group_exprs[0] if len(group_exprs)==1 else " || '/' || ".join(group_exprs)
        grp  = ", ".join(group_exprs)
        sql  = f"""
SELECT
    {dim} AS dimension,
    {sel} AS value,
    ROUND({sel} * 100.0 / SUM({sel}) OVER (), 1) AS pct_of_total
FROM {frm}
WHERE {where}
GROUP BY {grp}
ORDER BY value DESC
"""
        return sql.strip(), params

    @staticmethod
    def _trend(spec: MetricSpec, desc: QueryDescriptor) -> tuple[str, list]:
        """Aggregate by time period (month or quarter)."""
        _, frm, where, params = SQLBuilder._build_base(spec, desc)

        grain = desc.trend_grain or "month"
        if grain == "quarter":
            period_expr = (f"CAST(strftime('%Y', {spec.date_column}) AS TEXT) || '-Q' || "
                          f"CAST((CAST(strftime('%m', {spec.date_column}) AS INTEGER) + 2) / 3 AS TEXT)")
        else:
            period_expr = f"strftime('%Y-%m', {spec.date_column})"

        sql = (f"SELECT {period_expr} AS dimension, "
              f"{spec.select_expression} AS value "
              f"FROM {frm} WHERE {where} "
              f"GROUP BY {period_expr} ORDER BY dimension ASC")
        return sql, params

    @staticmethod
    def _rank_within(spec: MetricSpec, desc: QueryDescriptor) -> tuple[str, list]:
        """Top N within each group."""
        sel, frm, where, params = SQLBuilder._build_base(spec, desc)
        group_by    = desc.group_by if desc.group_by else (list(spec.force_group_by) if isinstance(spec.force_group_by, list) else [])
        group_exprs = [SQLBuilder._get_dims(spec)[d] for d in group_by
                      if d in SQLBuilder._get_dims(spec)]

        if len(group_exprs) < 2:
            return SQLBuilder._simple(spec, desc)

        outer_dim = group_exprs[0]
        inner_dim = group_exprs[1]
        limit     = desc.filters.get("limit", 1)
        grp       = ", ".join(group_exprs)

        sql = f"""
SELECT
    {outer_dim} || ' / ' || {inner_dim} AS dimension,
    value
FROM (
    SELECT
        {outer_dim},
        {inner_dim},
        {sel} AS value,
        ROW_NUMBER() OVER (PARTITION BY {outer_dim} ORDER BY {sel} DESC) AS rn
    FROM {frm}
    WHERE {where}
    GROUP BY {grp}
)
WHERE rn <= {limit}
ORDER BY {outer_dim}, value DESC
"""
        return sql.strip(), params

    @staticmethod
    def preview(spec: MetricSpec, desc: QueryDescriptor) -> str:
        """
        Returns a SAFE preview of the SQL for the self-check LLM call.
        Replaces actual table/column names with aliases for security.
        The LLM sees the structure, not the schema.
        """
        sql, _ = SQLBuilder.build(spec, desc)
        # Replace actual table names with [table] and column names with [column]
        # so the LLM can reason about the query structure without seeing schema
        preview = sql
        for real in [spec.primary_table, spec.primary_alias]:
            preview = preview.replace(real, "[source_table]")
        # Replace SQL expressions with governed vocabulary
        preview = preview.replace(spec.select_expression, f"[{spec.metric_id}]")
        preview = preview.replace(spec.date_column, "[date_column]")
        for dim_name, dim_sql in SQLBuilder._get_dims(spec).items():
            preview = preview.replace(dim_sql, f"[{dim_name}]")
        return preview


def format_value(value: float, format_type: str) -> str:
    """Format a numeric value for display."""
    if value is None: return "-"
    if format_type == "currency":
        if abs(value) >= 1_000_000: return f"${value/1_000_000:.2f}M"
        if abs(value) >= 1_000:     return f"${value/1_000:.1f}K"
        return f"${value:,.2f}"
    if format_type == "percent":  return f"{value:.2f}%"
    if format_type == "integer":  return f"{int(value):,}"
    return f"{value:,.2f}"
