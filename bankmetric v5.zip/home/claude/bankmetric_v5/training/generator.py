"""
BankMetric v5 — Training Data Generator

Reads the metric registry and generates question→SQL training pairs
for fine-tuning a small on-prem LLM.

How it works:
  1. For each metric in the registry, reads:
     - display_name, description, allowed_dimensions, business_questions
  2. Generates question variations using templates + an LLM (offline)
  3. For each question, builds the correct SQL using SQLBuilder
  4. Saves pairs as JSONL ready for fine-tuning

Output format (JSONL — one pair per line):
  {"prompt": "What was our revenue last quarter?",
   "completion": "metric=total_revenue time=last_quarter group_by=[]"}

Two modes:
  Mode A — Structured output (metric_id + params) — for classifier fine-tuning
  Mode B — SQL output — for direct SQL generation fine-tuning

Mode A is recommended for zero-hallucination design.
The fine-tuned model learns to classify, not generate.
"""

import json
import sys
import os
import itertools
import random
from datetime import date
from dataclasses import dataclass, field
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ── Question templates ─────────────────────────────────────────────────────────
# These generate the training question variations.
# Combined with metric descriptions and dimension names they cover
# the full range of what a banking analyst might ask.

QUESTION_TEMPLATES = {
    "simple_total": [
        "What is our {metric_name}?",
        "Show me {metric_name}",
        "What was {metric_name} {time}?",
        "Give me {metric_name} for {time}",
        "{metric_name} {time}",
        "What is the {metric_name} for {time}?",
        "Tell me the {metric_name}",
        "Display {metric_name}",
        "Get {metric_name} for {time}",
        "I need {metric_name}",
    ],
    "by_dimension": [
        "Show {metric_name} by {dim}",
        "Break down {metric_name} by {dim}",
        "{metric_name} by {dim} {time}",
        "What is {metric_name} by {dim}?",
        "Show me {metric_name} broken down by {dim}",
        "{metric_name} per {dim} {time}",
        "Which {dim} has the highest {metric_name}?",
        "Which {dim} has the lowest {metric_name}?",
        "How does {metric_name} compare across {dim}s?",
        "Show {metric_name} for each {dim}",
        "Break {metric_name} down by {dim} for {time}",
        "{metric_name} analysis by {dim}",
    ],
    "top_n": [
        "Top 5 {dim}s by {metric_name}",
        "Top 10 {dim}s by {metric_name} {time}",
        "Show top 5 {metric_name} by {dim}",
        "Which are the top 3 {dim}s for {metric_name}?",
        "Top 10 {metric_name} {time}",
        "Show me top 5 {dim}s by {metric_name} last quarter",
        "Bottom 5 {dim}s by {metric_name}",
        "Lowest 3 {dim}s for {metric_name}",
    ],
    "comparison": [
        "How does {metric_name} compare to last year?",
        "{metric_name} this quarter versus last quarter",
        "Compare {metric_name} to previous period",
        "Is {metric_name} better or worse than last quarter?",
        "How has {metric_name} changed?",
        "{metric_name} growth rate",
        "Which {dim} grew the most in {metric_name}?",
        "Which {dim} had the biggest change in {metric_name}?",
        "{metric_name} year over year by {dim}",
        "{metric_name} quarter over quarter",
        "Show {metric_name} compared to last quarter by {dim}",
    ],
    "trend": [
        "Show {metric_name} trend by month",
        "{metric_name} over time",
        "Monthly {metric_name} for last year",
        "How has {metric_name} trended?",
        "Show {metric_name} by quarter",
        "{metric_name} trend last 12 months",
        "Monthly trend of {metric_name}",
        "Quarterly {metric_name} this year",
        "{metric_name} month over month",
    ],
    "pct_of_total": [
        "What percentage of total {metric_name} comes from each {dim}?",
        "{metric_name} share by {dim}",
        "What share of {metric_name} does each {dim} contribute?",
        "Show {metric_name} as percentage of total by {dim}",
        "{dim} contribution to {metric_name}",
        "Which {dim} contributes most to {metric_name}?",
    ],
    "filtered": [
        "{metric_name} for {region} {time}",
        "Show {metric_name} in {region}",
        "{metric_name} for {region} only",
        "What is {metric_name} in {region} last quarter?",
        "{metric_name} {product} product {time}",
        "Show {metric_name} for {product}",
    ],
    "intent_variations": [
        # Natural language that implies the metric without naming it
        # These are the hard cases — require LLM to understand intent
    ],
}

TIME_RANGES = [
    ("last quarter",     "last_quarter"),
    ("last month",       "last_month"),
    ("this year",        "this_year"),
    ("last year",        "last_year"),
    ("year to date",     "year_to_date"),
    ("this month",       "this_month"),
    ("this quarter",     "this_quarter"),
    ("last 30 days",     "last_30_days"),
    ("last 90 days",     "last_90_days"),
    ("",                 "last_30_days"),  # no time = default
]

REGIONS = ["North America", "Europe", "APAC", "Latin America"]
PRODUCTS = ["Mortgage", "Personal Loan", "Auto Loan", "Business Loan", "Credit Card"]

DIM_DISPLAY = {
    "region":   "region",
    "product":  "product",
    "channel":  "channel",
    "customer": "customer",
}


# ── Output format ──────────────────────────────────────────────────────────────

@dataclass
class TrainingPair:
    """One training example."""
    question:    str
    metric_id:   str
    time_range:  str
    group_by:    list
    filters:     dict
    computation: str
    # The target output for fine-tuning
    completion:  str = ""
    # Metadata
    metric_name: str = ""
    category:    str = ""
    template:    str = ""
    split:       str = "train"  # train / val / test

    def to_jsonl_classifier(self) -> str:
        """
        Mode A — classifier output.
        LLM learns to output structured params, not SQL.
        Zero hallucination: all values from governed vocabulary.
        """
        self.completion = json.dumps({
            "metric_id":   self.metric_id,
            "time_range":  self.time_range,
            "group_by":    self.group_by,
            "filters":     self.filters,
            "computation": self.computation,
        }, separators=(',', ':'))
        return json.dumps({
            "prompt":     f"Question: {self.question}\nAnswer:",
            "completion": " " + self.completion,
            "metric_id":  self.metric_id,
            "category":   self.category,
            "template":   self.template,
            "split":      self.split,
        })

    def to_jsonl_sql(self, sql: str) -> str:
        """
        Mode B — SQL output.
        LLM learns to generate SQL directly from question.
        Higher hallucination risk but more flexible.
        """
        return json.dumps({
            "prompt":     f"Banking analytics question: {self.question}\nSQL:",
            "completion": " " + sql,
            "metric_id":  self.metric_id,
            "split":      self.split,
        })


# ── Generator ─────────────────────────────────────────────────────────────────

class TrainingDataGenerator:
    """
    Reads metric registry and generates training pairs.

    Usage:
        gen = TrainingDataGenerator()
        pairs = gen.generate_all()
        gen.save(pairs, "training_data.jsonl")
    """

    def __init__(self):
        from db.database import get_connection
        from db.registry import MetricRegistry
        from db.sql_builder import SQLBuilder, QueryDescriptor

        get_connection()
        self.registry      = MetricRegistry
        self.sql_builder   = SQLBuilder
        self.QueryDescriptor = QueryDescriptor
        self.metrics       = MetricRegistry.get_all()
        print(f"✅ Generator ready — {len(self.metrics)} metrics loaded")

    def generate_all(self,
                     variations_per_metric: int = 50,
                     val_split:  float = 0.1,
                     test_split: float = 0.05) -> list[TrainingPair]:
        """
        Generate all training pairs for all metrics.

        Args:
            variations_per_metric: how many question variations per metric
            val_split:  fraction of pairs for validation
            test_split: fraction of pairs for test

        Returns:
            List of TrainingPair objects
        """
        all_pairs = []

        for metric in self.metrics:
            pairs = self._generate_for_metric(metric, variations_per_metric)
            all_pairs.extend(pairs)

        # Shuffle and assign splits
        random.shuffle(all_pairs)
        n = len(all_pairs)
        n_test = int(n * test_split)
        n_val  = int(n * val_split)

        for i, p in enumerate(all_pairs):
            if i < n_test:
                p.split = "test"
            elif i < n_test + n_val:
                p.split = "val"
            else:
                p.split = "train"

        train = sum(1 for p in all_pairs if p.split == "train")
        val   = sum(1 for p in all_pairs if p.split == "val")
        test  = sum(1 for p in all_pairs if p.split == "test")

        print(f"\n✅ Generated {n} training pairs")
        print(f"   Train: {train}  Val: {val}  Test: {test}")
        print(f"   Metrics covered: {len(set(p.metric_id for p in all_pairs))}")

        return all_pairs

    def _generate_for_metric(self, spec, target_count: int) -> list[TrainingPair]:
        """Generate training pairs for one metric."""
        import json as _json

        pairs = []
        mid   = spec.metric_id
        name  = spec.display_name.lower()

        # Get allowed dimensions
        dims = spec.allowed_dimensions
        if isinstance(dims, str):
            try: dims = _json.loads(dims)
            except: dims = {}
        dim_names = list(dims.keys()) if isinstance(dims, dict) else []

        # 1. Simple totals — each time range
        for time_display, time_id in TIME_RANGES[:8]:
            for tmpl in random.sample(QUESTION_TEMPLATES["simple_total"], 3):
                q = tmpl.format(
                    metric_name=name,
                    time=time_display,
                ).strip().rstrip("?") + ("?" if tmpl.endswith("?") else "")
                q = q.replace("  ", " ").strip()
                pairs.append(TrainingPair(
                    question=q, metric_id=mid,
                    time_range=time_id, group_by=[],
                    filters={}, computation="simple",
                    metric_name=name, category=spec.category,
                    template="simple_total",
                ))

        # 2. By dimension — each dim × each time range
        for dim in dim_names[:3]:  # top 3 dims
            for time_display, time_id in random.sample(TIME_RANGES[:8], 3):
                for tmpl in random.sample(QUESTION_TEMPLATES["by_dimension"], 2):
                    q = tmpl.format(
                        metric_name=name, dim=dim,
                        time=time_display,
                    ).strip()
                    pairs.append(TrainingPair(
                        question=q, metric_id=mid,
                        time_range=time_id, group_by=[dim],
                        filters={}, computation="simple",
                        metric_name=name, category=spec.category,
                        template="by_dimension",
                    ))

        # 3. Comparisons — time comparison
        for tmpl in random.sample(QUESTION_TEMPLATES["comparison"], 3):
            dim = random.choice(dim_names) if dim_names else None
            q = tmpl.format(
                metric_name=name,
                dim=dim or "segment",
                time="last quarter",
            ).strip()
            pairs.append(TrainingPair(
                question=q, metric_id=mid,
                time_range="last_quarter", group_by=[dim] if dim else [],
                filters={}, computation="compare_periods",
                metric_name=name, category=spec.category,
                template="comparison",
            ))

        # 4. Trends
        for tmpl in random.sample(QUESTION_TEMPLATES["trend"], 2):
            q = tmpl.format(metric_name=name).strip()
            pairs.append(TrainingPair(
                question=q, metric_id=mid,
                time_range="last_year", group_by=[],
                filters={}, computation="trend",
                metric_name=name, category=spec.category,
                template="trend",
            ))

        # 5. Percentages of total
        for dim in dim_names[:2]:
            for tmpl in random.sample(QUESTION_TEMPLATES["pct_of_total"], 2):
                q = tmpl.format(metric_name=name, dim=dim).strip()
                pairs.append(TrainingPair(
                    question=q, metric_id=mid,
                    time_range="last_quarter", group_by=[dim],
                    filters={}, computation="pct_of_total",
                    metric_name=name, category=spec.category,
                    template="pct_of_total",
                ))

        # 6. Top N
        if dim_names:
            for n_limit in [5, 10, 3]:
                for tmpl in random.sample(QUESTION_TEMPLATES["top_n"], 2):
                    dim = dim_names[0]
                    q = tmpl.format(
                        metric_name=name, dim=dim,
                        time="last quarter",
                    ).strip()
                    pairs.append(TrainingPair(
                        question=q, metric_id=mid,
                        time_range="last_quarter", group_by=[dim],
                        filters={"limit": n_limit}, computation="simple",
                        metric_name=name, category=spec.category,
                        template="top_n",
                    ))

        # 7. Region filters
        if "region" in dim_names:
            for region in random.sample(REGIONS, 2):
                for tmpl in random.sample(QUESTION_TEMPLATES["filtered"], 2):
                    q = tmpl.format(
                        metric_name=name, region=region,
                        product=random.choice(PRODUCTS),
                        time="last quarter",
                    ).strip()
                    pairs.append(TrainingPair(
                        question=q, metric_id=mid,
                        time_range="last_quarter", group_by=[],
                        filters={"region": region},
                        computation="simple",
                        metric_name=name, category=spec.category,
                        template="filtered",
                    ))

        # 8. Business questions from registry — these are gold
        #    Already human-written, map directly to this metric
        for bq in spec.business_questions:
            pairs.append(TrainingPair(
                question=bq, metric_id=mid,
                time_range="last_quarter", group_by=[],
                filters={}, computation="simple",
                metric_name=name, category=spec.category,
                template="registry_question",
            ))

        # Trim to target count
        if len(pairs) > target_count:
            # Keep registry questions always, sample the rest
            registry_q = [p for p in pairs if p.template == "registry_question"]
            other      = [p for p in pairs if p.template != "registry_question"]
            random.shuffle(other)
            keep = target_count - len(registry_q)
            pairs = registry_q + other[:keep]

        return pairs

    def save(self, pairs: list[TrainingPair],
             output_path: str,
             mode: str = "classifier") -> dict:
        """
        Save training pairs to JSONL file.

        mode: "classifier" (recommended) or "sql"
        Returns: stats dict
        """
        from db.sql_builder import SQLBuilder, QueryDescriptor

        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        stats = {"total": 0, "train": 0, "val": 0, "test": 0,
                 "by_metric": {}, "by_template": {}, "sql_errors": 0}

        with open(output_path, "w") as f:
            for pair in pairs:
                if mode == "classifier":
                    line = pair.to_jsonl_classifier()
                else:
                    # Build SQL for this pair
                    try:
                        from db.registry import MetricRegistry
                        spec = MetricRegistry.get(pair.metric_id)
                        if not spec:
                            stats["sql_errors"] += 1
                            continue
                        desc = QueryDescriptor(
                            metric_id   = pair.metric_id,
                            time_range  = pair.time_range,
                            group_by    = pair.group_by,
                            filters     = pair.filters,
                            computation = pair.computation,
                        )
                        sql, _ = SQLBuilder.build(spec, desc)
                        line = pair.to_jsonl_sql(sql)
                    except Exception as e:
                        stats["sql_errors"] += 1
                        continue

                f.write(line + "\n")
                stats["total"] += 1
                stats[pair.split] = stats.get(pair.split, 0) + 1
                stats["by_metric"][pair.metric_id] = \
                    stats["by_metric"].get(pair.metric_id, 0) + 1
                stats["by_template"][pair.template] = \
                    stats["by_template"].get(pair.template, 0) + 1

        print(f"\n✅ Saved {stats['total']} pairs to {output_path}")
        print(f"   Train: {stats['train']}  Val: {stats['val']}  Test: {stats['test']}")
        if stats["sql_errors"]:
            print(f"   ⚠️  SQL errors: {stats['sql_errors']}")

        return stats

    def save_splits(self, pairs: list[TrainingPair],
                    output_dir: str,
                    mode: str = "classifier"):
        """Save train/val/test as separate files."""
        os.makedirs(output_dir, exist_ok=True)
        for split in ["train", "val", "test"]:
            split_pairs = [p for p in pairs if p.split == split]
            path = os.path.join(output_dir, f"{split}.jsonl")
            self.save(split_pairs, path, mode)
            print(f"   {split}.jsonl → {len(split_pairs)} pairs")

    def generate_summary_report(self, pairs: list[TrainingPair]) -> str:
        """Generate a human-readable summary of the training data."""
        from collections import Counter

        total    = len(pairs)
        by_cat   = Counter(p.category for p in pairs)
        by_comp  = Counter(p.computation for p in pairs)
        by_tmpl  = Counter(p.template for p in pairs)
        by_split = Counter(p.split for p in pairs)

        lines = [
            "═" * 55,
            "  TRAINING DATA SUMMARY",
            "═" * 55,
            f"  Total pairs:    {total:,}",
            f"  Train:          {by_split['train']:,}",
            f"  Validation:     {by_split['val']:,}",
            f"  Test:           {by_split['test']:,}",
            "",
            "  By category:",
        ]
        for cat, n in sorted(by_cat.items(), key=lambda x: -x[1]):
            pct = n / total * 100
            lines.append(f"    {cat:<20} {n:>5}  ({pct:.1f}%)")

        lines += ["", "  By computation type:"]
        for comp, n in sorted(by_comp.items(), key=lambda x: -x[1]):
            pct = n / total * 100
            lines.append(f"    {comp:<25} {n:>5}  ({pct:.1f}%)")

        lines += ["", "  By template:"]
        for tmpl, n in sorted(by_tmpl.items(), key=lambda x: -x[1]):
            pct = n / total * 100
            lines.append(f"    {tmpl:<25} {n:>5}  ({pct:.1f}%)")

        lines += [
            "",
            "  Sample questions:",
        ]
        seen_metrics = set()
        for p in pairs:
            if p.metric_id not in seen_metrics and len(seen_metrics) < 8:
                lines.append(f"    Q: {p.question[:65]}")
                lines.append(f"       → {p.metric_id} | {p.time_range} | {p.group_by} | {p.computation}")
                seen_metrics.add(p.metric_id)

        lines.append("═" * 55)
        return "\n".join(lines)


# ── CLI entry point ────────────────────────────────────────────────────────────

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="BankMetric Training Data Generator"
    )
    parser.add_argument("--output",      default="training_data/",
                        help="Output directory")
    parser.add_argument("--variations",  type=int, default=50,
                        help="Question variations per metric (default: 50)")
    parser.add_argument("--mode",        choices=["classifier","sql"],
                        default="classifier",
                        help="Output mode: classifier (recommended) or sql")
    parser.add_argument("--splits",      action="store_true",
                        help="Save separate train/val/test files")
    parser.add_argument("--report",      action="store_true",
                        help="Print summary report")
    args = parser.parse_args()

    gen   = TrainingDataGenerator()
    pairs = gen.generate_all(variations_per_metric=args.variations)

    if args.report:
        print(gen.generate_summary_report(pairs))

    if args.splits:
        gen.save_splits(pairs, args.output, mode=args.mode)
    else:
        output_path = os.path.join(args.output, "training_data.jsonl")
        gen.save(pairs, output_path, mode=args.mode)

    print(f"\n  Next steps:")
    print(f"  1. Review {args.output} — check questions look natural")
    print(f"  2. Optionally augment with GPT-4 generated variations")
    print(f"  3. Fine-tune: ollama create bankmetric --file Modelfile")
    print(f"  4. Replace Stage 1 in parser/llm_parser.py with fine-tuned model")


if __name__ == "__main__":
    main()
