"""
BankMetric v5 — Metric Registry

Single source of truth for all metric definitions.
The only class that reads metric schema from the database.
Everything else in the system goes through this class.
"""
import json
from dataclasses import dataclass, field
from typing import Optional
from db.database import get_connection


@dataclass
class MetricSpec:
    """Complete metric definition loaded from registry."""
    # Identity
    metric_id:          str
    display_name:       str
    description:        str
    long_description:   str
    business_questions: list[str]
    category:           str
    tags:               list[str]
    business_owner:     str
    data_steward:       str
    tier:               int
    status:             str
    version:            int

    # Computation (internal — never sent to LLM)
    select_expression:  str
    is_ratio:           bool
    numerator_expr:     Optional[str]
    denominator_expr:   Optional[str]
    primary_table:      str
    primary_alias:      str
    base_filter:        str
    date_column:        str
    base_joins:         list[dict]

    # Dimensions
    allowed_dimensions: dict    # {name: sql_expression}
    dimension_joins:    dict    # {dim_name: join_sql}
    force_group_by:     list[str]
    default_limit:      Optional[int]
    default_sort:       str

    # Output
    format_type:        str
    unit:               Optional[str]

    def to_llm_description(self) -> str:
        """
        What the LLM sees — description and dimensions only.
        Never includes table names, column names, or SQL.
        """
        import json
        dims_data = self.allowed_dimensions
        if isinstance(dims_data, str):
            try: dims_data = json.loads(dims_data)
            except: dims_data = {}
        dims = list(dims_data.keys()) if isinstance(dims_data, dict) else []
        questions = self.business_questions[:3] if self.business_questions else []
        return (
            f"{self.metric_id}: {self.description}\n"
            f"  Format: {self.format_type} ({self.unit or ''})\n"
            f"  Dimensions: {', '.join(dims)}\n"
            f"  Example questions: {'; '.join(questions)}"
        )

    def to_dict(self) -> dict:
        """Serialise for API responses."""
        return {
            "metric_id":          self.metric_id,
            "display_name":       self.display_name,
            "description":        self.description,
            "long_description":   self.long_description,
            "business_questions": self.business_questions,
            "category":           self.category,
            "tags":               self.tags,
            "business_owner":     self.business_owner,
            "data_steward":       self.data_steward,
            "tier":               self.tier,
            "status":             self.status,
            "allowed_dimensions": list(self.allowed_dimensions.keys()),
            "format_type":        self.format_type,
            "unit":               self.unit,
            "default_limit":      self.default_limit,
        }


class MetricRegistry:
    """
    Loads metric definitions from the database.
    Provides governed vocabulary for LLM prompts.
    Validates queries before execution.
    """

    _cache: dict[str, MetricSpec] = {}

    @classmethod
    def get(cls, metric_id: str) -> Optional[MetricSpec]:
        if metric_id not in cls._cache:
            cls._load_all()
        return cls._cache.get(metric_id)

    @classmethod
    def get_all(cls, status: str = "published") -> list[MetricSpec]:
        cls._load_all()
        return [s for s in cls._cache.values() if s.status == status]

    @classmethod
    def get_ids(cls) -> list[str]:
        return [m.metric_id for m in cls.get_all()]

    @classmethod
    def get_llm_vocabulary(cls) -> str:
        """
        Returns what the LLM is allowed to see.
        Metric descriptions and dimensions only — no schema.
        """
        metrics = cls.get_all()
        lines = ["AVAILABLE METRICS:"]
        for m in metrics:
            lines.append(m.to_llm_description())
        return "\n".join(lines)

    @classmethod
    def validate_query(cls, metric_id: str, group_by: list[str],
                       filters: dict) -> tuple[bool, str]:
        """
        Validate a query against the registry.
        Returns (valid, error_message).
        """
        spec = cls.get(metric_id)
        if not spec:
            available = ", ".join(cls.get_ids())
            return False, f"Metric '{metric_id}' not found. Available: {available}"

        if spec.status != "published":
            return False, f"Metric '{metric_id}' is {spec.status} and not available."

        dims_data = spec.allowed_dimensions
        if isinstance(dims_data, str):
            import json
            try: dims_data = json.loads(dims_data)
            except: dims_data = {}
        invalid_dims = [d for d in group_by if d not in dims_data]
        if invalid_dims:
            valid = list(spec.allowed_dimensions.keys())
            return False, (f"Dimension(s) {invalid_dims} not valid for '{metric_id}'. "
                          f"Valid dimensions: {valid}")

        region = filters.get("region")
        if region:
            valid_regions = ["North America", "Europe", "APAC", "Latin America"]
            if region not in valid_regions:
                return False, f"Region '{region}' not valid. Valid: {valid_regions}"

        product = filters.get("product")
        if product:
            valid_products = ["Mortgage", "Personal Loan", "Auto Loan",
                             "Business Loan", "Credit Card"]
            if product not in valid_products:
                return False, f"Product '{product}' not valid. Valid: {valid_products}"

        return True, ""

    @classmethod
    def invalidate_cache(cls):
        cls._cache = {}

    @classmethod
    def _load_all(cls):
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM metric_registry WHERE status != 'deleted'"
        ).fetchall()
        cls._cache = {}
        for row in rows:
            r = dict(row)
            spec = MetricSpec(
                metric_id         = r["metric_id"],
                display_name      = r["display_name"],
                description       = r["description"],
                long_description  = r.get("long_description") or "",
                business_questions= (json.loads(r["business_questions"]) if isinstance(r.get("business_questions"), str) else r.get("business_questions") or []),
                category          = r.get("category") or "",
                tags              = (json.loads(r["tags"]) if isinstance(r.get("tags"), str) else r.get("tags") or []),
                business_owner    = r.get("business_owner") or "",
                data_steward      = r.get("data_steward") or "",
                tier              = r.get("tier") or 3,
                status            = r.get("status") or "published",
                version           = r.get("version") or 1,
                select_expression = r["select_expression"],
                is_ratio          = bool(r.get("is_ratio")),
                numerator_expr    = r.get("numerator_expr"),
                denominator_expr  = r.get("denominator_expr"),
                primary_table     = r["primary_table"],
                primary_alias     = r["primary_alias"],
                base_filter       = r.get("base_filter") or "1=1",
                date_column       = r["date_column"],
                base_joins        = (json.loads(r["base_joins"]) if isinstance(r.get("base_joins"), str) else r.get("base_joins") or []),
                allowed_dimensions= (json.loads(r["allowed_dimensions"]) if isinstance(r.get("allowed_dimensions"), str) else r.get("allowed_dimensions") or {}),
                dimension_joins   = (json.loads(r["dimension_joins"]) if isinstance(r.get("dimension_joins"), str) else r.get("dimension_joins") or {}),
                force_group_by    = (json.loads(r["force_group_by"]) if isinstance(r.get("force_group_by"), str) else r.get("force_group_by") or []),
                default_limit     = r.get("default_limit"),
                default_sort      = r.get("default_sort") or "DESC",
                format_type       = r.get("format_type") or "number",
                unit              = r.get("unit"),
            )
            cls._cache[spec.metric_id] = spec

    # ── CRUD operations ────────────────────────────────────────────────────────

    @classmethod
    def save(cls, metric_data: dict) -> tuple[bool, str]:
        """Save or update a metric definition."""
        conn = get_connection()
        try:
            # Convert lists/dicts to JSON strings
            for field in ["business_questions", "tags", "base_joins",
                          "allowed_dimensions", "dimension_joins",
                          "force_group_by"]:
                if field in metric_data and not isinstance(metric_data[field], str):
                    metric_data[field] = json.dumps(metric_data[field])

            # Check if exists
            existing = conn.execute(
                "SELECT version FROM metric_registry WHERE metric_id=?",
                (metric_data["metric_id"],)
            ).fetchone()

            if existing:
                metric_data["version"] = (existing["version"] or 1) + 1
                metric_data["updated_at"] = "datetime('now')"
                conn.execute("""
                    UPDATE metric_registry SET
                        display_name=:display_name, description=:description,
                        long_description=:long_description,
                        business_questions=:business_questions,
                        category=:category, tags=:tags,
                        business_owner=:business_owner, data_steward=:data_steward,
                        tier=:tier, status=:status,
                        select_expression=:select_expression,
                        base_filter=:base_filter, allowed_dimensions=:allowed_dimensions,
                        force_group_by=:force_group_by, default_limit=:default_limit,
                        format_type=:format_type, unit=:unit,
                        version=:version,
                        updated_at=datetime('now')
                    WHERE metric_id=:metric_id
                """, metric_data)
            else:
                conn.execute("""
                    INSERT INTO metric_registry
                    (metric_id, display_name, description, long_description,
                     business_questions, category, tags, business_owner, data_steward,
                     tier, status, select_expression, base_filter,
                     date_column, primary_table, primary_alias,
                     allowed_dimensions, dimension_joins, force_group_by,
                     default_limit, format_type, unit)
                    VALUES
                    (:metric_id, :display_name, :description, :long_description,
                     :business_questions, :category, :tags, :business_owner, :data_steward,
                     :tier, :status, :select_expression, :base_filter,
                     :date_column, :primary_table, :primary_alias,
                     :allowed_dimensions, :dimension_joins, :force_group_by,
                     :default_limit, :format_type, :unit)
                """, metric_data)

            conn.commit()
            cls.invalidate_cache()
            return True, "Saved successfully"
        except Exception as e:
            return False, str(e)

    @classmethod
    def delete(cls, metric_id: str) -> tuple[bool, str]:
        """Soft delete — marks as deleted, never hard deletes."""
        conn = get_connection()
        try:
            conn.execute(
                "UPDATE metric_registry SET status='deleted' WHERE metric_id=?",
                (metric_id,)
            )
            conn.commit()
            cls.invalidate_cache()
            return True, f"Metric '{metric_id}' deleted"
        except Exception as e:
            return False, str(e)
