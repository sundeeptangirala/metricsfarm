"""
BankMetric v4 — Two-Stage Parser

Stage 1: LLM (Ollama) — language understanding only
  - What is the intent? (data / ui_command / clarify / unclear)
  - Which metric? (or is it ambiguous?)
  - Is this a follow-up?
  Short prompt, relaxed output, model does what it's good at.

Stage 2: Python — precise extraction from raw text
  - limit:   read "top N" literally from question
  - region:  exact match against whitelist
  - time:    pattern match on explicit phrases  
  - group_by: dimension keywords
  - order:   "lowest/worst/least" → ASC
  These are not competing rules — they read what the user literally typed.

The LLM never has to produce a perfectly formatted JSON with every field
correct. It just has to understand the question and identify the metric.
Python handles the precision work.
"""

import re
import json
import requests
import logging
from datetime import date, timedelta
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "phi3:mini"          # better at structured output than llama3.2:3b
OLLAMA_MODEL_FALLBACK = "llama3.2:3b"  # used if phi3 not available
TIMEOUT_SEC  = 30

# ── Registry ───────────────────────────────────────────────────────────────────

AVAILABLE_METRICS = [
    "total_revenue", "transaction_count", "average_transaction",
    "revenue_per_customer", "active_customers", "new_customers",
    "churn_rate", "total_loan_value", "loan_count", "delinquency_rate",
]

AVAILABLE_DIMS     = ["region", "product", "channel", "customer"]
AVAILABLE_REGIONS  = ["North America", "Europe", "APAC", "Latin America"]
AVAILABLE_PRODUCTS = ["Mortgage", "Personal Loan", "Auto Loan",
                      "Business Loan", "Credit Card"]
AVAILABLE_CHANNELS = ["Branch", "Online", "Mobile", "Agent"]
AVAILABLE_TIMES    = [
    "today", "this_week", "last_week", "this_month", "last_month",
    "this_quarter", "last_quarter", "this_year", "last_year",
    "year_to_date", "last_30_days", "last_90_days",
]

# ── Output types ───────────────────────────────────────────────────────────────

@dataclass
class ClarifyOption:
    label:      str
    metric:     Optional[str] = None
    time_range: Optional[str] = None
    group_by:   list          = field(default_factory=list)
    filters:    dict          = field(default_factory=dict)

@dataclass
class QueryObject:
    intent:           str            = "data"
    metric:           Optional[str]  = None
    time_range:       Optional[str]  = None
    group_by:         list           = field(default_factory=list)
    filters:          dict           = field(default_factory=dict)
    inherit_context:  bool           = False
    ui_action:        Optional[str]  = None
    clarify_question: Optional[str]  = None
    clarify_options:  list           = field(default_factory=list)
    unclear_message:  Optional[str]  = None
    raw_text:         str            = ""
    confidence:       float          = 1.0
    parser:           str            = "llm"


# ── Date resolver ──────────────────────────────────────────────────────────────

def resolve_date_range(time_range: str) -> tuple[str, str]:
    today = date.today()
    def qs(d): return date(d.year, ((d.month-1)//3)*3+1, 1)
    def ms(d): return date(d.year, d.month, 1)
    if time_range == "last_quarter":
        e = qs(today)-timedelta(1); return qs(e).isoformat(), e.isoformat()
    if time_range == "last_month":
        e = ms(today)-timedelta(1); return ms(e).isoformat(), e.isoformat()
    if time_range == "last_year":
        return date(today.year-1,1,1).isoformat(), date(today.year-1,12,31).isoformat()
    if time_range == "last_week":
        e = today-timedelta(days=today.weekday()+1)
        return (e-timedelta(6)).isoformat(), e.isoformat()
    MAP = {
        "today":        (today, today),
        "this_week":    (today-timedelta(days=today.weekday()), today),
        "this_month":   (ms(today), today),
        "this_quarter": (qs(today), today),
        "this_year":    (date(today.year,1,1), today),
        "year_to_date": (date(today.year,1,1), today),
        "last_30_days": (today-timedelta(30), today),
        "last_90_days": (today-timedelta(90), today),
    }
    if time_range in MAP:
        s, e = MAP[time_range]; return s.isoformat(), e.isoformat()
    return (today-timedelta(30)).isoformat(), today.isoformat()


# ══════════════════════════════════════════════════════════════════════════════
# STAGE 2 — Python precision extraction
# Reads what the user literally typed. Not rules — just reading.
# ══════════════════════════════════════════════════════════════════════════════

# Number words → digits
NUMBER_WORDS = {
    "one":1,"two":2,"three":3,"four":4,"five":5,
    "six":6,"seven":7,"eight":8,"nine":9,"ten":10,
    "fifteen":15,"twenty":20,"twenty-five":25,"fifty":50,"hundred":100,
}

def _extract_limit(text: str) -> Optional[int]:
    """Read 'top N' or 'top five' from raw text. User said it explicitly."""
    lower = text.lower()
    # "top 5" / "top 10" / "top 5 customers"
    m = re.search(r'\btop\s+(\d+)\b', lower)
    if m: return int(m.group(1))
    # "top five" / "top ten"
    m = re.search(r'\btop\s+(' + '|'.join(NUMBER_WORDS.keys()) + r')\b', lower)
    if m: return NUMBER_WORDS[m.group(1)]
    # "5 customers" / "10 regions" (without "top")
    m = re.search(r'\b(\d+)\s+(?:customers?|regions?|products?|channels?)\b', lower)
    if m: return int(m.group(1))
    return None


def _extract_region(text: str) -> Optional[str]:
    """Match region names and aliases against whitelist."""
    lower = text.lower()
    # Exact whitelist values first
    for r in AVAILABLE_REGIONS:
        if r.lower() in lower: return r
    # Aliases — only if not asking "by region" (that's a dimension)
    if re.search(r'\bby\s+region\b', lower): return None
    ALIASES = {
        "north america": "North America", "na ": "North America",
        " us ": "North America", "usa": "North America",
        "united states": "North America", "americas": "North America",
        "europe": "Europe", "uk": "Europe", "emea": "Europe",
        "apac": "APAC", "asia pacific": "APAC", "asia": "APAC",
        " ap ": "APAC",
        "latin america": "Latin America", "latam": "Latin America",
        "south america": "Latin America",
    }
    for alias, canonical in ALIASES.items():
        if alias in f" {lower} ": return canonical
    return None


def _extract_product(text: str) -> Optional[str]:
    """Match product names against whitelist."""
    lower = text.lower()
    if re.search(r'\bby\s+product\b', lower): return None
    ALIASES = {
        "mortgage": "Mortgage", "home loan": "Mortgage",
        "personal loan": "Personal Loan", "personal loans": "Personal Loan",
        "auto loan": "Auto Loan", "auto loans": "Auto Loan", "car loan": "Auto Loan",
        "business loan": "Business Loan", "business loans": "Business Loan",
        "credit card": "Credit Card", "credit cards": "Credit Card",
    }
    for alias, canonical in ALIASES.items():
        if alias in lower: return canonical
    return None


def _extract_time(text: str) -> Optional[str]:
    """Match time expressions. User wrote them explicitly."""
    lower = text.lower()
    # Exact phrases
    PATTERNS = [
        (r'\blast\s+quarter\b',          "last_quarter"),
        (r'\bthis\s+quarter\b',          "this_quarter"),
        (r'\bq(?:td)?\b',                "this_quarter"),
        (r'\blast\s+month\b',            "last_month"),
        (r'\bthis\s+month\b',            "this_month"),
        (r'\bm(?:td)?\b',                "this_month"),
        (r'\blast\s+year\b',             "last_year"),
        (r'\bthis\s+year\b',             "this_year"),
        (r'\byear\s+to\s+date\b|\bytd\b', "year_to_date"),
        (r'\blast\s+90\s+days?\b',       "last_90_days"),
        (r'\blast\s+30\s+days?\b',       "last_30_days"),
        (r'\blast\s+week\b',             "last_week"),
        (r'\bthis\s+week\b',             "this_week"),
        (r'\btoday\b',                   "today"),
        (r'\bttm\b|\bltm\b|\blast\s+12\s+months?\b', "last_year"),
    ]
    for pattern, tr in PATTERNS:
        if re.search(pattern, lower): return tr
    return None


def _extract_dims(text: str) -> list[str]:
    """Extract explicit dimension requests."""
    lower = text.lower()
    dims  = []
    DIM_PATTERNS = {
        "region":   [r'\bby\s+region\b', r'\bper\s+region\b', r'\bby\s+geography\b',
                     r'\bwhich\s+region\b', r'\btop\s+\d+\s+regions?\b',
                     r'\bregion\s+breakdown\b', r'\bacross\s+regions?\b'],
        "product":  [r'\bby\s+product\b', r'\bper\s+product\b',
                     r'\bwhich\s+product\b', r'\btop\s+\d+\s+products?\b',
                     r'\bproduct\s+breakdown\b', r'\bacross\s+products?\b'],
        "channel":  [r'\bby\s+channel\b', r'\bper\s+channel\b',
                     r'\bwhich\s+channel\b', r'\btop\s+\d+\s+channels?\b',
                     r'\bchannel\s+breakdown\b', r'\bacross\s+channels?\b',
                     r'\bmost\s+used\s+channel\b', r'\bbest\s+channel\b'],
        "customer": [r'\bby\s+customer\b', r'\bper\s+customer\b',
                     r'\btop\s+\d+\s+customers?\b',       # "top 5 customers"
                     r'\btop\s+\w+\s+customers?\b',       # "top five customers"
                     r'\b\d+\s+customers?\b',              # "10 customers"
                     r'\bcustomer\s+breakdown\b',
                     r'\bmost\s+valuable\s+customers?\b',
                     r'\bbest\s+customers?\b',
                     r'\btop\s+customers?\b',
                     r'customers?\s+by\s+revenue\b'],       # "customers by revenue"
    }
    for dim, patterns in DIM_PATTERNS.items():
        if any(re.search(p, lower) for p in patterns):
            dims.append(dim)
    return dims


def _extract_order(text: str) -> str:
    """ASC if user asks for lowest/worst/least."""
    lower = text.lower()
    if any(w in lower for w in ["lowest", "worst", "least", "smallest", "bottom"]):
        return "ASC"
    return "DESC"


# ══════════════════════════════════════════════════════════════════════════════
# STAGE 1 — LLM prompt (short, focused on understanding only)
# ══════════════════════════════════════════════════════════════════════════════

def _build_prompt(question: str, context_turns: list[dict],
                  previous_summary: dict | None) -> str:

    context_str = ""
    if context_turns:
        last = context_turns[-1]
        context_str = f"""
Last query context (for follow-up detection):
  metric={last.get("metric")}, time={last.get("time_range")}, group_by={last.get("group_by")}
"""

    summary_str = ""
    if previous_summary and previous_summary.get("key_findings"):
        summary_str = f"""
Background from previous session:
{json.dumps(previous_summary["key_findings"], indent=2)}
"""

    return f"""You are a banking analytics assistant. Classify this question.
{summary_str}{context_str}
AVAILABLE METRICS:
{json.dumps(AVAILABLE_METRICS)}

Respond with ONE of these intents:

"data" — user wants a metric answer. Return the metric name.
  If this is a follow-up to the last query, set inherit_context=true.

"ui_command" — user wants to change the display (chart type, export, reset/clear/start over).
  Set ui_action: chart_line | chart_bar | export | clear | display_change

"clarify" — metric is genuinely ambiguous (two metrics equally fit).
  Common cases: "show transactions" (count or value?), "show loans" (count or value?),
  "show customers" (active count or revenue ranking?), "top 5" with no metric stated.
  Always provide 2-3 clarify_options with label and metric.

"unclear" — question is outside scope (why/predict/compare to competitors/jargon like NIM/LGD).
  Provide helpful unclear_message and suggest 2-3 alternative data questions.

NOTE: You do NOT need to extract time periods, regions, limits, or dimensions.
      Just identify the intent and metric. Python handles the rest.

Return ONLY valid JSON:
{{
  "intent": "data",
  "metric": "metric_name_or_null",
  "inherit_context": false,
  "ui_action": null,
  "clarify_question": null,
  "clarify_options": null,
  "unclear_message": null,
  "confidence": 0.95
}}

QUESTION: "{question}"
"""


# ══════════════════════════════════════════════════════════════════════════════
# Combine Stage 1 + Stage 2
# ══════════════════════════════════════════════════════════════════════════════

def _fuzzy_metric(name: str) -> Optional[str]:
    if not name: return None
    n = name.lower().replace(" ","_").replace("-","_")
    if n in AVAILABLE_METRICS: return n
    for m in AVAILABLE_METRICS:
        if n in m or m in n: return m
    return None


def _get_model() -> str:
    """
    Auto-select best available model.
    Priority based on benchmark results for structured JSON output:
      mistral:7b   — best structured output, reliable clarify detection
      llama3.1:8b  — best follow-up/context, strong conversation
      phi3:mini    — good structured output, fast
      llama3.2:3b  — baseline, fast but inconsistent on clarify/follow-up
    """
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        models = [m["name"] for m in r.json().get("models", [])]
        # Priority order — best to worst for this task
        for preferred in ["mistral", "llama3.1", "phi3", "llama3.2"]:
            match = next((m for m in models if preferred in m), None)
            if match:
                # Return canonical name
                if "mistral"  in match: return "mistral:7b"
                if "llama3.1" in match: return "llama3.1:8b"
                if "phi3"     in match: return "phi3:mini"
                if "llama3.2" in match: return "llama3.2:3b"
        return models[0] if models else "llama3.2:3b"
    except:
        return "llama3.2:3b"


def parse(text: str,
          context_turns: list[dict] | None = None,
          previous_summary: dict | None = None) -> QueryObject:
    """
    Two-stage parse:
      Stage 1: LLM understands intent + metric
      Stage 2: Python extracts limit, region, time, dims from raw text
    """
    ctx    = context_turns or []
    model  = _get_model()
    prompt = _build_prompt(text, ctx, previous_summary)

    # ── Stage 1: LLM ──────────────────────────────────────────────────────────
    try:
        resp = requests.post(
            OLLAMA_URL,
            json={"model": model, "prompt": prompt, "stream": False,
                  "options": {"temperature": 0.0, "num_predict": 300}},
            timeout=TIMEOUT_SEC,
        )
        resp.raise_for_status()
        raw = resp.json().get("response", "").strip()
        logger.debug(f"LLM ({model}): {raw[:200]}")

    except requests.exceptions.ConnectionError:
        return QueryObject(intent="unclear", parser="offline",
            unclear_message="Ollama is not running.\n\nStart it:\n```\nollama serve\n```")
    except requests.exceptions.Timeout:
        return QueryObject(intent="unclear", parser="offline",
            unclear_message="Ollama took too long. Try again in a few seconds.")
    except Exception as e:
        return QueryObject(intent="unclear", parser="offline",
            unclear_message=f"Connection error: {str(e)}")

    data = _extract_json(raw)
    if data is None:
        # Retry with minimal prompt
        try:
            mini = f'Classify intent for: "{text}". Return JSON: {{"intent":"data","metric":null,"inherit_context":false,"confidence":0.5}}'
            r2   = requests.post(OLLAMA_URL, json={"model": model, "prompt": mini,
                   "stream": False, "options": {"temperature": 0.0, "num_predict": 150}},
                   timeout=TIMEOUT_SEC)
            data = _extract_json(r2.json().get("response", ""))
        except: pass

    if data is None:
        return QueryObject(intent="clarify",
            clarify_question="I had trouble understanding — could you rephrase?",
            clarify_options=[], raw_text=text)

    intent = data.get("intent", "unclear")
    if intent not in ("data", "ui_command", "clarify", "unclear"):
        intent = "unclear"

    # ── Handle non-data intents immediately ───────────────────────────────────
    if intent == "ui_command":
        return QueryObject(intent="ui_command",
                           ui_action=data.get("ui_action"),
                           raw_text=text, parser="llm")

    if intent == "clarify":
        options = []
        for o in (data.get("clarify_options") or []):
            options.append(ClarifyOption(
                label      = str(o.get("label", "")),
                metric     = _fuzzy_metric(o.get("metric")),
                time_range = _extract_time(text) or "last_30_days",
                group_by   = _extract_dims(text),
                filters    = {},
            ))
        return QueryObject(intent="clarify",
                           clarify_question=data.get("clarify_question",
                               "Did you mean one of these?"),
                           clarify_options=options,
                           raw_text=text, parser="llm")

    if intent == "unclear":
        return QueryObject(intent="unclear",
                           unclear_message=data.get("unclear_message",
                               "That question is outside my scope."),
                           raw_text=text, parser="llm")

    # ── Stage 2: Python precision extraction for data queries ─────────────────
    inherit = bool(data.get("inherit_context", False))
    last    = ctx[-1] if (inherit and ctx) else {}

    # Metric from LLM, fuzzy matched
    raw_metric = data.get("metric")
    metric = _fuzzy_metric(raw_metric) if raw_metric else (
             last.get("metric") if inherit else None)

    # Time — Python reads it from raw text, falls back to context or default
    time_range = (_extract_time(text)
                  or (last.get("time_range") if inherit else None)
                  or "last_30_days")

    # Dimensions — Python reads from raw text
    raw_dims = _extract_dims(text)
    if raw_dims:
        group_by = raw_dims            # user specified → use exactly these
    elif inherit:
        group_by = list(last.get("group_by") or [])
    else:
        group_by = []

    # Filters
    base = {k: v for k, v in (last.get("filters") or {}).items()
            if inherit and k not in ("limit",)} if inherit else {}
    filters = dict(base)

    # Region — Python reads from raw text (whitelist + aliases)
    region = _extract_region(text)
    if region: filters["region"] = region

    # Product — Python reads from raw text
    product = _extract_product(text)
    if product: filters["product"] = product

    # Limit — Python reads "top N" from raw text (user stated it explicitly)
    # _extract_limit uses regex so it always returns a clean int or None
    limit = _extract_limit(text)
    if limit and isinstance(limit, int): filters["limit"] = limit

    # Order — Python reads "lowest/worst" from raw text
    filters["order"] = _extract_order(text)

    # No metric identified — ask for clarification
    if not metric:
        return QueryObject(intent="clarify",
            clarify_question="Which metric would you like to see?",
            clarify_options=[
                ClarifyOption(label="Total Revenue",       metric="total_revenue"),
                ClarifyOption(label="Top customers",       metric="revenue_per_customer"),
                ClarifyOption(label="Active customers",    metric="active_customers"),
                ClarifyOption(label="Delinquency rate",    metric="delinquency_rate"),
            ],
            raw_text=text, parser="llm")

    result = QueryObject(
        intent          = "data",
        metric          = metric,
        time_range      = time_range,
        group_by        = group_by,
        filters         = filters,
        inherit_context = inherit,
        confidence      = float(data.get("confidence", 0.9)),
        raw_text        = text,
        parser          = f"llm:{model}",
    )

    # ── Stage 3: LLM validates the combined result ────────────────────────────
    validated = _validate_with_llm(text, result, model)

    # If Stage 3 already decided to clarify, skip Stage 4
    if validated.intent != "data":
        return validated

    # ── Stage 4: SQL self-check ────────────────────────────────────────────────
    # Generate SQL, ask LLM "does this SQL answer the question?"
    # Fully internal — user never sees this. Self-healing before execution.
    return _sql_self_check(text, validated, model)


def _extract_json(raw: str) -> dict | None:
    if not raw: return None
    raw = re.sub(r"```json\s*", "", raw)
    raw = re.sub(r"```\s*", "", raw)
    m = re.search(r'\{.*\}', raw, re.DOTALL)
    if not m: return None
    try: return json.loads(m.group())
    except: return None



# ══════════════════════════════════════════════════════════════════════════════
# STAGE 3 — LLM validation of combined result
# Short prompt. Not parsing again — reviewing the work.
# Only fires when there's a genuine reason to doubt Stage 1+2.
# ══════════════════════════════════════════════════════════════════════════════

_VALIDATION_PROMPT = """A user asked: "{question}"

Our system interpreted this as:
  metric:     {metric}
  time_range: {time_range}
  group_by:   {group_by}
  filters:    {filters}

Available metrics: {metrics}

Does this interpretation make sense for what the user asked?
Consider:
- Is the metric right for their intent?
- Does "top N" with this metric make sense? (e.g. "top 5" + transaction_count with no group_by = nonsense)
- Would a good analyst execute this, or ask a clarifying question first?

Return ONLY this JSON:
{{
  "makes_sense": true,
  "needs_clarification": false,
  "clarify_question": null,
  "clarify_options": null
}}"""


def _validate_with_llm(question: str, query: QueryObject, model: str) -> QueryObject:
    """
    Stage 3: LLM reviews the combined Stage 1+2 result.
    Returns the original query if it makes sense.
    Returns a clarify QueryObject if the combination doesn't make sense.
    """
    # Only validate when there's a reason to be uncertain
    # Skip validation for clearly correct results — saves time
    needs_check = (
        # "top N" with a count metric and no group_by is always wrong
        (query.filters.get("limit") and query.metric in
         ("transaction_count", "loan_count", "active_customers", "new_customers")
         and not query.group_by)
        # No group_by on revenue_per_customer
        or (query.metric == "revenue_per_customer" and not query.group_by)
        # Confidence below threshold from Stage 1
        or query.confidence < 0.75
    )

    if not needs_check:
        return query  # fast path — Stage 1+2 result is good

    prompt = _VALIDATION_PROMPT.format(
        question   = question,
        metric     = query.metric,
        time_range = query.time_range,
        group_by   = query.group_by,
        filters    = {k:v for k,v in query.filters.items() if v and k != "order"},
        metrics    = AVAILABLE_METRICS,
    )

    try:
        resp = requests.post(
            OLLAMA_URL,
            json={"model": model, "prompt": prompt, "stream": False,
                  "options": {"temperature": 0.0, "num_predict": 200}},
            timeout=15,
        )
        resp.raise_for_status()
        data = _extract_json(resp.json().get("response", ""))
        if not data:
            return query  # validation failed to parse — keep original

        if data.get("makes_sense", True) and not data.get("needs_clarification", False):
            return query  # Stage 3 confirmed — proceed

        # Stage 3 says something is wrong
        clarify_q    = data.get("clarify_question", "Could you clarify what you're looking for?")
        clarify_opts = data.get("clarify_options") or []

        # If no options provided, build sensible defaults based on metric context
        if not clarify_opts and query.metric in ("transaction_count", "total_revenue"):
            clarify_opts = [
                {"label": "Transaction count (how many transactions?)",
                 "metric": "transaction_count", "group_by": ["channel"], "filters": {}},
                {"label": "Transaction value (how much revenue?)",
                 "metric": "total_revenue", "group_by": [], "filters": {}},
                {"label": "Top customers by revenue",
                 "metric": "revenue_per_customer", "group_by": ["customer"],
                 "filters": {"limit": query.filters.get("limit")}},
            ]

        options = [ClarifyOption(
            label      = o.get("label",""),
            metric     = _fuzzy_metric(o.get("metric")),
            time_range = query.time_range,
            group_by   = o.get("group_by", []),
            filters    = o.get("filters", {}),
        ) for o in clarify_opts]

        return QueryObject(
            intent           = "clarify",
            clarify_question = clarify_q,
            clarify_options  = options,
            raw_text         = question,
            parser           = f"llm:{model}+validated",
        )

    except Exception as e:
        logger.debug(f"Stage 3 validation error (non-fatal): {e}")
        return query  # validation error — keep original, don't break flow



# ══════════════════════════════════════════════════════════════════════════════
# STAGE 4 — Internal SQL self-check
# Generate SQL from the query object, then ask the LLM:
# "Does this SQL actually answer the original question?"
# If not — correct it before execution. User never sees this happening.
# ══════════════════════════════════════════════════════════════════════════════

def _generate_sql_preview(query: QueryObject) -> Optional[str]:
    """Generate the SQL that would execute — without running it."""
    try:
        import sys, os
        sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        from api.resolver import METRIC_SQL
        spec    = METRIC_SQL.get(query.metric)
        if not spec: return None
        allowed = spec["dims"]

        user_gb      = list(query.group_by)
        effective_gb = user_gb if user_gb else list(spec["force_group_by"])
        user_limit   = query.filters.get("limit")
        effective_limit = (int(user_limit) if user_limit is not None
                           else (spec["default_limit"] if not user_gb and spec["default_limit"] else None))

        date_from, date_to = resolve_date_range(query.time_range or "last_30_days")

        joins = set()
        if spec["base_join"]: joins.add(spec["base_join"])
        for d in effective_gb:
            if d in spec.get("dim_joins", {}): joins.add(spec["dim_joins"][d])
        join_str = " ".join(joins)

        conditions = [spec["where"],
                      f"{spec['date_col']} BETWEEN '{date_from}' AND '{date_to}'"]
        for col, val in query.filters.items():
            if col in ("limit","order"): continue
            if col in allowed: conditions.append(f"{allowed[col]} = '{val}'")
        where = " AND ".join(f"({c})" for c in conditions)

        order       = str(query.filters.get("order","DESC")).upper()
        group_exprs = [allowed[d] for d in effective_gb if d in allowed]

        if group_exprs:
            dim = group_exprs[0] if len(group_exprs)==1 else " || ' / ' || ".join(group_exprs)
            sql = (f"SELECT {dim} AS dimension, {spec['select']} AS value "
                   f"FROM {spec['table']} {join_str} WHERE {where} "
                   f"GROUP BY {', '.join(group_exprs)} ORDER BY value {order}")
            if effective_limit: sql += f" LIMIT {effective_limit}"
        else:
            sql = (f"SELECT NULL AS dimension, {spec['select']} AS value "
                   f"FROM {spec['table']} {join_str} WHERE {where}")
        return sql
    except Exception as e:
        logger.debug(f"SQL preview generation error: {e}")
        return None


_SQL_CHECK_PROMPT = """A user asked: "{question}"

We are about to execute this SQL:
{sql}

Does this SQL correctly answer what the user asked?

Check for these common mistakes:
1. COUNT(*) with LIMIT but no GROUP BY — returns N rows of the same total, meaningless
2. Metric aggregates the wrong thing (e.g. summing when user wants a count)
3. Missing GROUP BY when user said "by region/product/channel"
4. Time range is wrong (e.g. TODAY when no time was mentioned — should be last_30_days)
5. LIMIT applied when user did not say "top N"

If the SQL is correct: {{"correct": true, "issue": null, "fix": null}}
If the SQL has an issue: {{"correct": false, "issue": "description", "fix": "what to change"}}

Return ONLY valid JSON."""


def _sql_self_check(question: str, query: QueryObject, model: str) -> QueryObject:
    """
    Stage 4: Generate SQL, ask LLM if it answers the question.
    If not — apply the suggested fix and re-check once.
    Fully internal. User never sees this.
    """
    sql = _generate_sql_preview(query)
    if not sql:
        return query  # can't generate SQL — pass through

    prompt = _SQL_CHECK_PROMPT.format(question=question, sql=sql)

    try:
        resp = requests.post(
            OLLAMA_URL,
            json={"model": model, "prompt": prompt, "stream": False,
                  "options": {"temperature": 0.0, "num_predict": 150}},
            timeout=15,
        )
        resp.raise_for_status()
        data = _extract_json(resp.json().get("response","").strip())
        if not data: return query

        if data.get("correct", True):
            logger.info(f"Stage 4: SQL self-check passed ✓")
            return query  # SQL is correct — proceed

        issue = data.get("issue","")
        fix   = data.get("fix","")
        logger.info(f"Stage 4: SQL issue detected — {issue} | fix: {fix}")

        # Apply fix based on what LLM identified
        fixed = QueryObject(
            intent          = query.intent,
            metric          = query.metric,
            time_range      = query.time_range,
            group_by        = list(query.group_by),
            filters         = dict(query.filters),
            inherit_context = query.inherit_context,
            confidence      = query.confidence,
            raw_text        = query.raw_text,
            parser          = query.parser + "+selfcheck",
        )

        issue_lower = issue.lower()

        # Fix: COUNT with LIMIT but no GROUP BY → clarify what they want ranked
        if "count" in issue_lower and "limit" in issue_lower and "group" in issue_lower:
            return QueryObject(
                intent           = "clarify",
                clarify_question = "Did you mean:",
                clarify_options  = [
                    ClarifyOption(label=f"Top {fixed.filters.get('limit',5)} customers by revenue",
                                  metric="revenue_per_customer",
                                  time_range=fixed.time_range,
                                  group_by=["customer"],
                                  filters={"limit": fixed.filters.get("limit",5)}),
                    ClarifyOption(label="Transaction count by channel",
                                  metric="transaction_count",
                                  time_range=fixed.time_range,
                                  group_by=["channel"], filters={}),
                    ClarifyOption(label="Revenue by channel",
                                  metric="total_revenue",
                                  time_range=fixed.time_range,
                                  group_by=["channel"], filters={}),
                ],
                raw_text = question,
                parser   = query.parser + "+selfcheck",
            )

        # Fix: missing GROUP BY → add the likely dimension
        if "group by" in issue_lower or "missing" in issue_lower:
            if "region" in fix.lower():    fixed.group_by = ["region"]
            elif "product" in fix.lower(): fixed.group_by = ["product"]
            elif "channel" in fix.lower(): fixed.group_by = ["channel"]
            elif "customer" in fix.lower():fixed.group_by = ["customer"]

        # Fix: time range wrong (today with no time mentioned)
        if "time" in issue_lower or "today" in issue_lower:
            if "last_30_days" in fix.lower() or "30" in fix:
                fixed.time_range = "last_30_days"
            elif "last_quarter" in fix.lower():
                fixed.time_range = "last_quarter"

        # Fix: unwanted limit
        if "limit" in issue_lower and "not" in issue_lower:
            fixed.filters.pop("limit", None)

        logger.info(f"Stage 4: Applied fix → metric={fixed.metric}, "
                    f"group_by={fixed.group_by}, time={fixed.time_range}")
        return fixed

    except Exception as e:
        logger.debug(f"Stage 4 self-check error (non-fatal): {e}")
        return query  # error — keep original, don't break flow


def check_ollama() -> dict:
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        models = [m["name"] for m in r.json().get("models", [])]
        model  = _get_model()
        has    = any(model.split(":")[0] in m for m in models)
        return {"running": True, "models": models, "target_model": model,
                "model_available": has,
                "status": "ready" if has else "model_not_pulled"}
    except requests.exceptions.ConnectionError:
        return {"running": False, "status": "ollama_not_running"}
    except Exception as e:
        return {"running": False, "status": "error", "error": str(e)}
