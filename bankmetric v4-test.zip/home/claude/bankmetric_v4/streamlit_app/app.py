"""
BankMetric v4 — Streamlit Chat UI

Features:
  - Clarification options as clickable buttons
  - Turn counter with warning at 8, force reset at 12
  - Session summary on reset
  - Summary carried to new conversation as context
  - Chart type switching (line/bar)
  - Clean empty state and error handling
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st
import requests
import pandas as pd
import json

API_URL = "http://localhost:8000"
WARN_AT  = 8
LIMIT_AT = 12

st.set_page_config(
    page_title="BankMetric",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.user-msg {
    background:#E8F4FD; border-left:4px solid #0A8F8F;
    padding:12px 16px; border-radius:0 10px 10px 0; margin:8px 0;
}
.bot-header {
    background:#F8F9FA; border-left:4px solid #6C757D;
    padding:12px 16px; border-radius:0 10px 10px 0; margin:8px 0 4px 0;
}
.clarify-msg {
    background:#FFF8E8; border-left:4px solid #BA7517;
    padding:12px 16px; border-radius:0 10px 10px 0; margin:8px 0;
    color:#633806;
}
.unclear-msg {
    background:#F3F0FF; border-left:4px solid #534AB7;
    padding:12px 16px; border-radius:0 10px 10px 0; margin:8px 0;
    color:#3C3489;
}
.ui-msg {
    background:#F0FFF4; border-left:4px solid #3B6D11;
    padding:10px 16px; border-radius:0 10px 10px 0; margin:8px 0;
    color:#27500A;
}
.error-msg {
    background:#FFF3F3; border-left:4px solid #DC3545;
    padding:12px 16px; border-radius:0 10px 10px 0; margin:8px 0;
}
.empty-msg {
    background:#F8F9FA; border-left:4px solid #6C757D;
    padding:12px 16px; border-radius:0 10px 10px 0; margin:8px 0;
    color:#495057;
}
.summary-box {
    background:#E1F5EE; border:1px solid #0F6E56;
    padding:16px; border-radius:10px; margin:12px 0;
}
.metric-total { font-size:30px; font-weight:700; color:#0A8F8F; }
.metric-label { font-size:12px; color:#6B7D99; text-transform:uppercase; letter-spacing:0.5px; }
.pill-llm    { background:#E1F5EE; color:#085041; padding:2px 8px; border-radius:12px; font-size:11px; font-weight:600; }
.pill-offline{ background:#FCEBEB; color:#A32D2D; padding:2px 8px; border-radius:12px; font-size:11px; font-weight:600; }
.pill-conf   { background:#E6F1FB; color:#0C447C; padding:2px 8px; border-radius:12px; font-size:11px; }
.turn-warn   { background:#FAEEDA; border:1px solid #BA7517; padding:10px 14px; border-radius:8px; margin:8px 0; }
</style>
""", unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────────
DEFAULTS = {
    "messages":         [],
    "context_window":   [],   # last 3 query contexts for LLM
    "turn_count":       0,
    "previous_summary": {},   # from last session
    "session_summary":  {},   # current session summary
    "last_chart_type":  "bar",
    "last_data":        None,
    "metrics_list":     [],
    "warn_dismissed":   False,
}
for k, v in DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ── API helpers ────────────────────────────────────────────────────────────────

def ask_api(question: str, clarify_resolved: dict = None) -> dict:
    """Send question to API. If clarify_resolved, send that directly."""
    if clarify_resolved:
        # User clicked a clarification option — execute directly
        try:
            return requests.post(f"{API_URL}/ask",
                json={
                    "question": clarify_resolved.get("label", question),
                    "conversation_context": st.session_state.context_window,
                    "previous_summary": st.session_state.previous_summary,
                    # Pre-resolved — send as structured query hint in question
                },
                timeout=35).json()
        except Exception as e:
            return {"success": False, "intent": "unclear",
                    "error": str(e), "suggestion": ""}
    try:
        return requests.post(f"{API_URL}/ask",
            json={
                "question": question,
                "conversation_context": st.session_state.context_window,
                "previous_summary": st.session_state.previous_summary,
            },
            timeout=35).json()
    except requests.exceptions.Timeout:
        return {"success": False, "intent": "unclear",
                "error": "Ollama is loading — wait a few seconds and try again.",
                "suggestion": ""}
    except requests.exceptions.ConnectionError:
        return {"success": False, "intent": "unclear",
                "error": "Cannot connect to BankMetric API. Run: python main.py",
                "suggestion": ""}
    except Exception as e:
        return {"success": False, "intent": "unclear",
                "error": str(e), "suggestion": ""}


def generate_summary_api() -> dict:
    """Ask API to generate a session summary."""
    try:
        # Build history string
        history = []
        for msg in st.session_state.messages:
            if msg["role"] == "user":
                history.append({"role": "user", "content": msg["content"]})
            elif msg.get("type") == "data" and msg.get("data", {}).get("success"):
                d = msg["data"]
                history.append({
                    "role": "assistant",
                    "content": f"{d.get('display_name')} = {d.get('formatted_total')} ({d.get('time_range')})"
                })
        return requests.post(f"{API_URL}/ask",
            json={"question": f"Summarise this conversation: {json.dumps(history[-20:])}",
                  "conversation_context": []},
            timeout=30).json()
    except:
        return {}


def load_metrics():
    try: return requests.get(f"{API_URL}/metrics", timeout=5).json()
    except: return []


# ── UI command handler ─────────────────────────────────────────────────────────

UI_MESSAGES = {
    "chart_line":     "✅ Chart type changed to line.",
    "chart_bar":      "✅ Chart type changed to bar.",
    "chart_change":   "Try: 'convert to line chart' or 'convert to bar chart'.",
    "display_change": ("Display layout changes aren't supported yet. "
                       "Try a data question like 'break it down by region'."),
    "export":         "Export is coming in Phase 2. For now, use the download button in the chart.",
    "clear":          "__clear__",
}

def handle_ui_command(action: str, question: str) -> str:
    if action == "chart_line":
        st.session_state.last_chart_type = "line"
    elif action == "chart_bar":
        st.session_state.last_chart_type = "bar"
    elif action == "clear":
        do_reset(carry_summary=True)
        return "__clear__"
    return UI_MESSAGES.get(action, f"Command '{action}' acknowledged.")


# ── Reset / summary ────────────────────────────────────────────────────────────

def do_reset(carry_summary: bool = True):
    """Generate summary, carry context forward, reset state."""
    # Generate summary from current session
    if st.session_state.messages and carry_summary:
        with st.spinner("📝 Summarising session..."):
            try:
                from parser.conversation import generate_summary, ConversationState
                state = ConversationState(messages=st.session_state.messages)
                summary = generate_summary(state)
                if summary:
                    st.session_state.previous_summary = summary
            except:
                pass

    # Reset conversation state
    st.session_state.messages       = []
    st.session_state.context_window = []
    st.session_state.turn_count     = 0
    st.session_state.last_chart_type = "bar"
    st.session_state.last_data       = None
    st.session_state.warn_dismissed  = False
    st.session_state.session_summary = {}


# ── Render helpers ─────────────────────────────────────────────────────────────

def render_data(data: dict, chart_type: str = "bar"):
    results  = data.get("results", [])
    group_by = data.get("group_by", [])
    has_dims = bool(group_by) and results and results[0].get("dimension")
    glabel   = " × ".join(group_by) if group_by else "Total"

    parser   = data.get("parser_used", "llm")
    conf     = data.get("confidence", 1.0)
    pbadge   = (f'<span class="pill-llm">LLM</span> <span class="pill-conf">{int(conf*100)}%</span>'
                if parser != "offline"
                else '<span class="pill-offline">Ollama offline</span>')

    empty_note = data.get("empty_note", "")

    st.markdown(f"""
    <div class="bot-header">
      <div style="margin-bottom:4px">{pbadge}</div>
      <span class="metric-label">{data.get('display_name','')} · {data.get('time_range','')}
      &nbsp;|&nbsp; {data.get('date_from','')} → {data.get('date_to','')}</span><br>
      <span class="metric-total">{data.get('formatted_total','')}</span>
      <span style="font-size:12px;color:#9CA3AF;margin-left:12px">
        {data.get('row_count',0)} {'rows' if has_dims else 'result'} · by {glabel}
      </span>
    </div>""", unsafe_allow_html=True)

    if empty_note:
        st.markdown(f'<div class="empty-msg">💡 {empty_note}</div>',
                    unsafe_allow_html=True)
        return

    if has_dims and results:
        df = pd.DataFrame(results)[["dimension","value","formatted_value"]]
        df.columns = [glabel.title(), "Value", data.get("display_name","Value")]
        df = df.sort_values("Value", ascending=False)
        c1, c2 = st.columns([1, 1])
        with c1:
            st.dataframe(df[[glabel.title(), data.get("display_name","Value")]],
                        use_container_width=True, hide_index=True)
        with c2:
            cdf = df.set_index(glabel.title())[["Value"]]
            cdf.columns = [data.get("display_name","Value")]
            if chart_type == "line": st.line_chart(cdf, height=260)
            else:                    st.bar_chart(cdf, height=260)

    with st.expander("🔍 Query details", expanded=False):
        qo = data.get("query_object", {})
        c1, c2, c3, c4 = st.columns(4)
        c1.markdown(f"**Metric**\n`{qo.get('metric','')}`")
        c2.markdown(f"**Time**\n`{qo.get('time_range','')}`")
        c3.markdown(f"**Group by**\n`{', '.join(qo.get('group_by',[])) or 'none'}`")
        c4.markdown(f"**Filters**\n`{json.dumps({k:v for k,v in qo.get('filters',{}).items() if v and k!='order'})}`")
        if data.get("sql_generated"):
            st.code(data["sql_generated"], language="sql")


def render_clarify(data: dict, msg_idx: int):
    q    = data.get("clarify_question", "Did you mean one of these?")
    opts = data.get("clarify_options", [])
    st.markdown(f'<div class="clarify-msg">🤔 <strong>{q}</strong></div>',
                unsafe_allow_html=True)
    if opts:
        cols = st.columns(min(len(opts), 3))
        for i, opt in enumerate(opts):
            with cols[i % 3]:
                if st.button(opt.get("label", f"Option {i+1}"),
                             key=f"clarify_{msg_idx}_{i}",
                             use_container_width=True):
                    handle_clarify_click(opt)
                    st.rerun()
    else:
        st.info("Please rephrase your question.")


def render_suggestions(data: dict):
    metric   = data.get("metric", "")
    group_by = data.get("group_by", [])
    sugg     = []

    if "region"  not in group_by: sugg.append("Break it down by region")
    if "product" not in group_by: sugg.append("Break it down by product")
    if "channel" not in group_by: sugg.append("Which channel is most used?")
    if "customer" not in group_by and metric not in ("active_customers","new_customers","churn_rate"):
        sugg.append("Show top 10 customers by revenue")

    tr = data.get("time_range", "")
    if   "Quarter" in tr: sugg.append("What about this quarter?")
    elif "Month"   in tr: sugg.append("What about last quarter?")
    else:                 sugg.append("Show me last quarter")

    if metric == "total_revenue":        sugg.append("Show transaction count")
    elif metric == "active_customers":   sugg.append("What is the churn rate?")
    elif metric in ("total_loan_value","loan_count"): sugg.append("Show delinquency rate")

    sugg = list(dict.fromkeys(sugg))[:4]  # deduplicate, max 4
    if sugg:
        st.markdown("**💡 Follow-up:**")
        cols = st.columns(len(sugg))
        for i, s in enumerate(sugg):
            if cols[i].button(s, key=f"sugg_{len(st.session_state.messages)}_{i}"):
                handle_question(s); st.rerun()


# ── Question handlers ──────────────────────────────────────────────────────────

def handle_clarify_click(option: dict):
    """User clicked a clarification option — execute it directly."""
    label = option.get("label", "Selected option")
    st.session_state.messages.append({"role": "user", "content": f"[Selected: {label}]"})
    with st.spinner("🧠 Getting answer..."):
        # Build a direct question from the option
        direct_q = label
        data = ask_api(direct_q)
    _process_response(label, data, count_turn=True)


def handle_question(question: str):
    st.session_state.messages.append({"role": "user", "content": question})
    intent = None

    with st.spinner("🧠 Thinking..."):
        data = ask_api(question)

    intent = data.get("intent", "data")

    # UI commands don't count as turns
    if intent == "ui_command":
        action = data.get("ui_action", "")
        result = handle_ui_command(action, question)
        if result == "__clear__":
            st.rerun(); return
        st.session_state.messages.append({
            "role": "assistant", "type": "ui_msg",
            "content": question, "text": result,
        })
        # Re-render last data with new chart type if chart changed
        if action in ("chart_line", "chart_bar"):
            _update_last_chart_type()
        return

    # Clarification — doesn't count as a turn
    if intent == "clarify":
        st.session_state.messages.append({
            "role": "assistant", "type": "clarify",
            "content": question, "data": data,
        })
        return

    # Data or unclear — counts as a turn
    _process_response(question, data, count_turn=True)


def _process_response(question: str, data: dict, count_turn: bool = False):
    intent = data.get("intent", "unclear")
    st.session_state.messages.append({
        "role": "assistant", "type": intent,
        "content": question, "data": data,
        "chart_type": st.session_state.last_chart_type,
    })
    if count_turn and intent in ("data", "unclear"):
        st.session_state.turn_count += 1

    if intent == "data" and data.get("success"):
        st.session_state.last_data = data
        st.session_state.last_chart_type = "bar"
        # Update context window (last 3 turns)
        ctx = {
            "metric":     data.get("metric"),
            "time_range": data.get("query_object", {}).get("time_range"),
            "group_by":   data.get("group_by", []),
            "filters":    {k: v for k, v in
                          data.get("query_object", {}).get("filters", {}).items()
                          if k != "limit"},
        }
        st.session_state.context_window.append(ctx)
        if len(st.session_state.context_window) > 3:
            st.session_state.context_window = st.session_state.context_window[-3:]


def _update_last_chart_type():
    """Update chart_type on the last data message for re-render."""
    for msg in reversed(st.session_state.messages):
        if msg.get("type") == "data" and msg.get("data", {}).get("success"):
            msg["chart_type"] = st.session_state.last_chart_type
            break


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("📊 BankMetric")
    st.caption("Conversational Analytics · v4")

    # New conversation — prominent at top
    col1, col2 = st.columns([3, 1])
    with col1:
        if st.button("🔄 New conversation", use_container_width=True, type="primary"):
            do_reset(carry_summary=True)
            st.rerun()
    with col2:
        tc = st.session_state.turn_count
        color = "#DC3545" if tc >= WARN_AT else "#28A745"
        st.markdown(f'<div style="text-align:center;padding:6px;background:{color};'
                    f'color:white;border-radius:6px;font-size:12px;font-weight:600;">'
                    f'{tc}/{LIMIT_AT}</div>', unsafe_allow_html=True)

    st.divider()

    # API / Ollama status
    try:
        health = requests.get(f"{API_URL}/health", timeout=3).json()
        st.success("✅ API connected")
        counts = health.get("counts", {})
        st.markdown(f"**Demo data:** {counts.get('transactions',0):,} txns · "
                    f"{counts.get('customers',0):,} customers · "
                    f"{counts.get('loans',0):,} loans")
        ollama = health.get("ollama", {})
        st.divider()
        st.markdown("**🧠 Ollama LLM**")
        if ollama.get("running") and ollama.get("model_available"):
            st.success(f"✅ Ready — `{ollama.get('target_model')}`")
        elif ollama.get("running"):
            st.warning("⚠️ Model not pulled")
            st.code(f"ollama pull {ollama.get('target_model','llama3.2:3b')}")
        else:
            st.error("❌ Not running")
            st.code("ollama serve")
    except:
        st.error("❌ API not reachable\n`python main.py`")

    # Previous session context
    if st.session_state.previous_summary.get("key_findings"):
        st.divider()
        st.markdown("**📋 Context from last session**")
        for f in st.session_state.previous_summary["key_findings"][:3]:
            st.markdown(f"• {f.get('insight', f.get('value', ''))}")
        if st.button("Clear context", key="clear_ctx"):
            st.session_state.previous_summary = {}
            st.rerun()

    st.divider()
    st.markdown("**What you can ask:**")
    st.markdown("""
Revenue · Customers · Loans · Churn · Delinquency

By region · product · channel · customer

Last quarter · this year · YTD · MTD

Follow-ups: *"break that down by region"*

Chart: *"convert to line chart"*
    """)

    st.divider()
    st.markdown("**📐 Governed metrics**")
    if not st.session_state.metrics_list:
        st.session_state.metrics_list = load_metrics()
    for m in st.session_state.metrics_list:
        with st.expander(m.get("display_name", "")):
            st.caption(m.get("description", ""))
            st.code(m.get("formula", ""), language="sql")


# ── Main area ──────────────────────────────────────────────────────────────────
st.markdown("## 💬 Ask anything about your metrics")
st.caption("Powered by local Ollama LLM · No data leaves your machine")

# Turn warning banner
tc = st.session_state.turn_count
if tc >= LIMIT_AT:
    st.markdown(f"""
    <div class="turn-warn">
    🛑 <strong>Conversation limit reached ({tc} turns).</strong>
    Start a new conversation to continue. Your findings are saved as context.
    </div>""", unsafe_allow_html=True)
    if st.button("🔄 Start new conversation (keep findings)", type="primary"):
        do_reset(carry_summary=True); st.rerun()
    st.stop()

elif tc >= WARN_AT and not st.session_state.warn_dismissed:
    c1, c2, c3 = st.columns([3, 1, 1])
    with c1:
        st.markdown(f"""<div class="turn-warn">
        ⚠️ <strong>Conversation getting long ({tc}/{LIMIT_AT} turns).</strong>
        Accuracy may reduce. Consider starting fresh.
        </div>""", unsafe_allow_html=True)
    with c2:
        if st.button("Start fresh", key="warn_reset"):
            do_reset(carry_summary=True); st.rerun()
    with c3:
        if st.button("Keep going", key="warn_dismiss"):
            st.session_state.warn_dismissed = True; st.rerun()

# Show previous session context note
if st.session_state.previous_summary.get("key_findings") and not st.session_state.messages:
    last_q = st.session_state.previous_summary.get("last_question", "")
    st.markdown(f"""
    <div class="summary-box">
    📋 <strong>Context loaded from previous session.</strong>
    I know what was found last time. You can ask follow-up questions directly.<br>
    <small>Last question: <em>"{last_q}"</em></small>
    </div>""", unsafe_allow_html=True)

# Empty state
if not st.session_state.messages:
    st.markdown("**Try asking:**")
    examples = [
        "Show me top 5 customers by revenue",
        "Revenue by region last quarter",
        "Which channel is most used?",
        "What is our delinquency rate by product?",
        "Active customers by region this month",
        "Churn rate by region last year",
        "Top 3 products by loan value",
        "New customers last quarter",
    ]
    cols = st.columns(3)
    for i, q in enumerate(examples):
        if cols[i % 3].button(q, key=f"ex_{i}", use_container_width=True):
            handle_question(q); st.rerun()
    st.divider()

# Chat history
for i, msg in enumerate(st.session_state.messages):
    if msg["role"] == "user":
        st.markdown(
            f'<div class="user-msg">👤 <strong>You:</strong> {msg["content"]}</div>',
            unsafe_allow_html=True)
    else:
        mtype = msg.get("type", "data")
        data  = msg.get("data", {})

        if mtype == "ui_msg":
            st.markdown(f'<div class="ui-msg">💡 {msg.get("text","")}</div>',
                        unsafe_allow_html=True)
            if "chart" in msg.get("text","").lower():
                for prev in reversed(st.session_state.messages[:i]):
                    if prev.get("type") == "data" and prev.get("data",{}).get("success"):
                        st.markdown("**📊 BankMetric:** *(chart updated)*")
                        render_data(prev["data"], st.session_state.last_chart_type)
                        break

        elif mtype == "clarify":
            render_clarify(data, i)

        elif mtype == "unclear":
            msg_text = data.get("error") or data.get("unclear_message", "")
            suggestion = data.get("suggestion", "")
            st.markdown(f"""
            <div class="unclear-msg">
            💭 {msg_text}
            {"<br><small>" + suggestion + "</small>" if suggestion else ""}
            </div>""", unsafe_allow_html=True)

        elif mtype == "data":
            if data.get("success"):
                st.markdown("**📊 BankMetric:**")
                chart_type = msg.get("chart_type", "bar")
                if i == len(st.session_state.messages) - 1:
                    chart_type = st.session_state.last_chart_type
                render_data(data, chart_type)
                if i == len(st.session_state.messages) - 1:
                    render_suggestions(data)
            else:
                err = data.get("error", "Something went wrong.")
                sug = data.get("suggestion", "")
                st.markdown(f"""
                <div class="error-msg">
                ❌ <strong>{err}</strong>
                {"<br><small>" + sug + "</small>" if sug else ""}
                </div>""", unsafe_allow_html=True)

# Input — disabled at limit
st.divider()
disabled = st.session_state.turn_count >= LIMIT_AT
with st.form(key="chat_form", clear_on_submit=True):
    c1, c2 = st.columns([5, 1])
    with c1:
        user_input = st.text_input(
            "Ask...",
            placeholder="e.g. Show top 5 customers by revenue in North America last quarter",
            label_visibility="collapsed",
            disabled=disabled,
        )
    with c2:
        submitted = st.form_submit_button(
            "Ask →", use_container_width=True, disabled=disabled)
    if submitted and user_input.strip():
        handle_question(user_input.strip()); st.rerun()
