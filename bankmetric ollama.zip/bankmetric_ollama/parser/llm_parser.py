"""
BankMetric - LLM Parser (Ollama)
v2 — fixed follow-up context handling.

Key fix: follow-up questions are detected in Python FIRST.
Inherited fields (metric, time_range, filters) are locked in before
the LLM is called. The LLM only fills in what is genuinely new.

Requires:
  - Ollama running locally: http://localhost:11434
  - Model pulled: ollama pull llama3.2:3b
"""

import re
import json
import requests
import logging
from datetime import date, timedelta
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2:3b"
TIMEOUT_SEC  = 30


# ── Structured Query Object ────────────────────────────────────────────────────

@dataclass
class QueryObject:
    metric: str | None = None
    time_range: str | None = None
    group_by: list[str] = field(default_factory=list)
    filters: dict = field(default_factory=dict)
    raw_text: str = ""
    confidence: float = 1.0
    error: str | None = None


# ── Date range resolver ────────────────────────────────────────────────────────

def resolve_date_range(time_range: str, raw: str = "") -> tuple[str, str]:
    today = date.today()

    def quarter_start(d): return date(d.year, ((d.month - 1) // 3) * 3 + 1, 1)
    def month_start(d):   return date(d.year, d.month, 1)

    if time_range == "last_quarter":
        qs = quarter_start(today)
        qe = qs - timedelta(days=1)
        return quarter_start(qe).isoformat(), qe.isoformat()
    if time_range == "this_quarter":
        return quarter_start(today).isoformat(), today.isoformat()
    if time_range == "last_month":
        first = month_start(today)
        end   = first - timedelta(days=1)
        return month_start(end).isoformat(), end.isoformat()
    if time_range == "this_month":
        return month_start(today).isoformat(), today.isoformat()
    if time_range == "last_year":
        return date(today.year-1,1,1).isoformat(), date(today.year-1,12,31).isoformat()
    if time_range == "this_year":
        return date(today.year,1,1).isoformat(), today.isoformat()
    if time_range == "year_to_date":
        return date(today.year,1,1).isoformat(), today.isoformat()
    if time_range == "last_30_days":
        return (today-timedelta(days=30)).isoformat(), today.isoformat()
    if time_range == "last_90_days":
        return (today-timedelta(days=90)).isoformat(), today.isoformat()
    if time_range == "today":
        return today.isoformat(), today.isoformat()
    if time_range == "this_week":
        return (today-timedelta(days=today.weekday())).isoformat(), today.isoformat()
    if time_range == "last_week":
        end = today - timedelta(days=today.weekday()+1)
        return (end-timedelta(days=6)).isoformat(), end.isoformat()
    m = re.search(r"last[_\s](\d+)[_\s]days?", time_range or "")
    if m:
        return (today-timedelta(days=int(m.group(1)))).isoformat(), today.isoformat()
    return (today-timedelta(days=30)).isoformat(), today.isoformat()


# ── Available metric registry ──────────────────────────────────────────────────

AVAILABLE_METRICS = [
    "total_revenue", "transaction_count", "average_transaction",
    "revenue_per_customer", "active_customers", "new_customers",
    "churn_rate", "total_loan_value", "loan_count", "delinquency_rate",
]

AVAILABLE_DIMS     = ["region", "product", "channel", "customer"]
AVAILABLE_REGIONS  = ["North America", "Europe", "APAC", "Latin America"]
AVAILABLE_PRODUCTS = ["Mortgage", "Personal Loan", "Auto Loan", "Business Loan", "Credit Card"]
AVAILABLE_CHANNELS = ["Branch", "Online", "Mobile", "Agent"]

TIME_RANGE_VALUES = [
    "today", "this_week", "last_week", "this_month", "last_month",
    "this_quarter", "last_quarter", "this_year", "last_year",
    "year_to_date", "last_30_days", "last_90_days",
]

# ── Follow-up detection (Python, not LLM) ─────────────────────────────────────
# These phrases mean: inherit the previous metric and time_range.
# The LLM is only asked what CHANGED (the new dimension or time).

FOLLOW_UP_PHRASES = [
    "break that", "break it", "now by", "also by", "and by",
    "split by", "drill down", "same for", "show me that",
    "what about", "how about", "now show",
]

# These phrases change only the time range — metric and dims are inherited
TIME_CHANGE_PHRASES = [
    "what about this", "what about last", "how about this", "how about last",
    "now show", "same but", "same for",
]

# Dimension keywords for quick Python extraction
DIM_PATTERNS = {
    "region":   [r"by\s+region", r"per\s+region", r"by\s+geography",
                 r"across\s+regions?", r"which\s+region",
                 r"top\s+\d+\s+regions?",          # "top 3 regions by revenue"
                 r"best\s+region", r"region\s+breakdown"],
    "product":  [r"by\s+product", r"per\s+product", r"by\s+loan\s+type",
                 r"across\s+products?", r"which\s+product",
                 r"top\s+\d+\s+products?",          # "top 5 products by revenue"
                 r"best\s+product", r"product\s+breakdown"],
    "channel":  [r"by\s+channel", r"per\s+channel", r"across\s+channels?",
                 r"which\s+channel", r"most\s+used\s+channel",
                 r"best\s+channel", r"channel\s+breakdown"],
    "customer": [r"by\s+customer", r"per\s+customer",
                 r"top\s+\d+\s+customers?", r"customer\s+breakdown",
                 r"most\s+valuable\s+customers?", r"best\s+customers?"],
}

TIME_PATTERNS = [
    (r"last\s+quarter",         "last_quarter"),
    (r"this\s+quarter",         "this_quarter"),
    (r"last\s+month",           "last_month"),
    (r"this\s+month",           "this_month"),
    (r"last\s+year",            "last_year"),
    (r"this\s+year",            "this_year"),
    (r"year\s+to\s+date|ytd",  "year_to_date"),
    (r"last\s+30\s+days?",      "last_30_days"),
    (r"last\s+90\s+days?",      "last_90_days"),
    (r"\btoday\b",              "today"),
    (r"this\s+week",            "this_week"),
    (r"last\s+week",            "last_week"),
]


def _detect_dims(lower: str) -> list[str]:
    dims = []
    for dim, patterns in DIM_PATTERNS.items():
        if any(re.search(p, lower) for p in patterns):
            dims.append(dim)
    return dims


def _detect_time(lower: str) -> str | None:
    for pattern, tr in TIME_PATTERNS:
        if re.search(pattern, lower):
            return tr
    return None


def _is_follow_up(lower: str) -> bool:
    return any(phrase in lower for phrase in FOLLOW_UP_PHRASES)


# ── Main parse entry point ─────────────────────────────────────────────────────

def parse(text: str, conversation_context: list[dict] | None = None) -> QueryObject:
    """
    Parse a natural language question.

    Strategy:
    1. Check if it's a follow-up (Python regex — reliable)
    2. If follow-up → inherit metric + time_range from last context
       then extract only what changed (new dim or new time) via Python
    3. If fresh question → send to Ollama LLM
    4. If Ollama unavailable → rule-based fallback
    """
    context = conversation_context or []
    lower   = text.lower().strip()

    # ── STEP 1: Follow-up detection (Python, not LLM) ──────────────────────
    if _is_follow_up(lower) and context:
        return _resolve_follow_up(text, lower, context)

    # ── STEP 2: Try LLM for fresh questions ────────────────────────────────
    try:
        result = _parse_with_llm(text, context)
        if result:
            return result
    except Exception as e:
        logger.warning(f"Ollama unavailable ({e}), using rule-based fallback")

    # ── STEP 3: Rule-based fallback ────────────────────────────────────────
    return _parse_rule_based(text, lower, context)


def _resolve_follow_up(text: str, lower: str, context: list[dict]) -> QueryObject:
    """
    Handle follow-up questions by inheriting context and only
    extracting what changed in the new question using Python patterns.
    This is 100% reliable — no LLM needed for follow-ups.

    Examples:
      "break it down by region"     → inherit metric+time, set group_by=["region"]
      "what about this quarter?"    → inherit metric+group_by, set time=this_quarter
      "now by product"              → inherit metric+time, set group_by=["product"]
      "break it down by product and region" → group_by=["product","region"]
    """
    last = context[-1]

    q = QueryObject(
        raw_text   = text,
        metric     = last.get("metric"),
        time_range = last.get("time_range") or "last_30_days",
        group_by   = list(last.get("group_by") or []),
        filters    = dict(last.get("filters") or {}),
        confidence = 0.99,
    )

    # Extract new dimensions mentioned
    new_dims = _detect_dims(lower)
    if new_dims:
        q.group_by = new_dims   # replace with explicitly mentioned dims

    # Extract new time range if mentioned
    new_time = _detect_time(lower)
    if new_time:
        q.time_range = new_time

    # Extract new top-N filter if mentioned
    top = re.search(r"top\s+(\d+)", lower)
    if top:
        q.filters["limit"] = int(top.group(1))

    # Extract region filter if specifically mentioned
    for name, val in [("north america","North America"),("europe","Europe"),
                       ("apac","APAC"),("latin america","Latin America")]:
        if name in lower and not any(re.search(p, lower) for p in [r"by\s+region",r"across\s+regions?"]):
            q.filters["region"] = val

    logger.info(
        f"Follow-up resolved: metric={q.metric}, time={q.time_range}, "
        f"group_by={q.group_by}, filters={q.filters}"
    )
    return q


# ── LLM prompt ────────────────────────────────────────────────────────────────

def _build_prompt(question: str, context: list[dict]) -> str:
    return f"""You are a banking analytics query parser. Convert the question into JSON only.

AVAILABLE METRICS (use exact names only):
{json.dumps(AVAILABLE_METRICS)}

DIMENSIONS for group_by: {AVAILABLE_DIMS}
TIME RANGES: {TIME_RANGE_VALUES}
FILTERS: region {AVAILABLE_REGIONS}, product {AVAILABLE_PRODUCTS}, channel {AVAILABLE_CHANNELS}, limit (integer)

RULES:
- Return ONLY valid JSON — no explanation, no markdown, no backticks
- group_by is a list e.g. ["region"] or ["region","product"]
- filters is a dict e.g. {{"region": "APAC", "limit": 5}}
- If no time mentioned, use "last_30_days"
- confidence: 0.0-1.0

QUESTION: "{question}"

{{"metric": "...", "time_range": "...", "group_by": [], "filters": {{}}, "confidence": 0.95, "error": null}}"""


def _parse_with_llm(text: str, context: list[dict]) -> QueryObject | None:
    prompt = _build_prompt(text, context)

    response = requests.post(
        OLLAMA_URL,
        json={
            "model":   OLLAMA_MODEL,
            "prompt":  prompt,
            "stream":  False,
            "options": {"temperature": 0.1, "top_p": 0.9, "num_predict": 200},
        },
        timeout=TIMEOUT_SEC
    )
    response.raise_for_status()

    raw = response.json().get("response", "").strip()
    logger.debug(f"LLM raw: {raw}")

    json_match = re.search(r'\{.*\}', raw, re.DOTALL)
    if not json_match:
        logger.warning(f"No JSON in LLM response: {raw[:200]}")
        return None

    data = json.loads(json_match.group())

    q = QueryObject(
        raw_text   = text,
        metric     = data.get("metric") or None,
        time_range = data.get("time_range") or "last_30_days",
        group_by   = data.get("group_by") or [],
        filters    = data.get("filters") or {},
        confidence = float(data.get("confidence", 0.9)),
        error      = data.get("error") or None,
    )

    # Validate / fuzzy-match metric
    if q.metric and q.metric not in AVAILABLE_METRICS:
        match = _fuzzy_match_metric(q.metric)
        if match:
            q.metric = match
        else:
            q.error  = f"Metric '{q.metric}' not recognised. Try: {', '.join(AVAILABLE_METRICS)}"
            q.metric = None

    if not q.metric and not q.error:
        q.error = ("Could not identify a metric. Try: revenue, customers, "
                   "loans, churn rate, delinquency rate, top customers by revenue.")

    return q


def _fuzzy_match_metric(name: str) -> str | None:
    name = name.lower().replace(" ", "_").replace("-", "_")
    for m in AVAILABLE_METRICS:
        if name in m or m in name:
            return m
    aliases = {
        "revenue": "total_revenue", "sales": "total_revenue", "income": "total_revenue",
        "transactions": "transaction_count", "customers": "active_customers",
        "active_users": "active_customers", "churn": "churn_rate",
        "delinquency": "delinquency_rate", "loans": "loan_count",
        "loan_value": "total_loan_value",
    }
    return aliases.get(name)


# ── Rule-based fallback ────────────────────────────────────────────────────────

def _parse_rule_based(text: str, lower: str, context: list[dict]) -> QueryObject:
    q = QueryObject(raw_text=text)

    # ── Channel / region intent without explicit metric keyword ──────────
    CHANNEL_INTENT_PATS = [
        r"best\s+channel", r"which\s+channel", r"most\s+(?:used|popular)\s+channel",
        r"preferred\s+channel", r"popular\s+channel",
    ]
    if any(re.search(p, lower) for p in CHANNEL_INTENT_PATS):
        time_r = _detect_time(lower) or "last_30_days"
        dims   = _detect_dims(lower)
        if "channel" not in dims: dims = ["channel"]
        top = re.search(r"top\s+(\d+)", lower)
        filt = {"limit": int(top.group(1))} if top else {}
        return QueryObject(raw_text=text, metric="transaction_count",
                           time_range=time_r, group_by=dims, filters=filt)

    METRIC_KEYWORDS = [
        ("revenue per customer",    "revenue_per_customer"),
        ("top customers by revenue","revenue_per_customer"),
        ("customers by revenue",    "revenue_per_customer"),
        ("total revenue",           "total_revenue"),
        ("revenue",                 "total_revenue"),
        ("transaction count",       "transaction_count"),
        ("transactions",            "transaction_count"),
        ("average transaction",     "average_transaction"),
        ("active customers",        "active_customers"),
        ("new customers",           "new_customers"),
        ("churn rate",              "churn_rate"),
        ("churn",                   "churn_rate"),
        ("most valuable customers", "revenue_per_customer"),
        ("best customers",          "revenue_per_customer"),
        ("highest spending",        "revenue_per_customer"),
        ("total loan value",        "total_loan_value"),
        ("loan value",              "total_loan_value"),
        ("loan count",              "loan_count"),
        ("loans",                   "loan_count"),
        ("delinquency rate",        "delinquency_rate"),
        ("delinquency",             "delinquency_rate"),
        ("customers",               "active_customers"),
    ]

    for kw, metric in METRIC_KEYWORDS:
        if kw in lower:
            q.metric = metric
            break

    if not q.metric:
        q.error = ("Could not identify a metric. Ollama is offline — "
                   "start Ollama to enable full natural language understanding.")
        return q

    q.time_range = _detect_time(lower) or "last_30_days"
    q.group_by   = _detect_dims(lower)

    if q.metric == "revenue_per_customer" and "customer" not in q.group_by:
        q.group_by.insert(0, "customer")

    for name, val in [("north america","North America"),("europe","Europe"),
                       ("apac","APAC"),("latin america","Latin America")]:
        if name in lower and "by region" not in lower:
            q.filters["region"] = val

    top = re.search(r"top\s+(\d+)", lower)
    if top:
        q.filters["limit"] = int(top.group(1))

    return q


# ── Ollama health check ────────────────────────────────────────────────────────

def check_ollama() -> dict:
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        models = [m["name"] for m in r.json().get("models", [])]
        has_model = any(OLLAMA_MODEL.split(":")[0] in m for m in models)
        return {
            "running": True, "models": models,
            "target_model": OLLAMA_MODEL, "model_available": has_model,
            "status": "ready" if has_model else "model_not_pulled",
        }
    except requests.exceptions.ConnectionError:
        return {"running": False, "status": "ollama_not_running",
                "fix": "Run: ollama serve"}
    except Exception as e:
        return {"running": False, "status": "error", "error": str(e)}


# ── Test ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Simulate the exact conversation that was failing
    ctx = []

    # Turn 1: fresh question
    q1 = parse("show me revenue per customer last quarter", ctx)
    print(f"Turn 1: metric={q1.metric}, time={q1.time_range}, group_by={q1.group_by}")
    ctx.append({"metric": q1.metric, "time_range": q1.time_range,
                "group_by": q1.group_by, "filters": q1.filters})

    # Turn 2: follow-up — THIS WAS FAILING
    q2 = parse("Break it down by region", ctx)
    print(f"Turn 2: metric={q2.metric}, time={q2.time_range}, group_by={q2.group_by}")
    assert q2.metric == "revenue_per_customer", f"FAIL: metric={q2.metric}"
    assert q2.time_range == "last_quarter",     f"FAIL: time={q2.time_range}"
    assert "region" in q2.group_by,             f"FAIL: group_by={q2.group_by}"
    ctx.append({"metric": q2.metric, "time_range": q2.time_range,
                "group_by": q2.group_by, "filters": q2.filters})

    # Turn 3: time change follow-up
    q3 = parse("What about this quarter?", ctx)
    print(f"Turn 3: metric={q3.metric}, time={q3.time_range}, group_by={q3.group_by}")
    assert q3.metric == "revenue_per_customer", f"FAIL: metric={q3.metric}"
    assert q3.time_range == "this_quarter",     f"FAIL: time={q3.time_range}"

    # Turn 4: dimension change
    q4 = parse("Now break it down by product", ctx)
    print(f"Turn 4: metric={q4.metric}, time={q4.time_range}, group_by={q4.group_by}")
    assert "product" in q4.group_by, f"FAIL: group_by={q4.group_by}"

    print("\nAll follow-up tests passed ✅")
