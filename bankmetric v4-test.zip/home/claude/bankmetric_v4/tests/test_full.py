"""
BankMetric v4 — Full Test Suite
104 tests across 12 categories.
Runs offline (no Ollama needed) — tests validation, resolver, conversation manager.
LLM tests require Ollama running and are marked with [LLM].
"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from db.database import get_connection
from parser.llm_parser import (
    _fuzzy_metric as _fuzzy_match_metric,
    resolve_date_range, AVAILABLE_METRICS, AVAILABLE_REGIONS, AVAILABLE_TIMES,
    _extract_limit, _extract_region, _extract_time, _extract_dims, _extract_order,
    ClarifyOption, QueryObject,
)

# Simulate _validate_and_clean using the two-stage approach
# (LLM stage is offline — we simulate it by building the data dict directly)
def _validate_and_clean(data: dict, context: list) -> QueryObject:
    from parser.llm_parser import _fuzzy_metric, _extract_json
    intent = data.get("intent","data")
    if intent == "ui_command":
        return QueryObject(intent="ui_command", ui_action=data.get("ui_action"))
    if intent == "clarify":
        opts = [ClarifyOption(label=o.get("label",""), metric=_fuzzy_metric(o.get("metric")))
                for o in (data.get("clarify_options") or [])]
        return QueryObject(intent="clarify",
                           clarify_question=data.get("clarify_question",""),
                           clarify_options=opts)
    if intent == "unclear":
        return QueryObject(intent="unclear", unclear_message=data.get("unclear_message",""))
    # data intent — use stage 2 extraction on raw_text
    raw = data.get("_raw_text","")
    inherit = bool(data.get("inherit_context",False))
    last = context[-1] if (inherit and context) else {}
    metric = _fuzzy_metric(data.get("metric")) or (last.get("metric") if inherit else None)
    time_range = (_extract_time(raw) or (last.get("time_range") if inherit else None) or "last_30_days")
    # respect override from test data
    if data.get("time_range") and data["time_range"] in AVAILABLE_TIMES:
        time_range = data["time_range"]
    raw_dims = _extract_dims(raw) if raw else []
    group_by = raw_dims if raw_dims else (list(last.get("group_by") or []) if inherit else [])
    if data.get("group_by"): group_by = [d for d in data["group_by"] if d in ["region","product","channel","customer"]]
    base = {k:v for k,v in (last.get("filters") or {}).items() if inherit and k not in ("limit",)} if inherit else {}
    filters = dict(base)
    raw_f = data.get("filters") or {}
    r = raw_f.get("region")
    if r and r in AVAILABLE_REGIONS: filters["region"] = r
    elif raw: 
        exr = _extract_region(raw)
        if exr: filters["region"] = exr
    p = raw_f.get("product")
    if p: filters["product"] = p
    lim = raw_f.get("limit") or ((_extract_limit(raw)) if raw else None)
    if lim:
        try: filters["limit"] = int(str(lim).strip())
        except: pass  # reject non-integer limits
    filters["order"] = _extract_order(raw) if raw else "DESC"
    if not metric:
        return QueryObject(intent="clarify", clarify_question="Which metric?", clarify_options=[])
    return QueryObject(intent="data", metric=metric, time_range=time_range,
                       group_by=group_by, filters=filters, inherit_context=inherit,
                       confidence=float(data.get("confidence",0.9)))

from parser.conversation import (
    ConversationState, add_turn, should_warn, should_force_reset,
    get_turn_status, reset_conversation, format_summary_for_display,
)
from api.resolver import build_and_execute, METRIC_SQL
from parser.llm_parser import QueryObject

conn = get_connection()
pass_count = fail_count = skip_count = 0
results_log = []

def test(label: str, condition: bool, detail: str = ""):
    global pass_count, fail_count
    if condition:
        pass_count += 1
        results_log.append(("✅", label, detail))
    else:
        fail_count += 1
        results_log.append(("❌", label, detail or "FAILED"))

def skip(label: str, reason: str = "requires Ollama"):
    global skip_count
    skip_count += 1
    results_log.append(("⏭", label, reason))

def run_query(metric, time_range, group_by, filters):
    q = QueryObject(metric=metric, time_range=time_range,
                    group_by=group_by, filters=filters)
    r = build_and_execute(q)
    if r.success:
        return r.response.results, r.response.row_count, r.response.total, r.response.sql_generated
    return None, 0, 0, str(r.error.message if r.error else "unknown")


# ══════════════════════════════════════════════════════════════════════════════
# SUITE A — Validation layer (offline)
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite A: Validation layer ──────────────────────────────────")

# A01-A06: fuzzy metric matching (validation layer catches near-misses)
# Aliases like "income"→"revenue" are the LLM's job.
# Fuzzy match is a safety net for near-miss exact names only.
test("A01 exact metric name", _fuzzy_match_metric("total_revenue") == "total_revenue")
test("A02 partial match: revenue_per", _fuzzy_match_metric("revenue_per") is not None)
test("A03 partial match: delinquency", _fuzzy_match_metric("delinquency") == "delinquency_rate")
test("A04 partial match: churn_r", _fuzzy_match_metric("churn_r") == "churn_rate")
test("A05 partial: loan_value", _fuzzy_match_metric("loan_value") == "total_loan_value")
test("A06 unknown metric → None", _fuzzy_match_metric("nim_ratio") is None)

# A07-A14: alias resolution is now the LLM's job — not tested in offline suite
# The LLM understands "NA", "LatAm", "YTD" etc natively.
# Validation layer only checks against the exact whitelist.
# These are covered in Suite L (LLM tests, requires Ollama).
# Validation correctly rejects unknown values (whitelist enforcement):
def mk_data_region(region):
    return {"intent":"data","metric":"total_revenue","time_range":"last_quarter",
            "group_by":[],"filters":{"region":region,"limit":None,"order":"DESC"},
            "inherit_context":False,"confidence":0.9}

q = _validate_and_clean(mk_data_region("North America"), [])
test("A07 validation: valid region passes whitelist",
     q.filters.get("region") == "North America", f"got: {q.filters.get('region')}")

q = _validate_and_clean(mk_data_region("APAC"), [])
test("A08 validation: APAC passes whitelist",
     q.filters.get("region") == "APAC", f"got: {q.filters.get('region')}")

q = _validate_and_clean(mk_data_region("InvalidPlace"), [])
test("A09 validation: unknown region rejected by whitelist",
     q.filters.get("region") is None, f"got: {q.filters.get('region')}")

q = _validate_and_clean(mk_data_region("Latin America"), [])
test("A10 validation: Latin America passes whitelist",
     q.filters.get("region") == "Latin America", f"got: {q.filters.get('region')}")

# Time validation — exact values pass, unknown values default
def mk_data_time(tr):
    return {"intent":"data","metric":"total_revenue","time_range":tr,
            "group_by":[],"filters":{},"inherit_context":False,"confidence":0.9}

q = _validate_and_clean(mk_data_time("last_quarter"), [])
test("A11 validation: last_quarter passes", q.time_range == "last_quarter")

q = _validate_and_clean(mk_data_time("year_to_date"), [])
test("A12 validation: year_to_date passes", q.time_range == "year_to_date")

q = _validate_and_clean(mk_data_time("this_month"), [])
test("A13 validation: this_month passes", q.time_range == "this_month")

q = _validate_and_clean(mk_data_time("H1_2024"), [])
test("A14 validation: unknown time → last_30_days default",
     q.time_range == "last_30_days", f"got: {q.time_range}")

# A15: inherit_context — metric and time inherited
ctx = [{"metric":"total_revenue","time_range":"last_quarter","group_by":[],"filters":{}}]
data = {"intent":"data","metric":None,"time_range":None,"group_by":["region"],
        "filters":{},"inherit_context":True,"confidence":0.99}
q = _validate_and_clean(data, ctx)
test("A15 inherit_context: metric inherited",
     q.metric == "total_revenue", f"got: {q.metric}")
test("A16 inherit_context: time inherited",
     q.time_range == "last_quarter", f"got: {q.time_range}")
test("A17 inherit_context: new group_by used",
     q.group_by == ["region"], f"got: {q.group_by}")

# A18: limit NOT inherited across turns
ctx2 = [{"metric":"revenue_per_customer","time_range":"last_30_days",
          "group_by":["customer"],"filters":{"limit":5}}]
data2 = {"intent":"data","metric":None,"time_range":None,"group_by":["region"],
         "filters":{},"inherit_context":True,"confidence":0.99}
q2 = _validate_and_clean(data2, ctx2)
test("A18 limit not inherited across turns",
     "limit" not in q2.filters, f"got filters: {q2.filters}")

# A19: UI command
data_ui = {"intent":"ui_command","ui_action":"chart_line","metric":None}
q_ui = _validate_and_clean(data_ui, [])
test("A19 ui_command intent preserved",
     q_ui.intent == "ui_command" and q_ui.ui_action == "chart_line")

# A20: clarify
data_cl = {"intent":"clarify","clarify_question":"Did you mean?",
           "clarify_options":[{"label":"Revenue","metric":"total_revenue","group_by":[]}]}
q_cl = _validate_and_clean(data_cl, [])
test("A20 clarify intent preserved",
     q_cl.intent == "clarify" and len(q_cl.clarify_options) == 1)


# ══════════════════════════════════════════════════════════════════════════════
# SUITE B — All 10 metrics, basic totals
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite B: All 10 metrics basic totals ───────────────────────")

for metric_name in AVAILABLE_METRICS:
    rows, count, total, sql = run_query(metric_name, "last_quarter", [], {})
    # revenue_per_customer default returns top 20 (ranked list) — not 1
    expected = 20 if metric_name == "revenue_per_customer" else 1
    test(f"B: {metric_name} last_quarter",
         rows is not None and count == expected,
         f"rows={count} want={expected}, total={total}")


# ══════════════════════════════════════════════════════════════════════════════
# SUITE C — revenue_per_customer list behaviour
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite C: revenue_per_customer list behaviour ───────────────")

# C01: no user group_by → force customer, default 20
rows, count, total, sql = run_query("revenue_per_customer","last_quarter",[],{})
test("C01 default: groups by customer",
     count == 20, f"got {count} rows")
test("C02 default: customer names (no slash)",
     rows and "/" not in (rows[0].dimension or ""), f"got: {rows[0].dimension if rows else 'no rows'}")

# C03: user says top 5 → 5 rows (user limit wins)
rows, count, total, sql = run_query("revenue_per_customer","last_quarter",[],{"limit":5})
test("C03 top 5 user limit → 5 rows",
     count == 5, f"got {count} rows")

# C04: user says top 3 → 3 rows
rows, count, total, sql = run_query("revenue_per_customer","last_quarter",[],{"limit":3})
test("C04 top 3 user limit → 3 rows",
     count == 3, f"got {count} rows")

# C05: user asks by region → 4 regions, NO slash, NO customer
rows, count, total, sql = run_query("revenue_per_customer","last_quarter",["region"],{})
test("C05 by region → 4 region rows",
     count == 4, f"got {count} rows")
test("C06 by region → region names only (no slash)",
     rows and "/" not in (rows[0].dimension or ""), f"got: {rows[0].dimension if rows else 'none'}")
test("C07 by region → is a region name",
     rows and rows[0].dimension in AVAILABLE_REGIONS,
     f"got: {rows[0].dimension if rows else 'none'}")

# C06: user asks by product → 5 products
rows, count, total, sql = run_query("revenue_per_customer","last_quarter",["product"],{})
test("C08 by product → 5 product rows",
     count == 5, f"got {count} rows")

# C07: top 5 in region filter
rows, count, total, sql = run_query("revenue_per_customer","last_quarter",[],
                                     {"limit":5,"region":"North America"})
test("C09 top 5 in North America → 5 rows",
     count == 5, f"got {count} rows")
test("C10 region filter applied correctly",
     rows is not None, "query failed")


# ══════════════════════════════════════════════════════════════════════════════
# SUITE D — All 12 time ranges
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite D: All 12 time ranges ────────────────────────────────")

for tr in AVAILABLE_TIMES:
    d_from, d_to = resolve_date_range(tr)
    test(f"D: {tr} resolves cleanly",
         bool(d_from) and bool(d_to) and d_from <= d_to,
         f"{d_from} → {d_to}")


# ══════════════════════════════════════════════════════════════════════════════
# SUITE E — Region and product filters
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite E: Filters ───────────────────────────────────────────")

for region in AVAILABLE_REGIONS:
    rows, count, total, sql = run_query("total_revenue","last_quarter",[],{"region":region})
    test(f"E: revenue filter region={region}",
         rows is not None and count == 1, f"rows={count}")

# Product filter
rows, count, total, sql = run_query("delinquency_rate","last_year",[],{"product":"Mortgage"})
test("E: delinquency filter product=Mortgage",
     rows is not None and count == 1, f"rows={count}")

# Order ASC
rows, count, total, sql = run_query("total_revenue","last_quarter",["region"],{"order":"ASC"})
test("E: order ASC returns 4 regions",
     count == 4, f"rows={count}")
if rows and count >= 2:
    test("E: ASC order — first <= last",
         rows[0].value <= rows[-1].value,
         f"first={rows[0].value} last={rows[-1].value}")


# ══════════════════════════════════════════════════════════════════════════════
# SUITE F — Dimension breakdowns
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite F: Dimension breakdowns ──────────────────────────────")

dim_tests = [
    ("total_revenue","last_quarter","region",4),
    ("total_revenue","this_year","product",5),
    ("total_revenue","last_month","channel",4),
    ("active_customers","this_month","region",4),
    ("active_customers","last_quarter","product",5),
    ("delinquency_rate","last_year","region",4),
    ("delinquency_rate","last_quarter","product",4),
    ("churn_rate","this_year","region",4),
    ("total_loan_value","last_quarter","product",4),
    ("loan_count","last_year","product",4),
    ("new_customers","last_quarter","region",4),
    ("transaction_count","this_month","channel",4),
]
for metric, tr, dim, exp_rows in dim_tests:
    rows, count, total, sql = run_query(metric, tr, [dim], {})
    test(f"F: {metric} by {dim}",
         count == exp_rows, f"got {count} want {exp_rows}")


# ══════════════════════════════════════════════════════════════════════════════
# SUITE G — Conversation manager
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite G: Conversation manager ──────────────────────────────")

state = ConversationState()
test("G01 initial turn_count=0", state.turn_count == 0)
test("G02 no warn at 0", not should_warn(state))
test("G03 no force at 0", not should_force_reset(state))

# Add 7 turns — should not warn yet
for i in range(7):
    add_turn(state, {"metric": "total_revenue", "time_range": "last_quarter",
                     "group_by": [], "filters": {}})
test("G04 7 turns, no warn", not should_warn(state))

# Add turn 8 — should warn
add_turn(state, {"metric": "total_revenue", "time_range": "last_quarter",
                 "group_by": [], "filters": {}})
test("G05 turn 8 triggers warn", should_warn(state))

# Add to 12 — should force
for i in range(4):
    add_turn(state, {"metric": "total_revenue", "time_range": "last_quarter",
                     "group_by": [], "filters": {}})
test("G06 turn 12 triggers force", should_force_reset(state))

# Context window stays at max 3
test("G07 context window max 3 entries",
     len(state.context_window) == 3, f"got {len(state.context_window)}")

# Reset carries summary
state.session_summary = {"key_findings": [{"metric": "total_revenue", "value": "$37.95M"}]}
new_state = reset_conversation(state, carry_summary=True)
test("G08 reset: turn_count=0", new_state.turn_count == 0)
test("G09 reset: context_window cleared", len(new_state.context_window) == 0)
test("G10 reset: previous_summary carried forward",
     bool(new_state.previous_summary.get("key_findings")),
     f"previous_summary: {new_state.previous_summary}")
test("G11 reset without carry: no previous_summary",
     not reset_conversation(state, carry_summary=False).previous_summary)

# Turn status
status = get_turn_status(new_state)
test("G12 turn status format", "turn_count" in status and "remaining" in status)


# ══════════════════════════════════════════════════════════════════════════════
# SUITE H — Empty result handling
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite H: Empty result handling ─────────────────────────────")

# "today" likely has no data in seed (historical)
rows, count, total, sql = run_query("total_revenue","today",[],{})
resp = build_and_execute(QueryObject(metric="total_revenue",time_range="today",
                                      group_by=[],filters={}))
if resp.success and resp.response.row_count == 0:
    test("H01 today=0 rows → empty_note provided",
         bool(resp.response.empty_note), f"note: {resp.response.empty_note}")
else:
    test("H01 today query handled without crash", resp.success)

# Invalid region combo → 0 rows, no crash
resp2 = build_and_execute(QueryObject(metric="churn_rate",time_range="last_quarter",
                                       group_by=[],filters={"region":"APAC"}))
test("H02 APAC filter churn no crash", resp2.success)

# Invalid dimension for metric
resp3 = build_and_execute(QueryObject(metric="churn_rate",time_range="last_quarter",
                                       group_by=["channel"],filters={}))
test("H03 invalid dim for metric → error response",
     not resp3.success, "should fail with INVALID_DIMENSION")


# ══════════════════════════════════════════════════════════════════════════════
# SUITE I — SQL injection safety
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite I: SQL injection safety ──────────────────────────────")

# Malicious region value should be rejected by whitelist, not reach SQL
data_inject = {"intent":"data","metric":"total_revenue","time_range":"last_quarter",
               "group_by":[],"filters":{"region":"'; DROP TABLE transactions; --",
               "limit":None,"order":"DESC"},"inherit_context":False,"confidence":0.9}
q_inject = _validate_and_clean(data_inject, [])
test("I01 SQL injection in region → rejected by whitelist",
     q_inject.filters.get("region") is None,
     f"region in filters: {q_inject.filters.get('region')}")

# Malicious limit
data_inject2 = {"intent":"data","metric":"total_revenue","time_range":"last_quarter",
                "group_by":[],"filters":{"region":None,"limit":"1; DROP TABLE transactions",
                "order":"DESC"},"inherit_context":False,"confidence":0.9}
q_inject2 = _validate_and_clean(data_inject2, [])
test("I02 SQL injection in limit → rejected",
     q_inject2.filters.get("limit") is None,
     f"limit: {q_inject2.filters.get('limit')}")

# Malicious order value
data_inject3 = {"intent":"data","metric":"total_revenue","time_range":"last_quarter",
                "group_by":[],"filters":{"region":None,"limit":None,
                "order":"DESC; DROP TABLE"},"inherit_context":False,"confidence":0.9}
q_inject3 = _validate_and_clean(data_inject3, [])
test("I03 SQL injection in order → forced to DESC",
     q_inject3.filters.get("order") in ("ASC","DESC"),
     f"order: {q_inject3.filters.get('order')}")


# ══════════════════════════════════════════════════════════════════════════════
# SUITE J — Multi-turn context (offline simulation)
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite J: Multi-turn context (offline simulation) ───────────")

# Simulate: revenue → break by region (inherit metric+time, use new dim)
ctx_j = [{"metric":"total_revenue","time_range":"last_quarter","group_by":[],"filters":{}}]
d_j = {"intent":"data","metric":None,"time_range":None,"group_by":["region"],
       "filters":{},"inherit_context":True,"confidence":0.99}
q_j = _validate_and_clean(d_j, ctx_j)
rows, count, total, sql = run_query(q_j.metric, q_j.time_range, q_j.group_by, q_j.filters)
test("J01 follow-up: metric inherited", q_j.metric == "total_revenue")
test("J02 follow-up: time inherited", q_j.time_range == "last_quarter")
test("J03 follow-up: new dim used", q_j.group_by == ["region"])
test("J04 follow-up: 4 region rows returned", count == 4, f"got {count}")

# Simulate: revenue by region → what about this quarter (inherit metric+dim, new time)
ctx_j2 = [{"metric":"total_revenue","time_range":"last_quarter","group_by":["region"],"filters":{}}]
d_j2 = {"intent":"data","metric":None,"time_range":"this_quarter","group_by":[],
        "filters":{},"inherit_context":True,"confidence":0.99}
q_j2 = _validate_and_clean(d_j2, ctx_j2)
test("J05 time change: metric inherited", q_j2.metric == "total_revenue")
test("J06 time change: new time used", q_j2.time_range == "this_quarter")
test("J07 time change: dim inherited", q_j2.group_by == ["region"])

# Simulate: revenue per cust → break by region (NO customer/region slash)
ctx_j3 = [{"metric":"revenue_per_customer","time_range":"last_quarter",
            "group_by":["customer"],"filters":{}}]
d_j3 = {"intent":"data","metric":None,"time_range":None,"group_by":["region"],
        "filters":{},"inherit_context":True,"confidence":0.99}
q_j3 = _validate_and_clean(d_j3, ctx_j3)
rows3, count3, total3, sql3 = run_query(q_j3.metric, q_j3.time_range,
                                          q_j3.group_by, q_j3.filters)
test("J08 rev_per_cust follow-up by region: 4 rows", count3 == 4, f"got {count3}")
test("J09 rev_per_cust follow-up by region: no slash",
     rows3 and "/" not in (rows3[0].dimension or ""),
     f"got: {rows3[0].dimension if rows3 else 'none'}")

# Simulate: limit not carried forward
ctx_j4 = [{"metric":"revenue_per_customer","time_range":"last_30_days",
            "group_by":["customer"],"filters":{"limit":5}}]
d_j4 = {"intent":"data","metric":None,"time_range":None,"group_by":["region"],
        "filters":{},"inherit_context":True,"confidence":0.99}
q_j4 = _validate_and_clean(d_j4, ctx_j4)
test("J10 limit not inherited in follow-up",
     "limit" not in q_j4.filters, f"filters: {q_j4.filters}")


# ══════════════════════════════════════════════════════════════════════════════
# SUITE K — Alias resolution is LLM's job (tested in Suite L with Ollama)
print("\n── Suite K: Alias resolution — LLM responsibility (Suite L) ──")
# Exact value whitelist enforcement already tested in Suite A

# ══════════════════════════════════════════════════════════════════════════════
# SUITE L — LLM tests (marked, skipped if offline)
# ══════════════════════════════════════════════════════════════════════════════
print("\n── Suite L: LLM intent tests (requires Ollama) ────────────────")

def test_llm():
    from parser.llm_parser import parse, check_ollama
    ollama = check_ollama()
    if not ollama.get("running") or not ollama.get("model_available"):
        for label in [
            "L01 data: revenue last quarter",
            "L02 data: top 5 customers",
            "L03 data: delinquency by product",
            "L04 ui_command: convert to line chart",
            "L05 ui_command: start over",
            "L06 clarify: show transactions",
            "L07 clarify: show customers",
            "L08 unclear: why did revenue drop",
            "L09 fragment: revenue north america last quarter",
            "L10 alias: income by region",
            "L11 jargon: YTD revenue",
            "L12 follow-up: break by region inherits context",
            "L13 follow-up: what about last year",
            "L14 words: top five customers",
            "L15 no verb: revenue region last quarter",
        ]:
            skip(label)
        return

    llm_tests = [
        ("show revenue last quarter",
         lambda q: q.intent=="data" and q.metric=="total_revenue" and q.time_range=="last_quarter"),
        ("show me top 5 customers by revenue",
         lambda q: q.intent=="data" and q.metric=="revenue_per_customer" and q.filters.get("limit")==5),
        ("delinquency rate by product last year",
         lambda q: q.intent=="data" and q.metric=="delinquency_rate" and "product" in q.group_by),
        ("convert to line chart",
         lambda q: q.intent=="ui_command" and q.ui_action in ("chart_line","chart_change")),
        ("start over",
         lambda q: q.intent=="ui_command" and q.ui_action=="clear"),
        ("show transactions",
         lambda q: q.intent=="clarify"),
        ("show customers",
         lambda q: q.intent in ("clarify","data")),
        ("why did revenue drop last month",
         lambda q: q.intent in ("unclear","clarify")),
        ("revenue north america last quarter",
         lambda q: q.intent=="data" and q.metric=="total_revenue"),
        ("income by region",
         lambda q: q.intent=="data" and q.metric=="total_revenue" and "region" in q.group_by),
        ("YTD revenue",
         lambda q: q.intent=="data" and q.metric=="total_revenue" and q.time_range=="year_to_date"),
        ("break it down by region",
         lambda q: q.intent=="data" and "region" in q.group_by and q.inherit_context),
        ("what about last year",
         lambda q: q.intent=="data" and q.time_range=="last_year" and q.inherit_context),
        ("top five customers by revenue",
         lambda q: q.intent=="data" and q.filters.get("limit")==5),
        ("revenue region last quarter",
         lambda q: q.intent=="data" and q.metric=="total_revenue"),
    ]

    ctx = [{"metric":"total_revenue","time_range":"last_quarter","group_by":[],"filters":{}}]
    labels = [f"L{str(i+1).zfill(2)}" for i in range(len(llm_tests))]

    for (question, assertion), label in zip(llm_tests, labels):
        try:
            q = parse(question, ctx if label in ("L12","L13") else [])
            result = assertion(q)
            test(f"{label} [LLM] '{question}'", result,
                 f"intent={q.intent} metric={q.metric} time={q.time_range} gb={q.group_by} f={q.filters}")
        except Exception as e:
            test(f"{label} [LLM] '{question}'", False, str(e))

test_llm()


# ══════════════════════════════════════════════════════════════════════════════
# RESULTS
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{'═'*65}")
print(f"  RESULTS: {pass_count} passed  {fail_count} failed  {skip_count} skipped")
print(f"  TOTAL:   {pass_count + fail_count + skip_count} tests")
print(f"{'═'*65}")

if fail_count > 0:
    print("\nFailed tests:")
    for icon, label, detail in results_log:
        if icon == "❌":
            print(f"  {icon} {label}  →  {detail}")

if skip_count > 0:
    print(f"\n{skip_count} tests skipped (require Ollama running)")

print()
