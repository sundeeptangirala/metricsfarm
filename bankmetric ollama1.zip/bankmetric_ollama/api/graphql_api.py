"""
BankMetric — GraphQL API (Strawberry + FastAPI)  v3

Key fixes vs v2:
  - User-specified limit ALWAYS beats metric default_limit
  - force_group_by applied AFTER user group_by, not before
  - Cleaner SQL building — no inline JOIN hacks in dim map
"""
import strawberry
from strawberry.fastapi import GraphQLRouter
from typing import Optional
import sqlite3

from db.database import get_connection
from parser.llm_parser import QueryObject, resolve_date_range


# ── GraphQL types ──────────────────────────────────────────────────────────────

@strawberry.type
class MetricResult:
    dimension: Optional[str]
    value: float
    formatted_value: str

@strawberry.type
class MetricResponse:
    metric_name: str
    display_name: str
    time_range: str
    date_from: str
    date_to: str
    group_by: list[str]
    results: list[MetricResult]
    total: float
    formatted_total: str
    row_count: int
    sql_generated: str

@strawberry.type
class MetricDefinition:
    metric_name: str
    display_name: str
    description: str
    formula: str
    source_table: str
    allowed_dims: str
    owner: str
    status: str

@strawberry.type
class ValidationError:
    code: str
    message: str
    suggestion: str

@strawberry.type
class QueryResponse:
    success: bool
    response: Optional[MetricResponse]
    error: Optional[ValidationError]


# ── Metric definitions ─────────────────────────────────────────────────────────
#
# force_group_by: dims injected when user doesn't specify any (metric is
#                 meaningless without them — e.g. revenue_per_customer)
# default_limit:  rows returned when user specifies no limit AND force_group_by
#                 is active. USER-specified limit ALWAYS overrides this.
#
# dims map: dim_name → SQL column expression
# If a dim requires a JOIN, the join is declared in "joins" key.

METRIC_SQL = {
    "total_revenue": {
        "select":        "ROUND(SUM(t.amount), 2)",
        "table":         "transactions t",
        "joins":         {"customer": "JOIN customers c ON c.id = t.customer_id"},
        "date_col":      "t.transaction_date",
        "where":         "t.status = 'completed'",
        "display_name":  "Total Revenue",
        "format":        "currency",
        "dims":          {"region":"t.region","product":"t.product",
                          "channel":"t.channel","customer":"c.name"},
        "force_group_by": [],
        "default_limit":  None,
    },
    "transaction_count": {
        "select":        "COUNT(*)",
        "table":         "transactions t",
        "joins":         {"customer": "JOIN customers c ON c.id = t.customer_id"},
        "date_col":      "t.transaction_date",
        "where":         "t.status = 'completed'",
        "display_name":  "Transaction Count",
        "format":        "integer",
        "dims":          {"region":"t.region","product":"t.product",
                          "channel":"t.channel","customer":"c.name"},
        "force_group_by": [],
        "default_limit":  None,
    },
    "average_transaction": {
        "select":        "ROUND(AVG(t.amount), 2)",
        "table":         "transactions t",
        "joins":         {},
        "date_col":      "t.transaction_date",
        "where":         "t.status = 'completed'",
        "display_name":  "Avg Transaction Value",
        "format":        "currency",
        "dims":          {"region":"t.region","product":"t.product","channel":"t.channel"},
        "force_group_by": [],
        "default_limit":  None,
    },
    "revenue_per_customer": {
        "select":        "ROUND(SUM(t.amount), 2)",
        "table":         "transactions t",
        "joins":         {"_base": "JOIN customers c ON c.id = t.customer_id"},
        "date_col":      "t.transaction_date",
        "where":         "t.status = 'completed'",
        "display_name":  "Revenue per Customer",
        "format":        "currency",
        "dims":          {"customer":"c.name","region":"c.region",
                          "product":"t.product","channel":"t.channel"},
        # Always group by customer — this metric is a ranked list, not a total
        "force_group_by": ["customer"],
        # Default to top 20 — sensible list without overwhelming
        # NOTE: user-specified limit (e.g. "top 5") OVERRIDES this
        "default_limit":  20,
    },
    "active_customers": {
        "select":        "COUNT(*)",
        "table":         "customers c",
        "joins":         {},
        "date_col":      "c.joined_date",
        "where":         "c.status = 'active'",
        "display_name":  "Active Customers",
        "format":        "integer",
        "dims":          {"region":"c.region","product":"c.product","channel":"c.channel"},
        "force_group_by": [],
        "default_limit":  None,
    },
    "new_customers": {
        "select":        "COUNT(*)",
        "table":         "customers c",
        "joins":         {},
        "date_col":      "c.joined_date",
        "where":         "1=1",
        "display_name":  "New Customers",
        "format":        "integer",
        "dims":          {"region":"c.region","product":"c.product","channel":"c.channel"},
        "force_group_by": [],
        "default_limit":  None,
    },
    "churn_rate": {
        "select":        "ROUND(CAST(SUM(CASE WHEN c.status='churned' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100, 2)",
        "table":         "customers c",
        "joins":         {},
        "date_col":      "c.joined_date",
        "where":         "1=1",
        "display_name":  "Churn Rate (%)",
        "format":        "percent",
        "dims":          {"region":"c.region","product":"c.product"},
        "force_group_by": [],
        "default_limit":  None,
    },
    "total_loan_value": {
        "select":        "ROUND(SUM(l.amount), 2)",
        "table":         "loans l",
        "joins":         {},
        "date_col":      "l.origination_date",
        "where":         "1=1",
        "display_name":  "Total Loan Value",
        "format":        "currency",
        "dims":          {"region":"l.region","product":"l.product"},
        "force_group_by": [],
        "default_limit":  None,
    },
    "loan_count": {
        "select":        "COUNT(*)",
        "table":         "loans l",
        "joins":         {},
        "date_col":      "l.origination_date",
        "where":         "1=1",
        "display_name":  "Loan Count",
        "format":        "integer",
        "dims":          {"region":"l.region","product":"l.product"},
        "force_group_by": [],
        "default_limit":  None,
    },
    "delinquency_rate": {
        "select":        "ROUND(CAST(SUM(CASE WHEN l.status='delinquent' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100, 2)",
        "table":         "loans l",
        "joins":         {},
        "date_col":      "l.origination_date",
        "where":         "1=1",
        "display_name":  "Delinquency Rate (%)",
        "format":        "percent",
        "dims":          {"region":"l.region","product":"l.product"},
        "force_group_by": [],
        "default_limit":  None,
    },
}


def _format_value(v: float, fmt: str) -> str:
    if fmt == "currency":
        if v >= 1_000_000: return f"${v/1_000_000:.2f}M"
        if v >= 1_000:     return f"${v/1_000:.1f}K"
        return f"${v:,.2f}"
    if fmt == "percent": return f"{v:.2f}%"
    return f"{v:,.0f}"


# ── Core resolver ──────────────────────────────────────────────────────────────

def build_and_execute(query_obj: QueryObject) -> QueryResponse:
    conn = get_connection()

    if query_obj.metric not in METRIC_SQL:
        return QueryResponse(success=False, response=None,
            error=ValidationError(code="UNKNOWN_METRIC",
                message=f"Metric '{query_obj.metric}' is not defined.",
                suggestion=f"Available: {', '.join(METRIC_SQL.keys())}"))

    spec    = METRIC_SQL[query_obj.metric]
    allowed = spec["dims"]
    fmt     = spec["format"]

    # ── Resolve group_by ────────────────────────────────────────────────
    # Start with what user asked for, then ensure force_group_by dims are present
    effective_group_by = list(query_obj.group_by)
    for fd in spec["force_group_by"]:
        if fd not in effective_group_by:
            effective_group_by.insert(0, fd)

    # ── Resolve limit ───────────────────────────────────────────────────
    # User-specified limit ALWAYS wins over default_limit
    user_limit = query_obj.filters.get("limit")
    if user_limit is not None:
        effective_limit = int(user_limit)
    elif spec["default_limit"] and effective_group_by:
        effective_limit = spec["default_limit"]
    else:
        effective_limit = None

    # ── Validate dims ───────────────────────────────────────────────────
    invalid = [d for d in effective_group_by if d not in allowed]
    if invalid:
        return QueryResponse(success=False, response=None,
            error=ValidationError(code="INVALID_DIMENSION",
                message=f"Dimension(s) {invalid} not available for '{query_obj.metric}'.",
                suggestion=f"Allowed: {list(allowed.keys())}"))

    # ── Date range ──────────────────────────────────────────────────────
    date_from, date_to = resolve_date_range(
        query_obj.time_range or "last_30_days", query_obj.raw_text)

    # ── Build JOIN clause ───────────────────────────────────────────────
    # Include base join (always) + any dim-triggered joins
    join_clauses = set()
    if "_base" in spec["joins"]:
        join_clauses.add(spec["joins"]["_base"])
    for d in effective_group_by:
        if d in spec.get("joins", {}):
            join_clauses.add(spec["joins"][d])
    # Also include joins needed for filter dims
    for col in query_obj.filters:
        if col in spec.get("joins", {}):
            join_clauses.add(spec["joins"][col])
    join_str = " ".join(join_clauses)

    # ── Build WHERE ─────────────────────────────────────────────────────
    conditions = [
        spec["where"],
        f"{spec['date_col']} BETWEEN '{date_from}' AND '{date_to}'",
    ]
    params: list = []

    for col, val in query_obj.filters.items():
        if col in ("limit", "order"): continue
        if col in allowed:
            conditions.append(f"{allowed[col]} = ?")
            params.append(val)

    where_clause = " AND ".join(f"({c})" for c in conditions)

    # ── Build SELECT / GROUP BY ─────────────────────────────────────────
    order_dir   = query_obj.filters.get("order", "DESC")
    group_exprs = [allowed[d] for d in effective_group_by if d in allowed]

    if group_exprs:
        dim_label = group_exprs[0] if len(group_exprs) == 1 \
                    else " || ' / ' || ".join(group_exprs)
        sql = (f"SELECT {dim_label} AS dimension, {spec['select']} AS value "
               f"FROM {spec['table']} {join_str} "
               f"WHERE {where_clause} "
               f"GROUP BY {', '.join(group_exprs)} "
               f"ORDER BY value {order_dir}")
        if effective_limit:
            sql += f" LIMIT {effective_limit}"
    else:
        sql = (f"SELECT NULL AS dimension, {spec['select']} AS value "
               f"FROM {spec['table']} {join_str} "
               f"WHERE {where_clause}")

    # ── Execute ─────────────────────────────────────────────────────────
    try:
        rows = conn.execute(sql, params).fetchall()
    except sqlite3.Error as e:
        return QueryResponse(success=False, response=None,
            error=ValidationError(code="SQL_ERROR", message=str(e),
                                  suggestion="Check metric definition."))

    results = [MetricResult(dimension=r["dimension"], value=r["value"] or 0.0,
                            formatted_value=_format_value(r["value"] or 0.0, fmt))
               for r in rows]

    total = sum(r.value for r in results)
    if fmt == "percent" and results:
        total = total / len(results)

    TIME_LABELS = {
        "last_month":"Last Month","this_month":"This Month",
        "last_quarter":"Last Quarter","this_quarter":"This Quarter",
        "last_year":"Last Year","this_year":"This Year",
        "year_to_date":"Year to Date","last_30_days":"Last 30 Days",
        "last_90_days":"Last 90 Days","today":"Today",
        "this_week":"This Week","last_week":"Last Week",
    }
    time_label = TIME_LABELS.get(query_obj.time_range or "", query_obj.time_range or "")

    return QueryResponse(success=True, error=None,
        response=MetricResponse(
            metric_name=query_obj.metric,
            display_name=spec["display_name"],
            time_range=time_label,
            date_from=date_from, date_to=date_to,
            group_by=effective_group_by,
            results=results, total=total,
            formatted_total=_format_value(total, fmt),
            row_count=len(results),
            sql_generated=sql,
        ))


# ── GraphQL schema ─────────────────────────────────────────────────────────────

@strawberry.type
class Query:
    @strawberry.field
    def metric(self, name: str, time_range: str = "last_30_days",
               group_by: list[str] = strawberry.UNSET,
               filters: Optional[strawberry.scalars.JSON] = None) -> QueryResponse:
        return build_and_execute(QueryObject(
            metric=name, time_range=time_range,
            group_by=group_by if group_by is not strawberry.UNSET else [],
            filters=filters or {},
        ))

    @strawberry.field
    def list_metrics(self) -> list[MetricDefinition]:
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM metric_registry WHERE status='published' ORDER BY metric_name"
        ).fetchall()
        return [MetricDefinition(
            metric_name=r["metric_name"], display_name=r["display_name"],
            description=r["description"] or "", formula=r["formula"],
            source_table=r["source_table"], allowed_dims=r["allowed_dims"],
            owner=r["owner"] or "", status=r["status"],
        ) for r in rows]


schema = strawberry.Schema(query=Query)
graphql_router = GraphQLRouter(schema)
