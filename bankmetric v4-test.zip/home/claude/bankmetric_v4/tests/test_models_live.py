"""
BankMetric — Live Model Test Runner

Runs 15 test questions through the full pipeline for every model you have pulled.
No UI needed. Captures:
  - Stage 1 LLM intent + metric
  - Stage 2 Python extracted values (limit, time, region, dims)
  - Stage 3 validation result
  - Stage 4 SQL self-check
  - Final SQL generated
  - Whether result matches expected

Usage:
    python tests/test_models_live.py

Output:
    - Console summary
    - tests/results/model_comparison_YYYY-MM-DD.txt  (full report)
    - tests/results/model_comparison_YYYY-MM-DD.json (machine-readable)
"""

import sys, os, json, time, re, requests
from datetime import datetime
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from db.database import get_connection
from parser.llm_parser import (
    _build_prompt, _extract_json, _extract_limit, _extract_time,
    _extract_dims, _extract_region, _fuzzy_metric, _validate_with_llm,
    _sql_self_check, _generate_sql_preview, resolve_date_range,
    QueryObject, ClarifyOption, AVAILABLE_METRICS, AVAILABLE_TIMES,
)
from api.resolver import build_and_execute

# ── Ensure output directory exists ────────────────────────────────────────────
os.makedirs(os.path.join(os.path.dirname(__file__), "results"), exist_ok=True)

# ── Test cases ─────────────────────────────────────────────────────────────────
# Each test has: question, context (for follow-ups), and expected values
TEST_CASES = [
    {
        "id": "T01",
        "question": "show me revenue by region last quarter",
        "context": [],
        "expected": {
            "intent":     "data",
            "metric":     "total_revenue",
            "time_range": "last_quarter",
            "group_by":   ["region"],
            "limit":      None,
        },
        "description": "Unambiguous data query — baseline",
    },
    {
        "id": "T02",
        "question": "show me top 5 customers by revenue",
        "context": [],
        "expected": {
            "intent":     "data",
            "metric":     "revenue_per_customer",
            "group_by":   ["customer"],
            "limit":      5,
        },
        "description": "Top N with metric — limit must be 5",
    },
    {
        "id": "T03",
        "question": "show transactions",
        "context": [],
        "expected": {
            "intent": "clarify",
        },
        "description": "Ambiguous — must ask clarifying question, not guess",
    },
    {
        "id": "T04",
        "question": "show me loans",
        "context": [],
        "expected": {
            "intent": "clarify",
        },
        "description": "Ambiguous — count or value?",
    },
    {
        "id": "T05",
        "question": "break it down by region",
        "context": [{"metric": "total_revenue", "time_range": "last_quarter",
                     "group_by": [], "filters": {}}],
        "expected": {
            "intent":          "data",
            "metric":          "total_revenue",
            "time_range":      "last_quarter",
            "group_by":        ["region"],
            "inherit_context": True,
        },
        "description": "Follow-up — must inherit metric and time",
    },
    {
        "id": "T06",
        "question": "what about last year?",
        "context": [{"metric": "total_revenue", "time_range": "last_quarter",
                     "group_by": ["region"], "filters": {}}],
        "expected": {
            "intent":          "data",
            "metric":          "total_revenue",
            "time_range":      "last_year",
            "group_by":        ["region"],
            "inherit_context": True,
        },
        "description": "Follow-up time change — inherit metric and dims",
    },
    {
        "id": "T07",
        "question": "convert to line chart",
        "context": [],
        "expected": {
            "intent":    "ui_command",
            "ui_action": "chart_line",
        },
        "description": "UI command — must not hit data pipeline",
    },
    {
        "id": "T08",
        "question": "which channel is most used?",
        "context": [],
        "expected": {
            "intent":   "data",
            "metric":   "transaction_count",
            "group_by": ["channel"],
        },
        "description": "Channel frequency intent — transaction_count not revenue",
    },
    {
        "id": "T09",
        "question": "show revenue in North America last quarter",
        "context": [],
        "expected": {
            "intent":     "data",
            "metric":     "total_revenue",
            "time_range": "last_quarter",
            "region":     "North America",
        },
        "description": "Region filter — must appear in filters not group_by",
    },
    {
        "id": "T10",
        "question": "why did revenue drop last month?",
        "context": [],
        "expected": {
            "intent": "unclear",
        },
        "description": "Out of scope — must not return data query",
    },
    {
        "id": "T11",
        "question": "top 3 regions by revenue this year",
        "context": [],
        "expected": {
            "intent":     "data",
            "metric":     "total_revenue",
            "time_range": "this_year",
            "group_by":   ["region"],
            "limit":      3,
        },
        "description": "Top N dimensions — limit=3 and group_by=region",
    },
    {
        "id": "T12",
        "question": "show me revenue per customer last quarter",
        "context": [],
        "expected": {
            "intent":     "data",
            "metric":     "revenue_per_customer",
            "time_range": "last_quarter",
            "group_by":   ["customer"],
            "limit":      None,
        },
        "description": "revenue_per_customer — returns ranked list, no slash",
    },
    {
        "id": "T13",
        "question": "delinquency rate by product last year",
        "context": [],
        "expected": {
            "intent":     "data",
            "metric":     "delinquency_rate",
            "time_range": "last_year",
            "group_by":   ["product"],
        },
        "description": "Loan metric with dimension",
    },
    {
        "id": "T14",
        "question": "YTD income by region",
        "context": [],
        "expected": {
            "intent":     "data",
            "metric":     "total_revenue",
            "time_range": "year_to_date",
            "group_by":   ["region"],
        },
        "description": "Alias: YTD=year_to_date, income=total_revenue",
    },
    {
        "id": "T15",
        "question": "start over",
        "context": [],
        "expected": {
            "intent":    "ui_command",
            "ui_action": "clear",
        },
        "description": "Reset command — must be ui_command not data",
    },
]


# ── Get available models ───────────────────────────────────────────────────────

def get_available_models() -> list[str]:
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        return [m["name"] for m in r.json().get("models", [])]
    except:
        return []


def call_llm(prompt: str, model: str, timeout: int = 30) -> dict | None:
    try:
        resp = requests.post(
            "http://localhost:11434/api/generate",
            json={"model": model, "prompt": prompt, "stream": False,
                  "options": {"temperature": 0.0, "num_predict": 300}},
            timeout=timeout,
        )
        resp.raise_for_status()
        raw = resp.json().get("response", "").strip()
        return _extract_json(raw)
    except Exception as e:
        return None


# ── Run one test case through full pipeline ────────────────────────────────────

def run_test(test: dict, model: str) -> dict:
    question  = test["question"]
    context   = test["context"]
    expected  = test["expected"]

    result = {
        "id":       test["id"],
        "question": question,
        "model":    model,
        "expected": expected,
        "description": test["description"],
    }

    t_start = time.time()

    # ── Stage 1: LLM ──────────────────────────────────────────────────────────
    prompt      = _build_prompt(question, context, None)
    stage1_data = call_llm(prompt, model)
    stage1_time = round(time.time() - t_start, 2)

    if stage1_data is None:
        result.update({
            "stage1_intent":  "ERROR",
            "stage1_metric":  None,
            "stage1_inherit": None,
            "stage1_raw":     "Failed to parse JSON from LLM",
            "stage1_time":    stage1_time,
            "final_intent":   "ERROR",
            "pass":           False,
            "fail_reason":    "Stage 1 returned no valid JSON",
        })
        return result

    stage1_intent  = stage1_data.get("intent", "unknown")
    stage1_metric  = stage1_data.get("metric")
    stage1_inherit = stage1_data.get("inherit_context", False)

    result["stage1_intent"]  = stage1_intent
    result["stage1_metric"]  = stage1_metric
    result["stage1_inherit"] = stage1_inherit
    result["stage1_time"]    = stage1_time

    # ── Stage 2: Python extraction ────────────────────────────────────────────
    t2 = time.time()
    s2_limit  = _extract_limit(question)
    s2_time   = _extract_time(question)
    s2_dims   = _extract_dims(question)
    s2_region = _extract_region(question)
    stage2_time = round(time.time() - t2, 4)

    result["stage2_limit"]  = s2_limit
    result["stage2_time_r"] = s2_time
    result["stage2_dims"]   = s2_dims
    result["stage2_region"] = s2_region
    result["stage2_time"]   = stage2_time

    # ── Build QueryObject (combined Stage 1 + 2) ──────────────────────────────
    if stage1_intent == "ui_command":
        query = QueryObject(
            intent    = "ui_command",
            ui_action = stage1_data.get("ui_action"),
            raw_text  = question,
            parser    = f"llm:{model}",
        )
    elif stage1_intent == "clarify":
        opts = []
        for o in (stage1_data.get("clarify_options") or []):
            opts.append(ClarifyOption(
                label      = o.get("label", ""),
                metric     = _fuzzy_metric(o.get("metric")),
                time_range = s2_time or "last_30_days",
                group_by   = s2_dims,
                filters    = {},
            ))
        query = QueryObject(
            intent           = "clarify",
            clarify_question = stage1_data.get("clarify_question", ""),
            clarify_options  = opts,
            raw_text         = question,
            parser           = f"llm:{model}",
        )
    elif stage1_intent == "unclear":
        query = QueryObject(
            intent          = "unclear",
            unclear_message = stage1_data.get("unclear_message", ""),
            raw_text        = question,
            parser          = f"llm:{model}",
        )
    else:
        # data intent — merge Stage 1 + 2
        inherit = stage1_inherit
        last    = context[-1] if (inherit and context) else {}

        metric = _fuzzy_metric(stage1_metric) or (
                 last.get("metric") if inherit else None)

        time_range = (s2_time
                      or (last.get("time_range") if inherit else None)
                      or "last_30_days")

        group_by = (s2_dims if s2_dims
                    else list(last.get("group_by") or []) if inherit
                    else [])

        base    = {k:v for k,v in (last.get("filters") or {}).items()
                   if inherit and k not in ("limit",)} if inherit else {}
        filters = dict(base)
        if s2_region:             filters["region"] = s2_region
        if s2_limit:              filters["limit"]  = s2_limit
        filters["order"] = "DESC"

        query = QueryObject(
            intent          = "data",
            metric          = metric,
            time_range      = time_range,
            group_by        = group_by,
            filters         = filters,
            inherit_context = inherit,
            confidence      = float(stage1_data.get("confidence", 0.9)),
            raw_text        = question,
            parser          = f"llm:{model}",
        )

    # ── Stage 3: LLM validation ───────────────────────────────────────────────
    t3 = time.time()
    if query.intent == "data":
        validated = _validate_with_llm(question, query, model)
    else:
        validated = query
    stage3_time = round(time.time() - t3, 2)
    result["stage3_changed"] = (validated.intent != query.intent)
    result["stage3_time"]    = stage3_time

    # ── Stage 4: SQL self-check ───────────────────────────────────────────────
    t4 = time.time()
    if validated.intent == "data":
        sql     = _generate_sql_preview(validated)
        final_q = _sql_self_check(question, validated, model)
    else:
        sql     = None
        final_q = validated
    stage4_time = round(time.time() - t4, 2)
    result["sql"]         = sql
    result["stage4_time"] = stage4_time

    # ── Execute SQL if data intent ────────────────────────────────────────────
    rows      = 0
    exec_err  = None
    if final_q.intent == "data" and final_q.metric:
        exec_result = build_and_execute(final_q)
        if exec_result.success:
            rows = exec_result.response.row_count
        else:
            exec_err = exec_result.error.message if exec_result.error else "unknown"
    result["rows_returned"] = rows
    result["exec_error"]    = exec_err

    # ── Final result ──────────────────────────────────────────────────────────
    result["final_intent"]  = final_q.intent
    result["final_metric"]  = final_q.metric
    result["final_time_r"]  = final_q.time_range
    result["final_group_by"]= final_q.group_by
    result["final_limit"]   = final_q.filters.get("limit")
    result["final_region"]  = final_q.filters.get("region")
    result["total_time"]    = round(time.time() - t_start, 2)

    # ── Check against expected ────────────────────────────────────────────────
    fails = []

    if final_q.intent != expected.get("intent"):
        fails.append(f"intent: got={final_q.intent} want={expected['intent']}")

    if expected.get("intent") == "data":
        if expected.get("metric") and final_q.metric != expected["metric"]:
            fails.append(f"metric: got={final_q.metric} want={expected['metric']}")

        if expected.get("time_range") and final_q.time_range != expected["time_range"]:
            fails.append(f"time: got={final_q.time_range} want={expected['time_range']}")

        if expected.get("group_by") is not None:
            exp_gb = set(expected["group_by"])
            got_gb = set(final_q.group_by)
            if exp_gb != got_gb:
                fails.append(f"group_by: got={list(got_gb)} want={list(exp_gb)}")

        if "limit" in expected:
            got_lim = final_q.filters.get("limit")
            if got_lim != expected["limit"]:
                fails.append(f"limit: got={got_lim} want={expected['limit']}")

        if expected.get("region"):
            got_reg = final_q.filters.get("region")
            if got_reg != expected["region"]:
                fails.append(f"region: got={got_reg} want={expected['region']}")

        if expected.get("inherit_context") is not None:
            if final_q.inherit_context != expected["inherit_context"]:
                fails.append(f"inherit_context: got={final_q.inherit_context} want={expected['inherit_context']}")

    if expected.get("intent") == "ui_command":
        if expected.get("ui_action") and final_q.ui_action != expected["ui_action"]:
            fails.append(f"ui_action: got={final_q.ui_action} want={expected['ui_action']}")

    result["pass"]        = len(fails) == 0
    result["fail_reason"] = " | ".join(fails) if fails else None
    return result


# ── Print results ──────────────────────────────────────────────────────────────

def print_results(model: str, results: list[dict]):
    passed = sum(1 for r in results if r["pass"])
    total  = len(results)
    print(f"\n{'═'*70}")
    print(f"  Model: {model}   Score: {passed}/{total}   "
          f"Avg response: {sum(r['total_time'] for r in results)/total:.1f}s")
    print(f"{'═'*70}")

    for r in results:
        icon = "✅" if r["pass"] else "❌"
        print(f"\n  {icon} [{r['id']}] {r['description']}")
        print(f"     Q: \"{r['question']}\"")
        print(f"     Stage1:  intent={r.get('stage1_intent','?')} "
              f"metric={r.get('stage1_metric','?')} "
              f"inherit={r.get('stage1_inherit','?')} "
              f"({r.get('stage1_time','?')}s)")
        print(f"     Stage2:  limit={r.get('stage2_limit')} "
              f"time={r.get('stage2_time_r')} "
              f"dims={r.get('stage2_dims')} "
              f"region={r.get('stage2_region')}")
        if r.get("stage3_changed"):
            print(f"     Stage3:  ⚠️  CHANGED intent")
        print(f"     Final:   intent={r.get('final_intent')} "
              f"metric={r.get('final_metric')} "
              f"time={r.get('final_time_r')} "
              f"group_by={r.get('final_group_by')} "
              f"limit={r.get('final_limit')}")
        if r.get("sql"):
            print(f"     SQL:     {r['sql'][:100]}{'...' if len(r.get('sql',''))>100 else ''}")
        if r.get("rows_returned") is not None and r.get("final_intent") == "data":
            print(f"     Rows:    {r['rows_returned']}")
        if r.get("exec_error"):
            print(f"     Error:   {r['exec_error']}")
        if not r["pass"]:
            print(f"     FAIL:    {r['fail_reason']}")
        print(f"     Time:    {r['total_time']}s total")


def print_comparison(all_results: dict[str, list[dict]]):
    """Side-by-side summary across all models."""
    print(f"\n\n{'═'*70}")
    print("  CROSS-MODEL COMPARISON")
    print(f"{'═'*70}")
    print(f"  {'Test':<6} {'Description':<40} " +
          " ".join(f"{m[:12]:<13}" for m in all_results))
    print(f"  {'-'*6} {'-'*40} " + " ".join(f"{'-'*12:<13}" for _ in all_results))

    test_ids = [r["id"] for r in list(all_results.values())[0]]
    for tid in test_ids:
        row_results = {m: next((r for r in rs if r["id"]==tid), None)
                       for m, rs in all_results.items()}
        first = list(row_results.values())[0]
        desc  = first["description"][:38] if first else ""
        line  = f"  {tid:<6} {desc:<40} "
        for model, r in row_results.items():
            if r is None:
                line += f"{'N/A':<13}"
            elif r["pass"]:
                line += f"{'✅ ' + str(r['total_time'])+'s':<13}"
            else:
                issue = (r.get("fail_reason") or "")[:10]
                line += f"{'❌ ' + issue:<13}"
        print(line)

    print(f"\n  {'TOTAL':<6} {'':40} " +
          " ".join(f"{sum(r['pass'] for r in rs)}/{len(rs):<12}"
                   for rs in all_results.values()))
    print(f"  {'AVG_T':<6} {'':40} " +
          " ".join(f"{sum(r['total_time'] for r in rs)/len(rs):.1f}s{'':<10}"
                   for rs in all_results.values()))


# ── Main ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n🔍 BankMetric — Live Model Test Runner")
    print("   Tests 15 questions through full 4-stage pipeline")
    print("   Captures Stage1→2→3→4 output and SQL for every question\n")

    # Check Ollama
    available = get_available_models()
    if not available:
        print("❌ Ollama not running. Start with: ollama serve")
        sys.exit(1)

    print(f"✅ Ollama running. Available models: {available}")

    # Seed DB
    get_connection()

    # Determine which models to test
    # Priority models — test all that are available
    PREFERRED = ["mistral:7b", "llama3.1:8b", "phi3:mini", "llama3.2:3b"]
    models_to_test = []
    for pref in PREFERRED:
        match = next((m for m in available if pref.split(":")[0] in m), None)
        if match and match not in models_to_test:
            models_to_test.append(match)

    if not models_to_test:
        models_to_test = available[:2]  # test first 2 available

    print(f"Testing models: {models_to_test}\n")

    # Run tests
    all_results = {}
    for model in models_to_test:
        print(f"\n{'─'*70}")
        print(f"  Running {len(TEST_CASES)} tests on {model}...")
        print(f"{'─'*70}")
        model_results = []
        for i, test in enumerate(TEST_CASES, 1):
            print(f"  [{i:02d}/{len(TEST_CASES)}] {test['id']}: {test['question'][:50]}...", end="", flush=True)
            r = run_test(test, model)
            icon = "✅" if r["pass"] else "❌"
            print(f" {icon} ({r['total_time']}s)")
            model_results.append(r)
        all_results[model] = model_results
        print_results(model, model_results)

    # Cross-model comparison
    if len(models_to_test) > 1:
        print_comparison(all_results)

    # Save full results
    timestamp  = datetime.now().strftime("%Y-%m-%d_%H-%M")
    out_dir    = os.path.join(os.path.dirname(__file__), "results")
    json_path  = os.path.join(out_dir, f"model_comparison_{timestamp}.json")
    txt_path   = os.path.join(out_dir, f"model_comparison_{timestamp}.txt")

    with open(json_path, "w") as f:
        json.dump(all_results, f, indent=2, default=str)

    print(f"\n📁 Full results saved:")
    print(f"   JSON: {json_path}")

    print("\n✅ Done")
