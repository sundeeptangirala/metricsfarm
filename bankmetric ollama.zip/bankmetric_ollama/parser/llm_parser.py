"""
BankMetric - LLM Parser (Ollama)
Replaces the rule-based nl_parser.py.

Sends the user's question to a local Ollama model and gets back
a structured QueryObject — no regex, no keyword lists, no maintenance.

Requires:
  - Ollama running locally: http://localhost:11434
  - Model pulled: ollama pull llama3.2:3b

Falls back to rule-based parsing if Ollama is unavailable.
"""

import re
import json
import requests
import logging
from datetime import date, timedelta
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

OLLAMA_URL  = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2:3b"   # swap to phi3:mini or mistral if preferred
TIMEOUT_SEC  = 30


# ── Structured Query Object (identical interface to rule-based parser) ─────────

@dataclass
class QueryObject:
    metric: str | None = None
    time_range: str | None = None
    group_by: list[str] = field(default_factory=list)
    filters: dict = field(default_factory=dict)
    raw_text: str = ""
    confidence: float = 1.0
    error: str | None = None


# ── Date range resolver (unchanged from prototype) ────────────────────────────

def resolve_date_range(time_range: str, raw: str = "") -> tuple[str, str]:
    today = date.today()

    def quarter_start(d): return date(d.year, ((d.month - 1) // 3) * 3 + 1, 1)
    def month_start(d):   return date(d.year, d.month, 1)

    ranges = {
        "today":        (today, today),
        "this_week":    (today - timedelta(days=today.weekday()), today),
        "last_week":    ((e := today - timedelta(days=today.weekday() + 1)) - timedelta(days=6), e),
        "this_month":   (month_start(today), today),
        "last_month":   ((s := month_start((e2 := month_start(today) - timedelta(days=1))), e2)[0], e2),
        "this_quarter": (quarter_start(today), today),
        "last_quarter": ((qs := quarter_start(today), (qe := qs - timedelta(days=1)), quarter_start(qe))[2], quarter_start(today) - timedelta(days=1)),
        "this_year":    (date(today.year, 1, 1), today),
        "last_year":    (date(today.year - 1, 1, 1), date(today.year - 1, 12, 31)),
        "year_to_date": (date(today.year, 1, 1), today),
        "last_30_days": (today - timedelta(days=30), today),
        "last_90_days": (today - timedelta(days=90), today),
    }

    # Handle last_quarter properly
    if time_range == "last_quarter":
        qs = quarter_start(today)
        qe = qs - timedelta(days=1)
        return quarter_start(qe).isoformat(), qe.isoformat()

    if time_range in ranges:
        s, e3 = ranges[time_range]
        return s.isoformat(), e3.isoformat()

    # last_n_days
    m = re.search(r"last[_\s](\d+)[_\s]days?", time_range or "")
    if m:
        return (today - timedelta(days=int(m.group(1)))).isoformat(), today.isoformat()

    return (today - timedelta(days=30)).isoformat(), today.isoformat()


# ── Metric registry (used in prompt — keeps LLM grounded to real metrics) ────

AVAILABLE_METRICS = [
    "total_revenue",
    "transaction_count",
    "average_transaction",
    "revenue_per_customer",
    "active_customers",
    "new_customers",
    "churn_rate",
    "total_loan_value",
    "loan_count",
    "delinquency_rate",
]

AVAILABLE_DIMS    = ["region", "product", "channel", "customer"]
AVAILABLE_REGIONS = ["North America", "Europe", "APAC", "Latin America"]
AVAILABLE_PRODUCTS= ["Mortgage", "Personal Loan", "Auto Loan", "Business Loan", "Credit Card"]
AVAILABLE_CHANNELS= ["Branch", "Online", "Mobile", "Agent"]

TIME_RANGE_VALUES = [
    "today", "this_week", "last_week",
    "this_month", "last_month",
    "this_quarter", "last_quarter",
    "this_year", "last_year", "year_to_date",
    "last_30_days", "last_90_days",
]


# ── System prompt — sent once per call ────────────────────────────────────────

def _build_prompt(question: str, context: list[dict]) -> str:
    ctx_str = ""
    if context:
        last = context[-1]
        ctx_str = f"""
Previous query context (for resolving follow-up questions like "break that down" or "what about this quarter"):
- Last metric: {last.get('metric', 'none')}
- Last time_range: {last.get('time_range', 'none')}
- Last group_by: {last.get('group_by', [])}
- Last filters: {last.get('filters', {})}
"""

    return f"""You are a banking analytics query parser. Your ONLY job is to convert a natural language question into a JSON query object.

AVAILABLE METRICS (use exactly these names):
{json.dumps(AVAILABLE_METRICS, indent=2)}

AVAILABLE DIMENSIONS for group_by:
{AVAILABLE_DIMS}

AVAILABLE FILTERS:
- region: {AVAILABLE_REGIONS}
- product: {AVAILABLE_PRODUCTS}
- channel: {AVAILABLE_CHANNELS}
- limit: integer (for "top N" questions)

AVAILABLE TIME RANGES (use exactly these values):
{TIME_RANGE_VALUES}
{ctx_str}
RULES:
1. Return ONLY a valid JSON object — no explanation, no markdown, no backticks
2. If the question is a follow-up ("break that down", "what about this quarter", "show me last year"), inherit the metric and/or filters from the context above
3. group_by is a list — can have multiple dimensions e.g. ["region", "product"]
4. filters is a dict — only include filters explicitly mentioned
5. If you cannot identify a metric, set metric to null and error to a helpful message
6. confidence is 0.0 to 1.0 — how confident you are in the parse
7. For "top N X by Y" questions: set group_by to the X dimension, filters.limit to N, metric to the Y metric

QUESTION: "{question}"

Return this exact JSON structure:
{{
  "metric": "metric_name_or_null",
  "time_range": "time_range_value_or_null",
  "group_by": [],
  "filters": {{}},
  "confidence": 0.95,
  "error": null
}}"""


# ── Main parse function ────────────────────────────────────────────────────────

def parse(text: str, conversation_context: list[dict] | None = None) -> QueryObject:
    """
    Parse a natural language question using Ollama LLM.
    Falls back to rule-based parsing if Ollama is unavailable.
    """
    q = QueryObject(raw_text=text)
    context = conversation_context or []

    # Try LLM first
    try:
        result = _parse_with_llm(text, context)
        if result:
            return result
    except Exception as e:
        logger.warning(f"Ollama unavailable ({e}), falling back to rule-based parser")

    # Fallback to rule-based
    logger.info("Using rule-based fallback parser")
    return _parse_rule_based(text, context)


def _parse_with_llm(text: str, context: list[dict]) -> QueryObject | None:
    """Call Ollama and parse the response into a QueryObject."""
    prompt = _build_prompt(text, context)

    response = requests.post(
        OLLAMA_URL,
        json={
            "model":  OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.1,   # low temp = deterministic, structured output
                "top_p": 0.9,
                "num_predict": 200,   # we only need a small JSON blob
            }
        },
        timeout=TIMEOUT_SEC
    )
    response.raise_for_status()

    raw = response.json().get("response", "").strip()
    logger.debug(f"LLM raw response: {raw}")

    # Extract JSON from response (model sometimes wraps in text)
    json_match = re.search(r'\{.*\}', raw, re.DOTALL)
    if not json_match:
        logger.warning(f"No JSON found in LLM response: {raw[:200]}")
        return None

    data = json.loads(json_match.group())

    q = QueryObject(
        raw_text    = text,
        metric      = data.get("metric") or None,
        time_range  = data.get("time_range") or "last_30_days",
        group_by    = data.get("group_by") or [],
        filters     = data.get("filters") or {},
        confidence  = float(data.get("confidence", 0.9)),
        error       = data.get("error") or None,
    )

    # Validate metric exists
    if q.metric and q.metric not in AVAILABLE_METRICS:
        # Try fuzzy match
        match = _fuzzy_match_metric(q.metric)
        if match:
            logger.info(f"Fuzzy matched '{q.metric}' → '{match}'")
            q.metric = match
        else:
            q.error = (
                f"Metric '{q.metric}' not found. "
                f"Available: {', '.join(AVAILABLE_METRICS)}"
            )
            q.metric = None

    if not q.metric and not q.error:
        q.error = (
            "I couldn't identify a metric in your question. "
            "Try asking about: revenue, customers, loans, churn rate, "
            "delinquency rate, or top customers by revenue."
        )

    return q


def _fuzzy_match_metric(name: str) -> str | None:
    """Try to match a slightly wrong metric name to a known one."""
    name = name.lower().replace(" ", "_").replace("-", "_")
    for m in AVAILABLE_METRICS:
        if name in m or m in name:
            return m
    # Common aliases
    aliases = {
        "revenue":          "total_revenue",
        "sales":            "total_revenue",
        "income":           "total_revenue",
        "transactions":     "transaction_count",
        "customers":        "active_customers",
        "active_users":     "active_customers",
        "churn":            "churn_rate",
        "delinquency":      "delinquency_rate",
        "loans":            "loan_count",
        "loan_value":       "total_loan_value",
    }
    return aliases.get(name)


# ── Rule-based fallback (simplified, reliable safety net) ─────────────────────

def _parse_rule_based(text: str, context: list[dict]) -> QueryObject:
    """
    Simplified rule-based parser as fallback when Ollama is unavailable.
    Handles the most common patterns reliably.
    """
    q = QueryObject(raw_text=text)
    lower = text.lower().strip()

    # Follow-up detection
    follow_ups = ["break that", "break it", "what about", "now by",
                  "same for", "split by", "which region", "which product"]
    if any(t in lower for t in follow_ups) and context:
        last = context[-1]
        q.metric     = last.get("metric")
        q.time_range = last.get("time_range")
        q.filters    = dict(last.get("filters", {}))

    # Metric detection
    METRIC_KEYWORDS = [
        ("revenue per customer",    "revenue_per_customer"),
        ("top customers by revenue","revenue_per_customer"),
        ("customers by revenue",    "revenue_per_customer"),
        ("total revenue",           "total_revenue"),
        ("revenue",                 "total_revenue"),
        ("transaction count",       "transaction_count"),
        ("transactions",            "transaction_count"),
        ("average transaction",     "average_transaction"),
        ("active customers",        "active_customers"),
        ("new customers",           "new_customers"),
        ("churn rate",              "churn_rate"),
        ("churn",                   "churn_rate"),
        ("total loan value",        "total_loan_value"),
        ("loan value",              "total_loan_value"),
        ("loan count",              "loan_count"),
        ("loans",                   "loan_count"),
        ("delinquency rate",        "delinquency_rate"),
        ("delinquency",             "delinquency_rate"),
        ("customers",               "active_customers"),
    ]
    if not q.metric:
        for kw, metric in METRIC_KEYWORDS:
            if kw in lower:
                q.metric = metric
                break

    if not q.metric:
        q.error = ("Could not identify a metric. Ollama is offline — "
                   "start Ollama to enable full natural language understanding.")
        return q

    # Time range
    TIME_PATTERNS = [
        (r"last\s+month",           "last_month"),
        (r"this\s+month",           "this_month"),
        (r"last\s+quarter",         "last_quarter"),
        (r"this\s+quarter",         "this_quarter"),
        (r"last\s+year",            "last_year"),
        (r"this\s+year",            "this_year"),
        (r"year\s+to\s+date|ytd",  "year_to_date"),
        (r"last\s+30\s+days?",      "last_30_days"),
        (r"last\s+90\s+days?",      "last_90_days"),
        (r"today",                  "today"),
    ]
    if not q.time_range:
        for pattern, tr in TIME_PATTERNS:
            if re.search(pattern, lower):
                q.time_range = tr
                break
        if not q.time_range:
            q.time_range = "last_30_days"

    # Dimensions
    if re.search(r"by\s+region|per\s+region|which\s+region", lower):
        q.group_by.append("region")
    if re.search(r"by\s+product|per\s+product|which\s+product", lower):
        q.group_by.append("product")
    if re.search(r"by\s+channel|per\s+channel|which\s+channel", lower):
        q.group_by.append("channel")
    if re.search(r"by\s+customer|top\s+\d+\s+customers?", lower):
        q.group_by.append("customer")

    if q.metric == "revenue_per_customer" and "customer" not in q.group_by:
        q.group_by.insert(0, "customer")

    # Filters
    regions = {"north america":"North America","europe":"Europe",
                "apac":"APAC","latin america":"Latin America"}
    for k, v in regions.items():
        if k in lower and "by region" not in lower:
            q.filters["region"] = v

    top = re.search(r"top\s+(\d+)", lower)
    if top:
        q.filters["limit"] = int(top.group(1))

    return q


# ── Ollama health check ────────────────────────────────────────────────────────

def check_ollama() -> dict:
    """Check if Ollama is running and the model is available."""
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        models = [m["name"] for m in r.json().get("models", [])]
        has_model = any(OLLAMA_MODEL.split(":")[0] in m for m in models)
        return {
            "running": True,
            "models": models,
            "target_model": OLLAMA_MODEL,
            "model_available": has_model,
            "status": "ready" if has_model else "model_not_pulled",
        }
    except requests.exceptions.ConnectionError:
        return {
            "running": False,
            "status": "ollama_not_running",
            "fix": "Run: ollama serve",
        }
    except Exception as e:
        return {"running": False, "status": "error", "error": str(e)}


# ── Quick test ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys

    status = check_ollama()
    print(f"Ollama status: {status}")

    if not status["running"]:
        print("Ollama not running — testing rule-based fallback only")

    tests = [
        ("Show me total revenue by region last quarter", []),
        ("Top 5 customers by revenue in North America", []),
        ("What is the delinquency rate by product?", []),
        ("Active customers this month", []),
        ("Break that down by channel", [{"metric": "active_customers",
                                          "time_range": "this_month",
                                          "group_by": [], "filters": {}}]),
        ("Which channel is most used by customers?", []),
        ("Show churn rate in Europe last year", []),
        ("What was our loan value last quarter by product?", []),
    ]

    for question, ctx in tests:
        result = parse(question, ctx)
        ok = "✅" if not result.error else "❌"
        print(f"\n{ok} '{question}'")
        print(f"   metric={result.metric}, time={result.time_range}, "
              f"group_by={result.group_by}, filters={result.filters}")
        if result.error:
            print(f"   error: {result.error}")
