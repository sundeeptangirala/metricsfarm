"""
BankMetric — LLM Parser (Ollama)  v3

Architecture:
  1. Intent classification  (Python, always)     → data | ui_command | clarify
  2. Follow-up detection    (Python, always)      → inherit context, extract delta
  3. LLM parsing            (Ollama, fresh only)  → structured JSON
  4. Rule-based fallback    (Python, if offline)  → reliable keyword matching

Key design decisions:
  - UI commands ("line chart", "export") are caught BEFORE any parsing
  - User-specified limit ALWAYS wins over metric defaults
  - LLM is only called for genuinely ambiguous fresh questions
  - Every path produces a consistent QueryObject
"""

import re
import json
import requests
import logging
from datetime import date, timedelta
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2:3b"
TIMEOUT_SEC  = 30


# ── QueryObject ────────────────────────────────────────────────────────────────

@dataclass
class QueryObject:
    metric:     str | None  = None
    time_range: str | None  = None
    group_by:   list[str]   = field(default_factory=list)
    filters:    dict        = field(default_factory=dict)
    raw_text:   str         = ""
    confidence: float       = 1.0
    error:      str | None  = None
    # intent: "data" | "ui_command" | "clarify"
    intent:     str         = "data"
    ui_action:  str | None  = None   # e.g. "line_chart", "bar_chart", "export"


# ── Date resolver ──────────────────────────────────────────────────────────────

def resolve_date_range(time_range: str, raw: str = "") -> tuple[str, str]:
    today = date.today()
    def qs(d): return date(d.year, ((d.month-1)//3)*3+1, 1)
    def ms(d): return date(d.year, d.month, 1)

    TR = {
        "today":        (today, today),
        "this_week":    (today - timedelta(days=today.weekday()), today),
        "this_month":   (ms(today), today),
        "this_quarter": (qs(today), today),
        "this_year":    (date(today.year,1,1), today),
        "year_to_date": (date(today.year,1,1), today),
        "last_30_days": (today - timedelta(30), today),
        "last_90_days": (today - timedelta(90), today),
    }
    if time_range == "last_quarter":
        e = qs(today) - timedelta(1);  return qs(e).isoformat(), e.isoformat()
    if time_range == "last_month":
        e = ms(today) - timedelta(1);  return ms(e).isoformat(), e.isoformat()
    if time_range == "last_year":
        return date(today.year-1,1,1).isoformat(), date(today.year-1,12,31).isoformat()
    if time_range == "last_week":
        e = today - timedelta(days=today.weekday()+1)
        return (e-timedelta(6)).isoformat(), e.isoformat()
    if time_range in TR:
        s, e = TR[time_range]; return s.isoformat(), e.isoformat()
    m = re.search(r"last[_\s](\d+)[_\s]days?", time_range or "")
    if m: return (today-timedelta(int(m.group(1)))).isoformat(), today.isoformat()
    return (today-timedelta(30)).isoformat(), today.isoformat()


# ── Registry ───────────────────────────────────────────────────────────────────

AVAILABLE_METRICS = [
    "total_revenue", "transaction_count", "average_transaction",
    "revenue_per_customer", "active_customers", "new_customers",
    "churn_rate", "total_loan_value", "loan_count", "delinquency_rate",
]
AVAILABLE_DIMS     = ["region", "product", "channel", "customer"]
AVAILABLE_REGIONS  = ["North America", "Europe", "APAC", "Latin America"]
AVAILABLE_PRODUCTS = ["Mortgage", "Personal Loan", "Auto Loan", "Business Loan", "Credit Card"]
AVAILABLE_CHANNELS = ["Branch", "Online", "Mobile", "Agent"]
TIME_RANGE_VALUES  = [
    "today","this_week","last_week","this_month","last_month",
    "this_quarter","last_quarter","this_year","last_year",
    "year_to_date","last_30_days","last_90_days",
]

# ── Intent classification ──────────────────────────────────────────────────────
# These are caught BEFORE any parsing. They are UI instructions, not data queries.
# Maps regex pattern → ui_action identifier.

UI_COMMAND_PATTERNS = [
    # Chart type changes
    (r"\bline\s+chart\b",                "chart_line"),
    (r"\bbar\s+chart\b",                 "chart_bar"),
    (r"\bconvert\s+.{0,20}(line|bar|pie|chart)\b", "chart_change"),
    (r"\bshow\s+.{0,10}(as|in)\s+(line|bar|pie|table)\b", "chart_change"),
    (r"\bchange\s+.{0,10}(to|into)\s+(line|bar|pie|chart)\b", "chart_change"),
    (r"\bmake\s+.{0,10}(line|bar|pie|chart)\b", "chart_change"),
    # Export / save
    (r"\bexport\b",                      "export"),
    (r"\bdownload\b",                    "export"),
    (r"\bsave\s+(this|as|to)\b",         "export"),
    # UI navigation
    (r"\bgo\s+back\b",                   "navigate"),
    (r"\bclear\b",                       "clear"),
    (r"\breset\b",                       "clear"),
    # Explanation requests (not data queries)
    (r"\bwhat\s+(is|are|does)\s+(a|an|the)\b", "explain"),
    (r"\bexplain\s+(this|that|how)\b",   "explain"),
    (r"\bhelp\s+me\s+understand\b",      "explain"),
]

def classify_intent(lower: str) -> tuple[str, str | None]:
    """
    Returns ("data", None) or ("ui_command", action_name).
    UI commands are things like chart changes, exports, explanations.
    """
    for pattern, action in UI_COMMAND_PATTERNS:
        if re.search(pattern, lower):
            return "ui_command", action
    return "data", None


# ── Follow-up detection ────────────────────────────────────────────────────────

FOLLOW_UP_PHRASES = [
    "break that", "break it", "now by", "also by", "and by",
    "split by", "drill down", "same for", "show me that",
    "what about", "how about", "now show",
]

DIM_PATTERNS = {
    "region":   [r"by\s+region", r"per\s+region", r"by\s+geography",
                 r"across\s+regions?", r"which\s+region",
                 r"top\s+\d+\s+regions?", r"best\s+region"],
    "product":  [r"by\s+product", r"per\s+product", r"by\s+loan\s+type",
                 r"across\s+products?", r"which\s+product",
                 r"top\s+\d+\s+products?", r"best\s+product"],
    "channel":  [r"by\s+channel", r"per\s+channel", r"across\s+channels?",
                 r"which\s+channel", r"most\s+used\s+channel",
                 r"best\s+channel"],
    "customer": [r"by\s+customer", r"per\s+customer",
                 r"top\s+\d+\s+customers?", r"customer\s+breakdown",
                 r"most\s+valuable\s+customers?"],
}

TIME_PATTERNS = [
    (r"last\s+quarter",        "last_quarter"),
    (r"this\s+quarter",        "this_quarter"),
    (r"last\s+month",          "last_month"),
    (r"this\s+month",          "this_month"),
    (r"last\s+year",           "last_year"),
    (r"this\s+year",           "this_year"),
    (r"year\s+to\s+date|ytd", "year_to_date"),
    (r"last\s+30\s+days?",     "last_30_days"),
    (r"last\s+90\s+days?",     "last_90_days"),
    (r"\btoday\b",             "today"),
    (r"this\s+week",           "this_week"),
    (r"last\s+week",           "last_week"),
]

def _detect_dims(lower: str) -> list[str]:
    return [d for d, pats in DIM_PATTERNS.items()
            if any(re.search(p, lower) for p in pats)]

def _detect_time(lower: str) -> str | None:
    for pat, tr in TIME_PATTERNS:
        if re.search(pat, lower): return tr
    return None

def _detect_limit(lower: str) -> int | None:
    m = re.search(r"top\s+(\d+)", lower)
    return int(m.group(1)) if m else None

def _detect_region_filter(lower: str) -> str | None:
    # Only applies when not asking "by region" (that's a dimension, not a filter)
    if re.search(r"by\s+region|across\s+regions?|per\s+region", lower):
        return None
    for name, val in [("north america","North America"),("latin america","Latin America"),
                       ("europe","Europe"),("apac","APAC"),("asia pacific","APAC"),("asia","APAC")]:
        if name in lower: return val
    return None

def _detect_product_filter(lower: str) -> str | None:
    if re.search(r"by\s+product|across\s+products?|per\s+product", lower):
        return None
    for name, val in [("personal loan","Personal Loan"),("personal loans","Personal Loan"),
                       ("auto loan","Auto Loan"),("auto loans","Auto Loan"),
                       ("business loan","Business Loan"),("business loans","Business Loan"),
                       ("credit card","Credit Card"),("credit cards","Credit Card"),
                       ("mortgage","Mortgage"),("mortgages","Mortgage")]:
        if name in lower: return val
    return None

def _is_follow_up(lower: str) -> bool:
    return any(p in lower for p in FOLLOW_UP_PHRASES)


# ── Main entry point ───────────────────────────────────────────────────────────

def parse(text: str, conversation_context: list[dict] | None = None) -> QueryObject:
    """
    Parse a natural language input.

    Decision tree:
      1. UI command?    → return QueryObject(intent="ui_command")
      2. Follow-up?     → inherit context, extract delta in Python
      3. Fresh query    → try Ollama LLM, fall back to rules
    """
    context = conversation_context or []
    lower   = text.lower().strip()

    # ── 1. UI command classification ──────────────────────────────────────
    intent, ui_action = classify_intent(lower)
    if intent == "ui_command":
        return QueryObject(
            raw_text  = text,
            intent    = "ui_command",
            ui_action = ui_action,
        )

    # ── 2. Follow-up detection ────────────────────────────────────────────
    if _is_follow_up(lower) and context:
        return _resolve_follow_up(text, lower, context)

    # ── 3. LLM (fresh questions) ──────────────────────────────────────────
    try:
        result = _parse_with_llm(text, context)
        if result: return result
    except Exception as e:
        logger.warning(f"Ollama unavailable ({e}), using rule-based fallback")

    # ── 4. Rule-based fallback ─────────────────────────────────────────────
    return _parse_rule_based(text, lower, context)


# ── Follow-up resolver ─────────────────────────────────────────────────────────

def _resolve_follow_up(text: str, lower: str, context: list[dict]) -> QueryObject:
    """
    Inherit metric + time_range from last turn.
    Only extract what genuinely changed: new dim, new time, new limit, new filter.
    """
    last = context[-1]

    # Start from last context — deep copy filters so we don't mutate history
    q = QueryObject(
        raw_text   = text,
        metric     = last.get("metric"),
        time_range = last.get("time_range") or "last_30_days",
        group_by   = list(last.get("group_by") or []),
        filters    = {k:v for k,v in (last.get("filters") or {}).items()
                      if k not in ("limit",)},  # drop old limit, user may specify new
        confidence = 0.99,
        intent     = "data",
    )

    new_dims = _detect_dims(lower)
    if new_dims:
        q.group_by = new_dims

    new_time = _detect_time(lower)
    if new_time:
        q.time_range = new_time

    # User-specified limit always wins
    lim = _detect_limit(lower)
    if lim: q.filters["limit"] = lim

    reg = _detect_region_filter(lower)
    if reg: q.filters["region"] = reg

    return q


# ── LLM parsing ────────────────────────────────────────────────────────────────

def _build_prompt(question: str) -> str:
    return f"""You are a banking analytics query parser. Your ONLY output is a single JSON object.

AVAILABLE METRICS (use EXACT names):
{json.dumps(AVAILABLE_METRICS)}

DIMENSIONS for group_by (list): {AVAILABLE_DIMS}
TIME RANGES: {TIME_RANGE_VALUES}
FILTERS (dict keys): region, product, channel, limit (integer — ONLY if user says "top N")

CRITICAL RULES:
1. Return ONLY valid JSON. No explanation, no markdown, no backticks.
2. "limit" in filters ONLY if user explicitly says "top N" or "N customers" etc.
3. Do NOT invent a limit. If user does not say a number, omit limit entirely.
4. group_by is a list. Can be empty [], one item ["region"], or multiple ["region","product"].
5. If no time period mentioned, default to "last_30_days".
6. "top N regions/products" means group_by=["region"/"product"] AND filters.limit=N.
7. "top N customers" means metric="revenue_per_customer", group_by=["customer"], filters.limit=N.

QUESTION: "{question}"

{{"metric":"...","time_range":"...","group_by":[],"filters":{{}},"confidence":0.95,"error":null}}"""


def _parse_with_llm(text: str, context: list[dict]) -> QueryObject | None:
    response = requests.post(
        OLLAMA_URL,
        json={"model": OLLAMA_MODEL, "prompt": _build_prompt(text),
              "stream": False, "options": {"temperature": 0.0, "num_predict": 256}},
        timeout=TIMEOUT_SEC
    )
    response.raise_for_status()
    raw = response.json().get("response", "").strip()

    m = re.search(r'\{.*\}', raw, re.DOTALL)
    if not m: return None

    try:
        data = json.loads(m.group())
    except json.JSONDecodeError:
        return None

    metric = data.get("metric") or None

    # Validate / fuzzy match metric
    if metric and metric not in AVAILABLE_METRICS:
        metric = _fuzzy_match_metric(metric)

    q = QueryObject(
        raw_text   = text,
        metric     = metric,
        time_range = data.get("time_range") or "last_30_days",
        group_by   = data.get("group_by") or [],
        filters    = data.get("filters") or {},
        confidence = float(data.get("confidence", 0.9)),
        error      = data.get("error") or None,
        intent     = "data",
    )

    if not q.metric and not q.error:
        q.error = ("Could not identify a metric. Try: revenue, customers, "
                   "loans, churn rate, delinquency, top customers by revenue.")
    return q


def _fuzzy_match_metric(name: str) -> str | None:
    n = name.lower().replace(" ","_").replace("-","_")
    for m in AVAILABLE_METRICS:
        if n in m or m in n: return m
    return {
        "revenue":"total_revenue","sales":"total_revenue","income":"total_revenue",
        "transactions":"transaction_count","customers":"active_customers",
        "churn":"churn_rate","delinquency":"delinquency_rate",
        "loans":"loan_count","loan_value":"total_loan_value",
    }.get(n)


# ── Rule-based fallback ────────────────────────────────────────────────────────

def _parse_rule_based(text: str, lower: str, context: list[dict]) -> QueryObject:
    q = QueryObject(raw_text=text, intent="data")

    # Channel intent without explicit metric
    if any(re.search(p, lower) for p in [
        r"best\s+channel", r"which\s+channel", r"most\s+(?:used|popular)\s+channel",
        r"preferred\s+channel", r"popular\s+channel",
    ]):
        q.metric     = "transaction_count"
        q.time_range = _detect_time(lower) or "last_30_days"
        q.group_by   = ["channel"]
        lim = _detect_limit(lower)
        if lim: q.filters["limit"] = lim
        return q

    KEYWORDS = [
        ("revenue per customer",    "revenue_per_customer"),
        ("top customers by revenue","revenue_per_customer"),
        ("customers by revenue",    "revenue_per_customer"),
        ("most valuable customer",  "revenue_per_customer"),
        ("best customer",           "revenue_per_customer"),
        ("highest spending",        "revenue_per_customer"),
        ("total revenue",           "total_revenue"),
        ("revenue",                 "total_revenue"),
        ("transaction count",       "transaction_count"),
        ("transactions",            "transaction_count"),
        ("average transaction",     "average_transaction"),
        ("avg transaction",         "average_transaction"),
        ("active customers",        "active_customers"),
        ("new customers",           "new_customers"),
        ("customer acquisition",    "new_customers"),
        ("churn rate",              "churn_rate"),
        ("churn",                   "churn_rate"),
        ("attrition",               "churn_rate"),
        ("total loan value",        "total_loan_value"),
        ("loan value",              "total_loan_value"),
        ("loan book",               "total_loan_value"),
        ("loan count",              "loan_count"),
        ("number of loans",         "loan_count"),
        ("loans",                   "loan_count"),
        ("delinquency rate",        "delinquency_rate"),
        ("delinquency",             "delinquency_rate"),
        ("default rate",            "delinquency_rate"),
        ("customers",               "active_customers"),  # catch-all last
    ]

    for kw, metric in KEYWORDS:
        if kw in lower:
            q.metric = metric
            break

    if not q.metric:
        q.error = ("Could not identify a metric. "
                   "Ollama is offline — start with: ollama serve")
        return q

    q.time_range = _detect_time(lower) or "last_30_days"
    q.group_by   = _detect_dims(lower)

    if q.metric == "revenue_per_customer" and "customer" not in q.group_by:
        q.group_by.insert(0, "customer")

    reg = _detect_region_filter(lower)
    if reg: q.filters["region"] = reg

    prod = _detect_product_filter(lower)
    if prod: q.filters["product"] = prod

    # User-specified limit
    lim = _detect_limit(lower)
    if lim: q.filters["limit"] = lim

    return q


# ── Ollama status ──────────────────────────────────────────────────────────────

def check_ollama() -> dict:
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        models = [m["name"] for m in r.json().get("models", [])]
        has_model = any(OLLAMA_MODEL.split(":")[0] in m for m in models)
        return {"running": True, "models": models, "target_model": OLLAMA_MODEL,
                "model_available": has_model,
                "status": "ready" if has_model else "model_not_pulled"}
    except requests.exceptions.ConnectionError:
        return {"running": False, "status": "ollama_not_running", "fix": "Run: ollama serve"}
    except Exception as e:
        return {"running": False, "status": "error", "error": str(e)}
