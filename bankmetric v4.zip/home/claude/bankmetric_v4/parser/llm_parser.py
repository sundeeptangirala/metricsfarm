"""
BankMetric v4 — LLM Parser

Single responsibility: send question to Ollama, get structured JSON back.
The LLM decides everything — intent, metric, dimensions, time, clarification.
No rules. No keyword lists. No regex fallback.

Validation layer only checks:
  - JSON is valid
  - metric name is in registry (fuzzy match if close)
  - field types are correct
"""

import re
import json
import requests
import logging
from datetime import date, timedelta
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2:3b"
TIMEOUT_SEC  = 30

# ── Registry — single source of truth ─────────────────────────────────────────

AVAILABLE_METRICS = [
    "total_revenue", "transaction_count", "average_transaction",
    "revenue_per_customer", "active_customers", "new_customers",
    "churn_rate", "total_loan_value", "loan_count", "delinquency_rate",
]
AVAILABLE_DIMS    = ["region", "product", "channel", "customer"]
AVAILABLE_REGIONS = ["North America", "Europe", "APAC", "Latin America"]
AVAILABLE_PRODUCTS= ["Mortgage", "Personal Loan", "Auto Loan", "Business Loan", "Credit Card"]
AVAILABLE_CHANNELS= ["Branch", "Online", "Mobile", "Agent"]
AVAILABLE_TIMES   = [
    "today", "this_week", "last_week", "this_month", "last_month",
    "this_quarter", "last_quarter", "this_year", "last_year",
    "year_to_date", "last_30_days", "last_90_days",
]


# ── Output types ───────────────────────────────────────────────────────────────

@dataclass
class ClarifyOption:
    label:      str
    metric:     Optional[str] = None
    time_range: Optional[str] = None
    group_by:   list          = field(default_factory=list)
    filters:    dict          = field(default_factory=dict)

@dataclass
class QueryObject:
    intent:           str            = "data"
    metric:           Optional[str]  = None
    time_range:       Optional[str]  = None
    group_by:         list           = field(default_factory=list)
    filters:          dict           = field(default_factory=dict)
    inherit_context:  bool           = False
    ui_action:        Optional[str]  = None
    clarify_question: Optional[str]  = None
    clarify_options:  list           = field(default_factory=list)
    unclear_message:  Optional[str]  = None
    raw_text:         str            = ""
    confidence:       float          = 1.0
    parser:           str            = "llm"


# ── Date resolver ──────────────────────────────────────────────────────────────

def resolve_date_range(time_range: str) -> tuple[str, str]:
    today = date.today()
    def qs(d): return date(d.year, ((d.month-1)//3)*3+1, 1)
    def ms(d): return date(d.year, d.month, 1)
    if time_range == "last_quarter":
        e = qs(today)-timedelta(1); return qs(e).isoformat(), e.isoformat()
    if time_range == "last_month":
        e = ms(today)-timedelta(1); return ms(e).isoformat(), e.isoformat()
    if time_range == "last_year":
        return date(today.year-1,1,1).isoformat(), date(today.year-1,12,31).isoformat()
    if time_range == "last_week":
        e = today-timedelta(days=today.weekday()+1)
        return (e-timedelta(6)).isoformat(), e.isoformat()
    MAP = {
        "today":        (today, today),
        "this_week":    (today-timedelta(days=today.weekday()), today),
        "this_month":   (ms(today), today),
        "this_quarter": (qs(today), today),
        "this_year":    (date(today.year,1,1), today),
        "year_to_date": (date(today.year,1,1), today),
        "last_30_days": (today-timedelta(30), today),
        "last_90_days": (today-timedelta(90), today),
    }
    if time_range in MAP:
        s, e = MAP[time_range]; return s.isoformat(), e.isoformat()
    return (today-timedelta(30)).isoformat(), today.isoformat()


# ── The prompt ─────────────────────────────────────────────────────────────────

def _build_prompt(question: str,
                  context_turns: list[dict],
                  previous_summary: dict | None) -> str:

    # Last turn context for follow-up awareness
    context_str = ""
    if context_turns:
        last = context_turns[-1]
        context_str = f"""
Previous query (for follow-up resolution):
  metric={last.get("metric")}, time={last.get("time_range")}, group_by={last.get("group_by")}, filters={last.get("filters")}
"""

    # Previous session findings as background knowledge
    summary_str = ""
    if previous_summary and previous_summary.get("key_findings"):
        summary_str = f"""
Background from previous session (you already know this):
{json.dumps(previous_summary["key_findings"], indent=2)}
"""

    return f"""You are a banking analytics assistant. Convert the user's question into a JSON query.

{summary_str}
AVAILABLE METRICS:
{json.dumps(AVAILABLE_METRICS)}

AVAILABLE DIMENSIONS (for group_by): {AVAILABLE_DIMS}
AVAILABLE TIME RANGES: {AVAILABLE_TIMES}
AVAILABLE REGIONS: {AVAILABLE_REGIONS}
AVAILABLE PRODUCTS: {AVAILABLE_PRODUCTS}
AVAILABLE CHANNELS: {AVAILABLE_CHANNELS}
{context_str}
RESPOND WITH ONE OF FOUR INTENTS:

1. intent="data" — when you understand what metric and analysis is needed
   Set inherit_context=true if this is a follow-up to the previous query.
   When inherit_context=true, only set fields that CHANGED — leave others null.
   The group_by you return REPLACES the previous group_by — it does not add to it.

2. intent="ui_command" — when the user wants to change how results look (chart type, export, reset/clear/start over)
   Set ui_action to: chart_line | chart_bar | export | clear | display_change

3. intent="clarify" — when the question is genuinely ambiguous and two or more metrics could equally apply
   Provide 2-3 clarify_options as clickable buttons for the user to choose from.
   Each option must include label, metric, time_range, group_by, filters.

4. intent="unclear" — when the question is outside the scope of available metrics
   Provide a helpful unclear_message and suggest 2-3 data questions they could ask instead.

RULES:
- limit in filters ONLY when user explicitly says "top N" or a specific number
- group_by has one dimension unless user explicitly requests two
- Default time_range when none mentioned: "last_30_days"
- Do not invent values — if unsure, use intent="clarify"

RETURN ONLY THIS JSON — no explanation, no markdown:
{{
  "intent": "data",
  "ui_action": null,
  "metric": null,
  "time_range": null,
  "group_by": [],
  "filters": {{"region": null, "product": null, "limit": null, "order": "DESC"}},
  "inherit_context": false,
  "clarify_question": null,
  "clarify_options": null,
  "unclear_message": null,
  "confidence": 0.95
}}

USER: "{question}"
"""


# ── Validation layer — thin, schema only ──────────────────────────────────────

def _fuzzy_metric(name: str) -> Optional[str]:
    """Match near-miss metric names. Last resort after LLM returns something close."""
    if not name: return None
    n = name.lower().replace(" ", "_").replace("-", "_")
    if n in AVAILABLE_METRICS: return n
    for m in AVAILABLE_METRICS:
        if n in m or m in n: return m
    return None


def _validate(data: dict, context: list[dict]) -> QueryObject:
    """
    Thin validation — only checks types and whitelists.
    Does not apply business rules or keyword mappings.
    """
    intent = data.get("intent", "unclear")
    if intent not in ("data", "ui_command", "clarify", "unclear"):
        intent = "unclear"

    raw_text = data.get("_raw_text", "")

    if intent == "ui_command":
        return QueryObject(intent="ui_command",
                           ui_action=data.get("ui_action"),
                           raw_text=raw_text)

    if intent == "clarify":
        options = []
        for o in (data.get("clarify_options") or []):
            options.append(ClarifyOption(
                label      = str(o.get("label", "")),
                metric     = _fuzzy_metric(o.get("metric")),
                time_range = o.get("time_range"),
                group_by   = [d for d in (o.get("group_by") or []) if d in AVAILABLE_DIMS],
                filters    = o.get("filters") or {},
            ))
        return QueryObject(intent="clarify",
                           clarify_question=data.get("clarify_question", "Did you mean one of these?"),
                           clarify_options=options,
                           raw_text=raw_text)

    if intent == "unclear":
        return QueryObject(intent="unclear",
                           unclear_message=data.get("unclear_message", "I couldn't understand that."),
                           raw_text=raw_text)

    # intent == "data" — validate fields
    inherit = bool(data.get("inherit_context", False))
    last    = context[-1] if (inherit and context) else {}

    # Metric — fuzzy match only, no keyword rules
    raw_metric = data.get("metric")
    metric = _fuzzy_metric(raw_metric) if raw_metric else (last.get("metric") if inherit else None)

    # Time range — validate against whitelist
    raw_time = data.get("time_range")
    if raw_time and raw_time in AVAILABLE_TIMES:
        time_range = raw_time
    elif inherit:
        time_range = last.get("time_range") or "last_30_days"
    else:
        time_range = "last_30_days"

    # Group by — validate dims, replace (not append) on follow-up
    raw_gb = [d for d in (data.get("group_by") or []) if d in AVAILABLE_DIMS]
    if raw_gb:
        group_by = raw_gb          # user specified — use exactly these
    elif inherit:
        group_by = list(last.get("group_by") or [])  # inherit previous
    else:
        group_by = []

    # Filters — never inherit limit across turns
    base = {k: v for k, v in (last.get("filters") or {}).items()
            if inherit and k not in ("limit",)} if inherit else {}
    raw_f = data.get("filters") or {}
    filters = dict(base)

    # Region — validate against whitelist only
    r = raw_f.get("region")
    if r and r in AVAILABLE_REGIONS:
        filters["region"] = r

    # Product — validate against whitelist only
    p = raw_f.get("product")
    if p and p in AVAILABLE_PRODUCTS:
        filters["product"] = p

    # Limit — only if LLM set it (user said "top N")
    lim = raw_f.get("limit")
    if lim is not None and str(lim).isdigit():
        filters["limit"] = int(lim)

    # Order
    order = str(raw_f.get("order", "DESC")).upper()
    filters["order"] = order if order in ("ASC", "DESC") else "DESC"

    if not metric:
        # LLM couldn't identify metric — ask for clarification
        return QueryObject(intent="clarify",
                           clarify_question="I couldn't identify which metric you're asking about. What would you like to see?",
                           clarify_options=[
                               ClarifyOption(label="Revenue",          metric="total_revenue"),
                               ClarifyOption(label="Top customers",    metric="revenue_per_customer"),
                               ClarifyOption(label="Active customers", metric="active_customers"),
                               ClarifyOption(label="Delinquency rate", metric="delinquency_rate"),
                           ],
                           raw_text=raw_text)

    return QueryObject(
        intent          = "data",
        metric          = metric,
        time_range      = time_range,
        group_by        = group_by,
        filters         = filters,
        inherit_context = inherit,
        confidence      = float(data.get("confidence", 0.9)),
        raw_text        = raw_text,
        parser          = "llm",
    )


# ── Main parse function ────────────────────────────────────────────────────────

def parse(text: str,
          context_turns: list[dict] | None = None,
          previous_summary: dict | None = None) -> QueryObject:
    """
    Send question to Ollama. Validate the JSON response. Return QueryObject.
    No fallback rules — if Ollama is offline, tell the user clearly.
    """
    ctx    = context_turns or []
    prompt = _build_prompt(text, ctx, previous_summary)

    try:
        resp = requests.post(
            OLLAMA_URL,
            json={"model": OLLAMA_MODEL, "prompt": prompt,
                  "stream": False, "options": {"temperature": 0.0, "num_predict": 500}},
            timeout=TIMEOUT_SEC,
        )
        resp.raise_for_status()
        raw = resp.json().get("response", "").strip()
        logger.debug(f"LLM: {raw[:300]}")

    except requests.exceptions.ConnectionError:
        return QueryObject(intent="unclear", parser="offline",
            unclear_message="Ollama is not running.\n\nStart it with:\n```\nollama serve\n```")
    except requests.exceptions.Timeout:
        return QueryObject(intent="unclear", parser="offline",
            unclear_message="Ollama took too long. Try again in a few seconds.")
    except Exception as e:
        return QueryObject(intent="unclear", parser="offline",
            unclear_message=f"Connection error: {str(e)}")

    # Parse JSON — retry once with simpler prompt if malformed
    data = _extract_json(raw)
    if data is None:
        try:
            retry = (f'Return only valid JSON for: "{text}"\n'
                     f'{{"intent":"clarify","clarify_question":"Could you rephrase that?",'
                     f'"clarify_options":[],"metric":null,"time_range":"last_30_days",'
                     f'"group_by":[],"filters":{{}},"inherit_context":false,"confidence":0.5}}')
            r2  = requests.post(OLLAMA_URL, json={"model": OLLAMA_MODEL, "prompt": retry,
                  "stream": False, "options": {"temperature": 0.0, "num_predict": 200}},
                  timeout=TIMEOUT_SEC)
            data = _extract_json(r2.json().get("response", ""))
        except:
            pass

    if data is None:
        return QueryObject(intent="clarify",
            clarify_question="I had trouble understanding that — could you rephrase?",
            clarify_options=[], raw_text=text)

    data["_raw_text"] = text
    return _validate(data, ctx)


def _extract_json(raw: str) -> dict | None:
    if not raw: return None
    raw = re.sub(r"```json\s*", "", raw)
    raw = re.sub(r"```\s*", "", raw)
    m = re.search(r'\{.*\}', raw, re.DOTALL)
    if not m: return None
    try: return json.loads(m.group())
    except: return None


# ── Ollama status ──────────────────────────────────────────────────────────────

def check_ollama() -> dict:
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        models = [m["name"] for m in r.json().get("models", [])]
        has_model = any(OLLAMA_MODEL.split(":")[0] in m for m in models)
        return {"running": True, "models": models, "target_model": OLLAMA_MODEL,
                "model_available": has_model,
                "status": "ready" if has_model else "model_not_pulled"}
    except requests.exceptions.ConnectionError:
        return {"running": False, "status": "ollama_not_running"}
    except Exception as e:
        return {"running": False, "status": "error", "error": str(e)}
