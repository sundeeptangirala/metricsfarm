"""
BankMetric - In-Memory SQLite Database
Creates all tables and seeds realistic banking data on startup.
"""
import sqlite3
import random
from datetime import date, timedelta

_conn: sqlite3.Connection | None = None


def get_connection() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(":memory:", check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _create_schema(_conn)
        _seed_data(_conn)
    return _conn


def _create_schema(conn: sqlite3.Connection):
    conn.executescript("""
    CREATE TABLE customers (
        id              INTEGER PRIMARY KEY,
        name            TEXT NOT NULL,
        joined_date     DATE NOT NULL,
        region          TEXT NOT NULL,
        product         TEXT NOT NULL,
        status          TEXT NOT NULL,
        channel         TEXT NOT NULL
    );

    CREATE TABLE transactions (
        id              INTEGER PRIMARY KEY,
        transaction_date DATE NOT NULL,
        amount          REAL NOT NULL,
        region          TEXT NOT NULL,
        product         TEXT NOT NULL,
        channel         TEXT NOT NULL,
        status          TEXT NOT NULL,
        customer_id     INTEGER REFERENCES customers(id)
    );

    CREATE TABLE loans (
        id              INTEGER PRIMARY KEY,
        origination_date DATE NOT NULL,
        amount          REAL NOT NULL,
        region          TEXT NOT NULL,
        product         TEXT NOT NULL,
        status          TEXT NOT NULL
    );

    CREATE TABLE metric_registry (
        id              INTEGER PRIMARY KEY,
        metric_name     TEXT UNIQUE NOT NULL,
        display_name    TEXT NOT NULL,
        description     TEXT,
        formula         TEXT NOT NULL,
        source_table    TEXT NOT NULL,
        allowed_dims    TEXT NOT NULL,
        allowed_time    INTEGER DEFAULT 1,
        owner           TEXT,
        status          TEXT DEFAULT 'published'
    );
    """)
    conn.commit()


FIRST_NAMES = [
    "James","Mary","John","Patricia","Robert","Jennifer","Michael","Linda",
    "William","Barbara","David","Susan","Richard","Jessica","Joseph","Sarah",
    "Thomas","Karen","Charles","Lisa","Christopher","Nancy","Daniel","Betty",
    "Matthew","Margaret","Anthony","Sandra","Mark","Ashley","Donald","Dorothy",
    "Steven","Kimberly","Paul","Emily","Andrew","Donna","Joshua","Michelle",
    "Kenneth","Carol","Kevin","Amanda","Brian","Melissa","George","Deborah",
    "Timothy","Stephanie","Ronald","Rebecca","Edward","Sharon","Jason","Laura",
    "Jeffrey","Cynthia","Ryan","Kathleen","Jacob","Amy","Gary","Angela",
]
LAST_NAMES = [
    "Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis",
    "Rodriguez","Martinez","Hernandez","Lopez","Gonzalez","Wilson","Anderson",
    "Thomas","Taylor","Moore","Jackson","Martin","Lee","Perez","Thompson",
    "White","Harris","Sanchez","Clark","Ramirez","Lewis","Robinson","Walker",
    "Young","Allen","King","Wright","Scott","Torres","Nguyen","Hill","Flores",
    "Green","Adams","Nelson","Baker","Hall","Rivera","Campbell","Mitchell",
    "Carter","Roberts","Turner","Phillips","Evans","Collins","Parker","Edwards",
]


def _seed_data(conn: sqlite3.Connection):
    regions    = ["North America", "Europe", "APAC", "Latin America"]
    products   = ["Mortgage", "Personal Loan", "Auto Loan", "Business Loan", "Credit Card"]
    channels   = ["Branch", "Online", "Mobile", "Agent"]
    loan_prods = ["Mortgage", "Personal Loan", "Auto Loan", "Business Loan"]

    random.seed(42)
    today = date.today()

    # ── Customers first ────────────────────────────────────────────────
    custs = []
    used_names = set()
    for i in range(1, 2001):
        while True:
            name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
            if name not in used_names:
                used_names.add(name)
                break
        days_ago = random.randint(0, 730)
        joined = today - timedelta(days=days_ago)
        custs.append((
            i, name, joined.isoformat(),
            random.choice(regions),
            random.choice(products),
            random.choices(["active", "inactive", "churned"], weights=[70, 20, 10])[0],
            random.choice(channels),
        ))
    conn.executemany("INSERT INTO customers VALUES (?,?,?,?,?,?,?)", custs)

    cust_region = {c[0]: c[3] for c in custs}
    cust_ids    = [c[0] for c in custs]

    # ── Transactions (linked to customers) ────────────────────────────
    txns = []
    for i in range(1, 5001):
        cid = random.choice(cust_ids)
        days_ago = random.randint(0, 730)
        txn_date = today - timedelta(days=days_ago)
        txns.append((
            i, txn_date.isoformat(),
            round(random.uniform(500, 150_000), 2),
            cust_region[cid],
            random.choice(products),
            random.choice(channels),
            random.choices(["completed", "pending", "failed"], weights=[85, 10, 5])[0],
            cid,
        ))
    conn.executemany("INSERT INTO transactions VALUES (?,?,?,?,?,?,?,?)", txns)

    # ── Loans ─────────────────────────────────────────────────────────
    loans = []
    for i in range(1, 1001):
        days_ago = random.randint(0, 730)
        orig = today - timedelta(days=days_ago)
        loans.append((
            i, orig.isoformat(),
            round(random.uniform(5_000, 500_000), 2),
            random.choice(regions),
            random.choice(loan_prods),
            random.choices(["current", "delinquent", "defaulted", "paid_off"],
                           weights=[75, 10, 5, 10])[0],
        ))
    conn.executemany("INSERT INTO loans VALUES (?,?,?,?,?,?)", loans)

    # ── Metric Registry ────────────────────────────────────────────────
    metrics = [
        ("total_revenue",        "Total Revenue",
         "Sum of all completed transactions",
         "SUM(amount) WHERE status='completed'",
         "transactions", "region,product,channel,customer", 1, "Finance Team"),

        ("transaction_count",    "Transaction Count",
         "Count of all completed transactions",
         "COUNT(*) WHERE status='completed'",
         "transactions", "region,product,channel,customer", 1, "Finance Team"),

        ("average_transaction",  "Avg Transaction Value",
         "Average value of completed transactions",
         "AVG(amount) WHERE status='completed'",
         "transactions", "region,product,channel", 1, "Finance Team"),

        ("revenue_per_customer", "Revenue per Customer",
         "Total revenue per individual customer (joined with customers table)",
         "SUM(t.amount) GROUP BY c.name WHERE t.status='completed'",
         "transactions+customers", "region,product,channel", 1, "Finance Team"),

        ("active_customers",     "Active Customers",
         "Count of customers with active status",
         "COUNT(*) WHERE status='active'",
         "customers", "region,product,channel", 1, "Customer Team"),

        ("new_customers",        "New Customers",
         "Count of customers joined in period",
         "COUNT(*) by joined_date",
         "customers", "region,product,channel", 1, "Customer Team"),

        ("churn_rate",           "Churn Rate",
         "Percentage of churned customers",
         "COUNT(churned)/COUNT(*)*100",
         "customers", "region,product", 1, "Customer Team"),

        ("total_loan_value",     "Total Loan Value",
         "Sum of all loan originations",
         "SUM(amount)",
         "loans", "region,product", 1, "Credit Team"),

        ("delinquency_rate",     "Delinquency Rate",
         "Percentage of delinquent loans",
         "COUNT(delinquent)/COUNT(*)*100",
         "loans", "region,product", 1, "Credit Team"),

        ("loan_count",           "Loan Count",
         "Count of loan originations",
         "COUNT(*)",
         "loans", "region,product", 1, "Credit Team"),
    ]
    conn.executemany(
        """INSERT INTO metric_registry
           (metric_name, display_name, description, formula,
            source_table, allowed_dims, allowed_time, owner)
           VALUES (?,?,?,?,?,?,?,?)""",
        metrics,
    )
    conn.commit()
    print("✅ BankMetric DB seeded: 5000 transactions, 2000 customers, 1000 loans, 10 metrics")
