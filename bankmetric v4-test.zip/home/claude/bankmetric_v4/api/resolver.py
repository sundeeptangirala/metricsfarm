"""
BankMetric v4 — Pure resolver (no strawberry dependency)
Used by tests and by main.py directly.
graphql_api.py wraps this with strawberry for the GraphQL endpoint.
"""
from dataclasses import dataclass, field
from typing import Optional
import sqlite3

from db.database import get_connection
from parser.llm_parser import QueryObject, resolve_date_range

@dataclass
class MetricResult:
    dimension:       Optional[str] = None
    value:           float         = 0.0
    formatted_value: str           = ""

@dataclass
class MetricResponse:
    metric_name:     str       = ""
    display_name:    str       = ""
    time_range:      str       = ""
    date_from:       str       = ""
    date_to:         str       = ""
    group_by:        list      = field(default_factory=list)
    results:         list      = field(default_factory=list)
    total:           float     = 0.0
    formatted_total: str       = ""
    row_count:       int       = 0
    sql_generated:   str       = ""
    empty_note:      str       = ""

@dataclass
class ValidationError:
    code:       str = ""
    message:    str = ""
    suggestion: str = ""

@dataclass
class QueryResponse:
    success:  bool                     = False
    response: Optional[MetricResponse] = None
    error:    Optional[ValidationError] = None

METRIC_SQL = {
    "total_revenue":        {"select":"ROUND(SUM(t.amount),2)","table":"transactions t","base_join":"","dim_joins":{"customer":"JOIN customers c ON c.id=t.customer_id"},"date_col":"t.transaction_date","where":"t.status='completed'","display_name":"Total Revenue","format":"currency","dims":{"region":"t.region","product":"t.product","channel":"t.channel","customer":"c.name"},"force_group_by":[],"default_limit":None},
    "transaction_count":    {"select":"COUNT(*)","table":"transactions t","base_join":"","dim_joins":{"customer":"JOIN customers c ON c.id=t.customer_id"},"date_col":"t.transaction_date","where":"t.status='completed'","display_name":"Transaction Count","format":"integer","dims":{"region":"t.region","product":"t.product","channel":"t.channel","customer":"c.name"},"force_group_by":[],"default_limit":None},
    "average_transaction":  {"select":"ROUND(AVG(t.amount),2)","table":"transactions t","base_join":"","dim_joins":{},"date_col":"t.transaction_date","where":"t.status='completed'","display_name":"Avg Transaction Value","format":"currency","dims":{"region":"t.region","product":"t.product","channel":"t.channel"},"force_group_by":[],"default_limit":None},
    "revenue_per_customer": {"select":"ROUND(SUM(t.amount),2)","table":"transactions t","base_join":"JOIN customers c ON c.id=t.customer_id","dim_joins":{},"date_col":"t.transaction_date","where":"t.status='completed'","display_name":"Revenue per Customer","format":"currency","dims":{"customer":"c.name","region":"c.region","product":"t.product","channel":"t.channel"},"force_group_by":["customer"],"default_limit":20},
    "active_customers":     {"select":"COUNT(*)","table":"customers c","base_join":"","dim_joins":{},"date_col":"c.joined_date","where":"c.status='active'","display_name":"Active Customers","format":"integer","dims":{"region":"c.region","product":"c.product","channel":"c.channel"},"force_group_by":[],"default_limit":None},
    "new_customers":        {"select":"COUNT(*)","table":"customers c","base_join":"","dim_joins":{},"date_col":"c.joined_date","where":"1=1","display_name":"New Customers","format":"integer","dims":{"region":"c.region","product":"c.product","channel":"c.channel"},"force_group_by":[],"default_limit":None},
    "churn_rate":           {"select":"ROUND(CAST(SUM(CASE WHEN c.status='churned' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)","table":"customers c","base_join":"","dim_joins":{},"date_col":"c.joined_date","where":"1=1","display_name":"Churn Rate (%)","format":"percent","dims":{"region":"c.region","product":"c.product"},"force_group_by":[],"default_limit":None},
    "total_loan_value":     {"select":"ROUND(SUM(l.amount),2)","table":"loans l","base_join":"","dim_joins":{},"date_col":"l.origination_date","where":"1=1","display_name":"Total Loan Value","format":"currency","dims":{"region":"l.region","product":"l.product"},"force_group_by":[],"default_limit":None},
    "loan_count":           {"select":"COUNT(*)","table":"loans l","base_join":"","dim_joins":{},"date_col":"l.origination_date","where":"1=1","display_name":"Loan Count","format":"integer","dims":{"region":"l.region","product":"l.product"},"force_group_by":[],"default_limit":None},
    "delinquency_rate":     {"select":"ROUND(CAST(SUM(CASE WHEN l.status='delinquent' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)","table":"loans l","base_join":"","dim_joins":{},"date_col":"l.origination_date","where":"1=1","display_name":"Delinquency Rate (%)","format":"percent","dims":{"region":"l.region","product":"l.product"},"force_group_by":[],"default_limit":None},
}

def _fmt(v, fmt):
    if fmt=="currency": return (f"${v/1e6:.2f}M" if v>=1e6 else f"${v/1e3:.1f}K" if v>=1e3 else f"${v:,.2f}")
    return f"{v:.2f}%" if fmt=="percent" else f"{v:,.0f}"

def build_and_execute(query_obj: QueryObject) -> QueryResponse:
    conn = get_connection()
    if query_obj.metric not in METRIC_SQL:
        return QueryResponse(success=False, response=None,
            error=ValidationError(code="UNKNOWN_METRIC",
                message=f"Metric '{query_obj.metric}' is not defined.",
                suggestion=f"Available: {', '.join(METRIC_SQL.keys())}"))
    spec=METRIC_SQL[query_obj.metric]; allowed=spec["dims"]; fmt=spec["format"]
    user_gb=list(query_obj.group_by)
    effective_gb=user_gb if user_gb else list(spec["force_group_by"])
    user_limit=query_obj.filters.get("limit")
    effective_limit=(int(user_limit) if user_limit is not None
                     else (spec["default_limit"] if (not user_gb) and spec["default_limit"] else None))
    invalid=[d for d in effective_gb if d not in allowed]
    if invalid:
        return QueryResponse(success=False, response=None,
            error=ValidationError(code="INVALID_DIMENSION",
                message=f"'{query_obj.metric}' cannot be grouped by {invalid}.",
                suggestion=f"Available: {list(allowed.keys())}"))
    date_from,date_to=resolve_date_range(query_obj.time_range or "last_30_days")
    joins=set()
    if spec["base_join"]: joins.add(spec["base_join"])
    for d in effective_gb:
        if d in spec["dim_joins"]: joins.add(spec["dim_joins"][d])
    join_str=" ".join(joins)
    conditions=[spec["where"],f"{spec['date_col']} BETWEEN '{date_from}' AND '{date_to}'"]
    params=[]
    for col,val in query_obj.filters.items():
        if col in ("limit","order"): continue
        if col in allowed: conditions.append(f"{allowed[col]} = ?"); params.append(val)
    where=" AND ".join(f"({c})" for c in conditions)
    order=str(query_obj.filters.get("order","DESC")).upper()
    if order not in ("ASC","DESC"): order="DESC"
    group_exprs=[allowed[d] for d in effective_gb if d in allowed]
    if group_exprs:
        dim_label=(group_exprs[0] if len(group_exprs)==1 else " || ' / ' || ".join(group_exprs))
        sql=(f"SELECT {dim_label} AS dimension, {spec['select']} AS value "
             f"FROM {spec['table']} {join_str} WHERE {where} "
             f"GROUP BY {', '.join(group_exprs)} ORDER BY value {order}")
        if effective_limit: sql+=f" LIMIT {effective_limit}"
    else:
        sql=f"SELECT NULL AS dimension, {spec['select']} AS value FROM {spec['table']} {join_str} WHERE {where}"
    try:
        rows=conn.execute(sql,params).fetchall()
    except sqlite3.Error as e:
        return QueryResponse(success=False, response=None,
            error=ValidationError(code="SQL_ERROR", message=str(e),
                suggestion="Check metric definition."))
    empty_note=""
    if not rows:
        if query_obj.time_range in ("today","this_week"):
            empty_note=f"No data for '{query_obj.time_range}'. Demo data is historical — try 'last quarter' or 'last 30 days'."
        else:
            filt_desc=", ".join(f"{k}={v}" for k,v in query_obj.filters.items() if k not in ("limit","order") and v)
            empty_note=(f"No data found{' for '+filt_desc if filt_desc else ''} in {query_obj.time_range or 'last 30 days'}. Try a different time period or remove filters.")
    results=[MetricResult(dimension=r["dimension"],value=r["value"] or 0.0,
                          formatted_value=_fmt(r["value"] or 0.0,fmt)) for r in rows]
    total=sum(r.value for r in results)
    if fmt=="percent" and results: total=total/len(results)
    TIME_LABELS={"last_month":"Last Month","this_month":"This Month","last_quarter":"Last Quarter","this_quarter":"This Quarter","last_year":"Last Year","this_year":"This Year","year_to_date":"Year to Date","last_30_days":"Last 30 Days","last_90_days":"Last 90 Days","today":"Today","this_week":"This Week","last_week":"Last Week"}
    time_label=TIME_LABELS.get(query_obj.time_range or "",query_obj.time_range or "")
    return QueryResponse(success=True, error=None,
        response=MetricResponse(metric_name=query_obj.metric,display_name=spec["display_name"],
            time_range=time_label,date_from=date_from,date_to=date_to,group_by=effective_gb,
            results=results,total=total,formatted_total=_fmt(total,fmt),
            row_count=len(results),sql_generated=sql,empty_note=empty_note))
