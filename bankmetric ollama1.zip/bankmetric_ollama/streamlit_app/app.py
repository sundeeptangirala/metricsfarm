"""
BankMetric — Streamlit Chat UI  v3
Handles: data queries · UI commands · follow-ups · chart type switching
"""
import streamlit as st
import requests
import pandas as pd
import json

API_URL = "http://localhost:8000"

st.set_page_config(
    page_title="BankMetric",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.user-msg {
    background:#E8F4FD; border-left:4px solid #0A8F8F;
    padding:12px 16px; border-radius:0 10px 10px 0; margin:8px 0; font-size:15px;
}
.bot-header {
    background:#F8F9FA; border-left:4px solid #6C757D;
    padding:12px 16px; border-radius:0 10px 10px 0; margin:8px 0 4px 0;
}
.ui-msg {
    background:#FFF8E8; border-left:4px solid #BA7517;
    padding:10px 16px; border-radius:0 10px 10px 0; margin:8px 0; font-size:14px;
    color:#633806;
}
.error-msg {
    background:#FFF3F3; border-left:4px solid #DC3545;
    padding:12px 16px; border-radius:0 10px 10px 0; margin:8px 0;
}
.metric-total { font-size:30px; font-weight:700; color:#0A8F8F; }
.metric-label { font-size:12px; color:#6B7D99; text-transform:uppercase; letter-spacing:0.5px; }
.pill-llm  { background:#E1F5EE; color:#085041; padding:2px 8px; border-radius:12px; font-size:11px; font-weight:600; }
.pill-rule { background:#FAEEDA; color:#633806; padding:2px 8px; border-radius:12px; font-size:11px; font-weight:600; }
.pill-conf { background:#E6F1FB; color:#0C447C; padding:2px 8px; border-radius:12px; font-size:11px; }
</style>
""", unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────────
for k, v in [("messages",[]), ("context",[]), ("metrics_list",[]),
              ("last_data", None), ("last_chart_type","bar")]:
    if k not in st.session_state:
        st.session_state[k] = v


# ── API helpers ────────────────────────────────────────────────────────────────
def ask_api(question: str) -> dict:
    try:
        return requests.post(f"{API_URL}/ask",
            json={"question": question,
                  "conversation_context": st.session_state.context},
            timeout=35).json()
    except requests.exceptions.Timeout:
        return {"success": False, "error": "Ollama is still loading — wait a few seconds and retry.",
                "suggestion": ""}
    except requests.exceptions.ConnectionError:
        return {"success": False, "error": "Cannot connect to BankMetric API.",
                "suggestion": "Run: python main.py"}
    except Exception as e:
        return {"success": False, "error": str(e), "suggestion": ""}

def load_metrics():
    try:   return requests.get(f"{API_URL}/metrics", timeout=5).json()
    except: return []


# ── UI command handler ─────────────────────────────────────────────────────────
CHART_ACTIONS = {"chart_line", "chart_bar", "chart_change"}

def handle_ui_command(action: str, question: str) -> str:
    """Handle UI commands without hitting the data API."""
    if action in CHART_ACTIONS:
        if "line" in question.lower():
            st.session_state.last_chart_type = "line"
            return "Chart type changed to line. The data above is now shown as a line chart."
        elif "bar" in question.lower():
            st.session_state.last_chart_type = "bar"
            return "Chart type changed to bar. The data above is now shown as a bar chart."
        else:
            return "I can switch between bar and line charts. Try: 'convert to line chart' or 'convert to bar chart'."
    if action == "export":
        return "Export is not yet available in this prototype. It will be added in Phase 2."
    if action == "clear":
        st.session_state.messages  = []
        st.session_state.context   = []
        st.session_state.last_data = None
        return "__clear__"
    if action == "explain":
        return ("I answer questions about banking metrics like revenue, customers, loans, "
                "churn rate, and delinquency. Try: 'show revenue by region last quarter' "
                "or 'top 10 customers by revenue'.")
    return f"I understood this as a '{action}' command. Try rephrasing as a data question."


# ── Render a metric result card ────────────────────────────────────────────────
def render_response(data: dict, chart_type: str = "bar"):
    if not data.get("success"):
        st.markdown(f"""
        <div class="error-msg">
            ❌ <strong>{data.get('error','Unknown error')}</strong><br>
            <small>{data.get('suggestion','')}</small>
        </div>""", unsafe_allow_html=True)
        return

    results  = data.get("results", [])
    group_by = data.get("group_by", [])
    has_dims = bool(group_by) and results and results[0].get("dimension")
    glabel   = " × ".join(group_by) if group_by else "Total"

    parser = data.get("parser_used","llm")
    conf   = data.get("query_object",{}).get("confidence",1.0)
    pbadge = (f'<span class="pill-llm">LLM</span> '
              f'<span class="pill-conf">{int(conf*100)}% confidence</span>'
              if parser == "llm" else '<span class="pill-rule">Rule-based fallback</span>')

    st.markdown(f"""
    <div class="bot-header">
        <div style="margin-bottom:4px">{pbadge}</div>
        <span class="metric-label">{data.get('display_name','')} · {data.get('time_range','')}
        &nbsp;|&nbsp; {data.get('date_from','')} → {data.get('date_to','')}</span><br>
        <span class="metric-total">{data.get('formatted_total','')}</span>
        <span style="font-size:12px;color:#9CA3AF;margin-left:12px">
            {data.get('row_count',0)} {'rows' if has_dims else 'result'} · by {glabel}
        </span>
    </div>""", unsafe_allow_html=True)

    if has_dims and results:
        df = pd.DataFrame(results)[["dimension","value","formatted_value"]]
        df.columns = [glabel.title(), "Value", data.get("display_name","Value")]
        df = df.sort_values("Value", ascending=False)

        c1, c2 = st.columns([1,1])
        with c1:
            st.dataframe(df[[glabel.title(), data.get("display_name","Value")]],
                         use_container_width=True, hide_index=True)
        with c2:
            chart_df = df.set_index(glabel.title())[["Value"]]
            chart_df.columns = [data.get("display_name","Value")]
            if chart_type == "line":
                st.line_chart(chart_df, height=260)
            else:
                st.bar_chart(chart_df, height=260)

    with st.expander("🔍 Query details — what the LLM understood", expanded=False):
        qo = data.get("query_object",{})
        c1,c2,c3,c4 = st.columns(4)
        c1.markdown(f"**Metric**\n`{qo.get('metric','')}`")
        c2.markdown(f"**Time**\n`{qo.get('time_range','')}`")
        c3.markdown(f"**Group by**\n`{', '.join(qo.get('group_by',[])) or 'none'}`")
        c4.markdown(f"**Filters**\n`{json.dumps(qo.get('filters',{}))}`")
        if data.get("sql_generated"):
            st.code(data["sql_generated"], language="sql")


# ── Follow-up suggestion chips ─────────────────────────────────────────────────
def render_suggestions(data: dict):
    if not data.get("success"): return
    metric   = data.get("metric","")
    group_by = data.get("group_by",[])
    sugg     = []

    if "customer" not in group_by and metric not in ("active_customers","new_customers","churn_rate"):
        sugg.append("Show top 10 customers by revenue")
    if "region"  not in group_by: sugg.append("Break it down by region")
    if "product" not in group_by: sugg.append("Break it down by product")
    if "channel" not in group_by: sugg.append("Which channel is most used?")

    tr = data.get("time_range","")
    if   "Quarter" in tr: sugg.append("What about this quarter?")
    elif "Month"   in tr: sugg.append("What about last quarter?")
    else:                 sugg.append("Show me last quarter")

    if metric == "total_revenue":
        sugg.append("Show transaction count")
    elif metric in ("total_loan_value","loan_count"):
        sugg.append("Show delinquency rate")
    elif metric == "active_customers":
        sugg.append("What is the churn rate?")

    sugg = sugg[:4]
    if sugg:
        st.markdown("**💡 Follow-up:**")
        cols = st.columns(len(sugg))
        for i, s in enumerate(sugg):
            if cols[i].button(s, key=f"s_{len(st.session_state.messages)}_{i}"):
                handle_question(s); st.rerun()


# ── Main question handler ──────────────────────────────────────────────────────
def handle_question(question: str):
    st.session_state.messages.append({"role":"user","content":question})

    # Check if it's a UI command first (same logic as server, for instant response)
    from parser.llm_parser import classify_intent
    lower  = question.lower().strip()
    intent, ui_action = classify_intent(lower)

    if intent == "ui_command":
        result = handle_ui_command(ui_action, question)
        if result == "__clear__":
            st.rerun()
            return
        st.session_state.messages.append({
            "role":"assistant","content":question,
            "type":"ui_msg","text":result
        })
        return

    # Data query
    with st.spinner("🧠 Thinking..."):
        data = ask_api(question)

    st.session_state.messages.append({
        "role":"assistant","content":question,
        "type":"data","data":data,
        "chart_type": st.session_state.last_chart_type,
    })

    if data.get("success"):
        st.session_state.last_data = data
        # Reset chart type to bar for new queries
        st.session_state.last_chart_type = "bar"
        st.session_state.context.append({
            "metric":     data.get("metric"),
            "time_range": data.get("query_object",{}).get("time_range"),
            "filters":    {k:v for k,v in data.get("query_object",{}).get("filters",{}).items()
                           if k != "limit"},  # don't carry limit forward
            "group_by":   data.get("group_by",[]),
        })
        st.session_state.context = st.session_state.context[-5:]


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("📊 BankMetric")
    st.caption("Conversational Analytics · Ollama LLM")
    st.divider()

    try:
        health = requests.get(f"{API_URL}/health", timeout=3).json()
        st.success("✅ API connected")
        counts = health.get("counts",{})
        st.markdown(f"""
**Data:**
- 📊 {counts.get('transactions',0):,} transactions
- 👥 {counts.get('customers',0):,} customers
- 🏦 {counts.get('loans',0):,} loans""")

        ollama = health.get("ollama",{})
        st.divider()
        st.markdown("**🧠 Ollama LLM**")
        if ollama.get("running") and ollama.get("model_available"):
            st.success(f"✅ Ready — `{ollama.get('target_model')}`")
        elif ollama.get("running"):
            st.warning("⚠️ Running — model not pulled")
            st.code(f"ollama pull {ollama.get('target_model','llama3.2:3b')}")
        else:
            st.error("❌ Ollama not running")
            st.markdown("```\nollama serve\n```")
    except:
        st.error("❌ API not reachable\n\nRun: `python main.py`")

    st.divider()
    st.markdown("**What you can ask:**")
    st.markdown("""
- Revenue, customers, loans, churn, delinquency
- By region, product, channel, or customer
- Any time period: last quarter, this year, etc.
- Follow-ups: "break that down by region"
- Chart type: "convert to line chart"
    """)

    st.divider()
    st.markdown("**📐 Governed metrics**")
    if not st.session_state.metrics_list:
        st.session_state.metrics_list = load_metrics()
    for m in st.session_state.metrics_list:
        with st.expander(m.get("display_name","")):
            st.caption(m.get("description",""))
            st.code(m.get("formula",""), language="sql")
            st.caption(f"📁 {m.get('source_table')} · 👤 {m.get('owner')}")

    st.divider()
    if st.button("🗑 Clear conversation"):
        st.session_state.messages  = []
        st.session_state.context   = []
        st.session_state.last_data = None
        st.session_state.last_chart_type = "bar"
        st.rerun()


# ── Main area ──────────────────────────────────────────────────────────────────
st.markdown("## 💬 Ask anything about your metrics")
st.caption("Powered by local Ollama LLM · No data leaves your machine")

if not st.session_state.messages:
    st.markdown("**Try asking:**")
    examples = [
        "Show me top 5 customers by revenue",
        "Revenue by region last quarter",
        "Which channel is most used?",
        "Top 3 products by loan value",
        "Active customers by region this month",
        "What is our delinquency rate by product?",
        "Churn rate by region last year",
        "New customers last quarter",
    ]
    cols = st.columns(3)
    for i, q in enumerate(examples):
        if cols[i%3].button(q, key=f"ex_{i}", use_container_width=True):
            handle_question(q); st.rerun()
    st.divider()

# Chat history
for i, msg in enumerate(st.session_state.messages):
    if msg["role"] == "user":
        st.markdown(f'<div class="user-msg">👤 <strong>You:</strong> {msg["content"]}</div>',
                    unsafe_allow_html=True)
    else:
        msg_type = msg.get("type","data")
        if msg_type == "ui_msg":
            st.markdown(f'<div class="ui-msg">💡 {msg["text"]}</div>',
                        unsafe_allow_html=True)
            # If chart type changed, re-render last data message with new type
            if "chart" in msg.get("text","").lower():
                # Find the last data message and re-render it
                for prev in reversed(st.session_state.messages[:i]):
                    if prev.get("type","data") == "data" and prev.get("data",{}).get("success"):
                        st.markdown("**📊 BankMetric:** *(chart updated)*")
                        render_response(prev["data"],
                                        st.session_state.last_chart_type)
                        break
        else:
            st.markdown("**📊 BankMetric:**")
            chart_type = msg.get("chart_type",
                                  st.session_state.last_chart_type
                                  if i == len(st.session_state.messages)-1
                                  else "bar")
            render_response(msg.get("data",{}), chart_type)
            if i == len(st.session_state.messages)-1:
                render_suggestions(msg.get("data",{}))

# Input
st.divider()
with st.form(key="chat_form", clear_on_submit=True):
    c1, c2 = st.columns([5,1])
    with c1:
        user_input = st.text_input("Ask anything...",
            placeholder="e.g. Show top 5 customers by revenue in North America",
            label_visibility="collapsed")
    with c2:
        submitted = st.form_submit_button("Ask →", use_container_width=True)
    if submitted and user_input.strip():
        handle_question(user_input.strip()); st.rerun()
