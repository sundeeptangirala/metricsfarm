"""
BankMetric v5 — Database

100 metrics across 7 subject areas.
Metric registry is the single source of truth.
"""
import sqlite3
import json
import random
from datetime import date, timedelta

_conn = None

def get_connection() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(":memory:", check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _create_schema(_conn)
        _seed_registry(_conn)
        _seed_data(_conn)
        print("✅ BankMetric v5 DB ready — 100 metrics loaded")
    return _conn


def _create_schema(conn):
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS metric_registry (
        metric_id           TEXT PRIMARY KEY,
        display_name        TEXT NOT NULL,
        description         TEXT NOT NULL,
        long_description    TEXT,
        business_questions  TEXT,
        category            TEXT,
        tags                TEXT,
        business_owner      TEXT,
        data_steward        TEXT,
        tier                INTEGER DEFAULT 3,
        status              TEXT DEFAULT 'published',
        version             INTEGER DEFAULT 1,
        select_expression   TEXT NOT NULL,
        is_ratio            INTEGER DEFAULT 0,
        numerator_expr      TEXT,
        denominator_expr    TEXT,
        primary_table       TEXT NOT NULL,
        primary_alias       TEXT NOT NULL,
        base_filter         TEXT DEFAULT '1=1',
        date_column         TEXT NOT NULL,
        base_joins          TEXT DEFAULT '[]',
        allowed_dimensions  TEXT NOT NULL,
        dimension_joins     TEXT DEFAULT '{}',
        force_group_by      TEXT DEFAULT '[]',
        default_limit       INTEGER,
        default_sort        TEXT DEFAULT 'DESC',
        format_type         TEXT DEFAULT 'number',
        unit                TEXT,
        created_at          TEXT DEFAULT (datetime('now')),
        updated_at          TEXT DEFAULT (datetime('now')),
        validated_at        TEXT
    );

    CREATE TABLE IF NOT EXISTS dimension_registry (
        dimension_id    TEXT PRIMARY KEY,
        display_name    TEXT NOT NULL,
        description     TEXT,
        example_values  TEXT
    );

    CREATE TABLE IF NOT EXISTS time_range_registry (
        time_range_id   TEXT PRIMARY KEY,
        display_name    TEXT NOT NULL,
        description     TEXT,
        aliases         TEXT
    );

    CREATE TABLE IF NOT EXISTS query_audit (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id      TEXT,
        user_upn        TEXT DEFAULT 'local',
        question        TEXT NOT NULL,
        metric_id       TEXT,
        time_range      TEXT,
        group_by        TEXT,
        filters         TEXT,
        aggregation     TEXT,
        feasible        INTEGER,
        row_count       INTEGER,
        response_time   REAL,
        stage_used      TEXT,
        queried_at      TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id     INTEGER,
        amount          REAL,
        region          TEXT,
        product         TEXT,
        channel         TEXT,
        status          TEXT,
        transaction_date TEXT,
        transaction_type TEXT
    );

    CREATE TABLE IF NOT EXISTS customers (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        name            TEXT,
        region          TEXT,
        product         TEXT,
        channel         TEXT,
        status          TEXT,
        segment         TEXT,
        joined_date     TEXT,
        digital_active  INTEGER DEFAULT 0,
        mobile_active   INTEGER DEFAULT 0,
        products_held   INTEGER DEFAULT 1,
        nps_score       INTEGER
    );

    CREATE TABLE IF NOT EXISTS loans (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id      INTEGER,
        amount           REAL,
        region           TEXT,
        product          TEXT,
        status           TEXT,
        origination_date TEXT,
        maturity_date    TEXT,
        interest_rate    REAL
    );

    CREATE TABLE IF NOT EXISTS deposits (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id      INTEGER,
        amount           REAL,
        region           TEXT,
        product          TEXT,
        deposit_type     TEXT,
        status           TEXT,
        opened_date      TEXT
    );

    CREATE TABLE IF NOT EXISTS complaints (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id     INTEGER,
        region          TEXT,
        channel         TEXT,
        product         TEXT,
        status          TEXT,
        resolved        INTEGER DEFAULT 0,
        filed_date      TEXT,
        resolved_date   TEXT
    );

    CREATE TABLE IF NOT EXISTS fraud_events (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        transaction_id  INTEGER,
        region          TEXT,
        product         TEXT,
        channel         TEXT,
        confirmed       INTEGER DEFAULT 0,
        amount          REAL,
        detected_date   TEXT
    );
    """)
    conn.commit()


def _m(metric_id, display_name, description, long_description,
        business_questions, category, tags, business_owner, data_steward,
        tier, status, select_expression, is_ratio,
        primary_table, primary_alias, base_filter, date_column,
        base_joins, allowed_dimensions, dimension_joins,
        force_group_by, default_limit, default_sort,
        format_type, unit,
        numerator_expr=None, denominator_expr=None):
    return {
        "metric_id": metric_id, "display_name": display_name,
        "description": description, "long_description": long_description,
        "business_questions": json.dumps(business_questions),
        "category": category, "tags": json.dumps(tags),
        "business_owner": business_owner, "data_steward": data_steward,
        "tier": tier, "status": status,
        "select_expression": select_expression, "is_ratio": is_ratio,
        "numerator_expr": numerator_expr, "denominator_expr": denominator_expr,
        "primary_table": primary_table, "primary_alias": primary_alias,
        "base_filter": base_filter, "date_column": date_column,
        "base_joins": json.dumps(base_joins),
        "allowed_dimensions": json.dumps(allowed_dimensions),
        "dimension_joins": json.dumps(dimension_joins),
        "force_group_by": json.dumps(force_group_by),
        "default_limit": default_limit, "default_sort": default_sort,
        "format_type": format_type, "unit": unit,
    }

# Shared dimension sets
TXN_DIMS  = {"region":"t.region","product":"t.product","channel":"t.channel","customer":"c.name"}
TXN_DJOIN = {"customer":"JOIN customers c ON c.id=t.customer_id"}
CUST_DIMS = {"region":"c.region","product":"c.product","channel":"c.channel"}
LOAN_DIMS = {"region":"l.region","product":"l.product"}
DEP_DIMS  = {"region":"d.region","product":"d.product","deposit_type":"d.deposit_type"}
COMP_DIMS = {"region":"cp.region","product":"cp.product","channel":"cp.channel"}
FRAU_DIMS = {"region":"f.region","product":"f.product","channel":"f.channel"}

def _seed_registry(conn):
    METRICS = [

    # ═══════════════════════════════════════════════════════════════
    # 1. REVENUE & INCOME (15)
    # ═══════════════════════════════════════════════════════════════
    _m("total_revenue","Total Revenue",
       "Sum of all completed transaction amounts within the period.",
       "Total Revenue is the gross value of all successfully completed financial transactions. Excludes pending, failed, and reversed transactions. Primary revenue indicator across all business lines.",
       ["What was our revenue last quarter?","Show revenue by region","Which product generates the most revenue?","How does revenue compare to last year?"],
       "revenue",["revenue","income","sales"],"CFO Office","Finance Data Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='completed'","t.transaction_date",
       [],"{"+ '"region":"t.region","product":"t.product","channel":"t.channel","customer":"c.name"'+"}",
       {"customer":"JOIN customers c ON c.id=t.customer_id"},[],None,"DESC","currency","USD"),

    _m("transaction_count","Transaction Count",
       "Number of completed transactions within the period.",
       "Measures volume of successfully processed transactions. Useful for channel usage, product popularity, and frequency analysis.",
       ["How many transactions did we process?","Which channel is most used?","Transaction volume by product","Volume month over month"],
       "revenue",["volume","count","transactions"],"Operations","Finance Data Team",3,"published",
       "COUNT(*)",0,"transactions","t","t.status='completed'","t.transaction_date",
       [],TXN_DIMS,TXN_DJOIN,[],None,"DESC","integer","count"),

    _m("average_transaction","Average Transaction Value",
       "Average value of completed transactions within the period.",
       "Average Transaction Value (ATV) measures the mean monetary value per transaction. Sensitive to outliers — consider alongside distribution analysis.",
       ["What is the average transaction value?","Which product has the highest average transaction?","Average transaction by region"],
       "revenue",["average","atv"],"CFO Office","Finance Data Team",3,"published",
       "ROUND(AVG(t.amount),2)",0,"transactions","t","t.status='completed'","t.transaction_date",
       [],{"region":"t.region","product":"t.product","channel":"t.channel"},{},
       [],None,"DESC","currency","USD"),

    _m("revenue_per_customer","Revenue per Customer",
       "Total revenue attributed to each individual customer, ranked highest to lowest.",
       "Ranks customers by total transaction value. Used for high-value customer identification and relationship management.",
       ["Who are our top 10 customers?","Most valuable customers in North America","Top 5 customers this quarter"],
       "revenue",["customers","ranking","top"],"Retail Banking","CRM Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='completed'","t.transaction_date",
       [{"alias":"c","sql":"JOIN customers c ON c.id=t.customer_id"}],
       {"customer":"c.name","region":"c.region","product":"t.product","channel":"t.channel"},
       {},["customer"],20,"DESC","currency","USD"),

    _m("fee_income","Fee Income",
       "Total fee-based income from charges and service fees within the period.",
       "Fee Income captures non-interest revenue from account fees, transaction fees, advisory fees, and service charges. Growing fee income indicates diversified revenue streams.",
       ["What is our fee income this quarter?","Show fee income by product","Which region generates the most fees?"],
       "revenue",["fees","income","non-interest"],"CFO Office","Finance Data Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='completed' AND t.transaction_type='fee'","t.transaction_date",
       [],{"region":"t.region","product":"t.product","channel":"t.channel"},{},
       [],None,"DESC","currency","USD"),

    _m("digital_revenue","Digital Channel Revenue",
       "Revenue generated through digital channels (online and mobile).",
       "Measures the monetary value of transactions conducted through digital channels. Key indicator of digital transformation progress.",
       ["What percentage of revenue is digital?","Show digital revenue by region","Digital vs branch revenue"],
       "revenue",["digital","online","mobile"],"Digital Banking","Finance Data Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='completed' AND t.channel IN ('Online','Mobile')","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},
       [],None,"DESC","currency","USD"),

    _m("revenue_per_branch","Revenue per Branch",
       "Average revenue attributed to each branch channel transaction.",
       "Measures branch productivity and contribution to overall revenue. Used for branch network optimisation decisions.",
       ["How much revenue does the branch channel generate?","Branch revenue by region","Branch vs digital revenue"],
       "revenue",["branch","productivity"],"Retail Banking","Finance Data Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='completed' AND t.channel='Branch'","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},
       [],None,"DESC","currency","USD"),

    _m("cross_sell_revenue","Cross-sell Revenue",
       "Revenue from customers holding more than one product.",
       "Measures the effectiveness of cross-selling strategy. Customers with multiple products typically have higher lifetime value and lower churn.",
       ["How much revenue comes from multi-product customers?","Cross-sell revenue by region","Which product combinations generate most revenue?"],
       "revenue",["cross-sell","multi-product"],"Retail Banking","CRM Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t",
       "t.status='completed' AND EXISTS (SELECT 1 FROM customers cx WHERE cx.id=t.customer_id AND cx.products_held>1)",
       "t.transaction_date",[],{"region":"t.region","product":"t.product"},{},
       [],None,"DESC","currency","USD"),

    _m("refund_amount","Refund Amount",
       "Total value of refunded transactions within the period.",
       "Tracks the monetary value of refunds issued. High refund rates may indicate service quality issues or fraud. Compare to total revenue for refund rate calculation.",
       ["How much did we refund this month?","Refunds by product","Which region has the most refunds?"],
       "revenue",["refunds","reversals"],"Operations","Finance Data Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='refunded'","t.transaction_date",
       [],{"region":"t.region","product":"t.product","channel":"t.channel"},{},
       [],None,"DESC","currency","USD"),

    _m("mobile_transaction_count","Mobile Transaction Count",
       "Number of transactions completed via mobile channel.",
       "Measures mobile channel adoption and usage. Key indicator of mobile banking maturity and customer preference for self-service.",
       ["How many mobile transactions did we process?","Mobile vs online transaction volume","Mobile transactions by region"],
       "revenue",["mobile","digital","channel"],"Digital Banking","Operations",3,"published",
       "COUNT(*)",0,"transactions","t","t.status='completed' AND t.channel='Mobile'","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},
       [],None,"DESC","integer","count"),

    _m("online_transaction_count","Online Transaction Count",
       "Number of transactions completed via online banking channel.",
       "Measures online banking adoption and usage volume. Together with mobile count, gives total digital transaction volume.",
       ["How many online transactions this month?","Online vs mobile usage","Online transactions by product"],
       "revenue",["online","digital","channel"],"Digital Banking","Operations",3,"published",
       "COUNT(*)",0,"transactions","t","t.status='completed' AND t.channel='Online'","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},
       [],None,"DESC","integer","count"),

    _m("branch_transaction_count","Branch Transaction Count",
       "Number of transactions completed via branch channel.",
       "Measures branch channel usage. Declining branch counts alongside rising digital counts indicates successful channel migration.",
       ["How many branch transactions this quarter?","Branch usage by region","Branch vs digital transaction volume"],
       "revenue",["branch","channel"],"Retail Banking","Operations",3,"published",
       "COUNT(*)",0,"transactions","t","t.status='completed' AND t.channel='Branch'","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},
       [],None,"DESC","integer","count"),

    _m("failed_transaction_count","Failed Transaction Count",
       "Number of transactions that failed to complete within the period.",
       "Tracks transaction failure volume. High failure rates indicate technical issues, fraud, or customer experience problems requiring investigation.",
       ["How many transactions failed this month?","Failed transactions by channel","Which product has the most failures?"],
       "revenue",["failed","errors","quality"],"Operations","Finance Data Team",3,"published",
       "COUNT(*)",0,"transactions","t","t.status='failed'","t.transaction_date",
       [],{"region":"t.region","product":"t.product","channel":"t.channel"},{},
       [],None,"DESC","integer","count"),

    _m("average_daily_transactions","Average Daily Transactions",
       "Average number of completed transactions per calendar day in the period.",
       "Normalises transaction volume by the number of days in the period, enabling fair comparison across periods of different lengths.",
       ["What is our daily transaction run rate?","Average daily volume by channel","Daily transaction rate by product"],
       "revenue",["daily","volume","average"],"Operations","Finance Data Team",3,"published",
       "ROUND(CAST(COUNT(*) AS FLOAT) / MAX(1, (julianday(MAX(t.transaction_date)) - julianday(MIN(t.transaction_date)) + 1)), 1)",
       0,"transactions","t","t.status='completed'","t.transaction_date",
       [],{"region":"t.region","channel":"t.channel"},{},
       [],None,"DESC","decimal","txns/day"),

    _m("peak_transaction_value","Highest Single Transaction",
       "The maximum value of any single completed transaction in the period.",
       "Identifies the largest individual transaction. Useful for limit monitoring, fraud detection, and understanding transaction size distribution.",
       ["What was our largest transaction this month?","Highest transaction by product","Biggest transaction in each region"],
       "revenue",["maximum","peak","single"],"Risk","Finance Data Team",3,"published",
       "ROUND(MAX(t.amount),2)",0,"transactions","t","t.status='completed'","t.transaction_date",
       [],{"region":"t.region","product":"t.product","channel":"t.channel"},{},
       [],None,"DESC","currency","USD"),

    # ═══════════════════════════════════════════════════════════════
    # 2. CUSTOMERS (15)
    # ═══════════════════════════════════════════════════════════════
    _m("active_customers","Active Customers",
       "Count of customers with active status who joined within the period.",
       "Active Customers counts customers currently holding active accounts. Use alongside New Customers and Churn Rate for complete lifecycle analysis.",
       ["How many active customers do we have?","Active customers by region","Which product has the most active customers?"],
       "customers",["active","count"],"Retail Banking","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.status='active'","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","integer","count"),

    _m("new_customers","New Customers",
       "Count of customers who joined within the selected period.",
       "Measures customer acquisition. Key metric for growth tracking and marketing effectiveness.",
       ["How many new customers did we acquire?","New customers by region","Are we growing our customer base?"],
       "customers",["acquisition","new","growth"],"Retail Banking","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","1=1","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","integer","count"),

    _m("churn_rate","Churn Rate",
       "Percentage of customers who have churned out of total customers.",
       "Churn Rate measures the proportion of customers who have closed or abandoned their accounts. Lower is better. Industry benchmark: 10-15% annually.",
       ["What is our churn rate?","Which region has the highest churn?","Is our churn rate improving?"],
       "customers",["churn","attrition","retention"],"Retail Banking","CRM Team",3,"published",
       "ROUND(CAST(SUM(CASE WHEN c.status='churned' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"customers","c","1=1","c.joined_date",
       [],{"region":"c.region","product":"c.product"},{},[],None,"DESC","percent","%"),

    _m("customer_retention_rate","Customer Retention Rate",
       "Percentage of customers retained (not churned) out of total customers.",
       "The inverse of churn rate. Shows the proportion of customers who remain active. Higher is better. Target: above 90%.",
       ["What is our retention rate?","Retention by region","How well are we retaining customers?"],
       "customers",["retention","churn","loyalty"],"Retail Banking","CRM Team",3,"published",
       "ROUND(CAST(SUM(CASE WHEN c.status='active' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"customers","c","1=1","c.joined_date",
       [],{"region":"c.region","product":"c.product"},{},[],None,"DESC","percent","%"),

    _m("dormant_customers","Dormant Customers",
       "Count of customers with inactive or dormant status.",
       "Dormant customers represent a re-engagement opportunity. High dormancy rates may indicate product-market fit issues or competitive pressure.",
       ["How many dormant customers do we have?","Dormant customers by region","Which product has the most dormant accounts?"],
       "customers",["dormant","inactive"],"Retail Banking","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.status='inactive'","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","integer","count"),

    _m("digital_customers","Digital Active Customers",
       "Count of customers actively using digital channels (online or mobile).",
       "Measures digital banking adoption. Customers using digital channels typically have lower service costs and higher retention.",
       ["How many customers use digital banking?","Digital adoption by region","Digital customers by product"],
       "customers",["digital","online","mobile","adoption"],"Digital Banking","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.digital_active=1","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","integer","count"),

    _m("mobile_customers","Mobile Active Customers",
       "Count of customers actively using the mobile banking app.",
       "Specifically tracks mobile app adoption, distinct from overall digital usage. Key metric for mobile strategy effectiveness.",
       ["How many customers use mobile banking?","Mobile adoption rate by region","Mobile customers by product"],
       "customers",["mobile","app","adoption"],"Digital Banking","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.mobile_active=1","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","integer","count"),

    _m("multi_product_customers","Multi-Product Customers",
       "Count of customers holding more than one product.",
       "Measures cross-sell penetration. Multi-product customers have significantly higher lifetime value and lower churn rates.",
       ["How many customers have multiple products?","Multi-product rate by region","Which regions have the best cross-sell?"],
       "customers",["cross-sell","multi-product","penetration"],"Retail Banking","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.products_held>1","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","integer","count"),

    _m("average_products_per_customer","Average Products per Customer",
       "Average number of products held per customer.",
       "Key cross-sell metric. Higher values indicate better product penetration and deeper customer relationships.",
       ["What is our average products per customer?","Products per customer by region","Are we improving cross-sell?"],
       "customers",["cross-sell","depth","penetration"],"Retail Banking","CRM Team",3,"published",
       "ROUND(AVG(c.products_held),2)",0,"customers","c","c.status='active'","c.joined_date",
       [],{"region":"c.region","product":"c.product"},{},[],None,"DESC","decimal","products"),

    _m("average_nps","Average NPS Score",
       "Average Net Promoter Score across customers who have provided scores.",
       "NPS measures customer loyalty. Scores range from -100 to 100. Above 50 is excellent. Below 0 requires urgent attention.",
       ["What is our NPS score?","NPS by region","Which product has the best NPS?","Is our NPS improving?"],
       "customers",["nps","satisfaction","loyalty"],"Customer Experience","CRM Team",3,"published",
       "ROUND(AVG(c.nps_score),1)",0,"customers","c","c.nps_score IS NOT NULL","c.joined_date",
       [],{"region":"c.region","product":"c.product"},{},[],None,"DESC","decimal","score"),

    _m("promoter_count","Promoter Count (NPS)",
       "Count of customers who are promoters (NPS score 9-10).",
       "Promoters are highly satisfied customers likely to recommend the bank. Growing promoter count indicates strong customer advocacy.",
       ["How many promoters do we have?","Promoters by region","Which product drives the most promoters?"],
       "customers",["nps","promoters","advocacy"],"Customer Experience","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.nps_score>=9","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","integer","count"),

    _m("detractor_count","Detractor Count (NPS)",
       "Count of customers who are detractors (NPS score 0-6).",
       "Detractors are dissatisfied customers at risk of churning and may actively discourage others. Requires immediate attention.",
       ["How many detractors do we have?","Detractors by region","Which product has the most detractors?"],
       "customers",["nps","detractors","risk"],"Customer Experience","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.nps_score<=6","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","integer","count"),

    _m("segment_retail_count","Retail Segment Customers",
       "Count of customers in the retail banking segment.",
       "Retail segment customers are individual consumers. Tracking by segment allows targeted product and service strategies.",
       ["How many retail customers do we have?","Retail customers by region","Retail segment growth"],
       "customers",["segment","retail"],"Retail Banking","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.segment='retail' AND c.status='active'","c.joined_date",
       [],{"region":"c.region","product":"c.product"},{},[],None,"DESC","integer","count"),

    _m("segment_business_count","Business Segment Customers",
       "Count of customers in the business banking segment.",
       "Business segment customers are SMEs and corporate clients. Typically higher value per customer but smaller volumes.",
       ["How many business customers do we have?","Business segment by region","Business customer growth"],
       "customers",["segment","business","sme"],"Business Banking","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.segment='business' AND c.status='active'","c.joined_date",
       [],{"region":"c.region","product":"c.product"},{},[],None,"DESC","integer","count"),

    _m("customer_lifetime_value","Customer Lifetime Value",
       "Average total revenue per customer over their relationship with the bank.",
       "CLV estimates the total revenue a customer will generate. Higher CLV justifies higher acquisition investment and personalised service.",
       ["What is our average customer lifetime value?","CLV by region","Which segment has highest CLV?"],
       "customers",["clv","lifetime","value"],"Strategy","Finance Data Team",3,"published",
       "ROUND(AVG(cx.total_rev),2)",0,
       "(SELECT customer_id, SUM(amount) AS total_rev FROM transactions WHERE status='completed' GROUP BY customer_id)","cx",
       "1=1","(SELECT joined_date FROM customers WHERE id=cx.customer_id LIMIT 1)",
       [],"{}",{},[],None,"DESC","currency","USD"),

    # ═══════════════════════════════════════════════════════════════
    # 3. LOANS & CREDIT (20)
    # ═══════════════════════════════════════════════════════════════
    _m("total_loan_value","Total Loan Value",
       "Sum of all loan origination amounts within the period.",
       "Total Loan Value represents gross value of loans originated. Measures lending activity and portfolio growth.",
       ["What is our total loan book?","Loan value by product","Which region has most lending?"],
       "loans",["loans","lending","portfolio"],"Lending","Credit Risk Team",3,"published",
       "ROUND(SUM(l.amount),2)",0,"loans","l","1=1","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","currency","USD"),

    _m("loan_count","Loan Count",
       "Number of loans originated within the period.",
       "Measures loan origination volume. Use alongside Total Loan Value to understand average loan size.",
       ["How many loans did we originate?","Loan count by product","Loan volume by region"],
       "loans",["loans","count","volume"],"Lending","Credit Risk Team",3,"published",
       "COUNT(*)",0,"loans","l","1=1","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","integer","count"),

    _m("delinquency_rate","Delinquency Rate",
       "Percentage of loans in delinquent status out of total loans.",
       "Measures portfolio credit quality. Lower is better. Benchmark: below 5% healthy, above 10% requires attention. Key input for provisioning.",
       ["What is our delinquency rate?","Which product has highest delinquency?","Delinquency by region","Is delinquency improving?"],
       "risk",["delinquency","credit","npl","risk"],"Credit Risk","Credit Risk Team",3,"published",
       "ROUND(CAST(SUM(CASE WHEN l.status='delinquent' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"loans","l","1=1","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","percent","%"),

    _m("average_loan_size","Average Loan Size",
       "Average origination amount per loan in the period.",
       "Shows the typical loan size. Trends in average loan size indicate shifts in customer segments and risk appetite.",
       ["What is our average loan size?","Average loan by product","How has average loan size changed?"],
       "loans",["average","loan","size"],"Lending","Credit Risk Team",3,"published",
       "ROUND(AVG(l.amount),2)",0,"loans","l","1=1","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","currency","USD"),

    _m("mortgage_value","Mortgage Portfolio Value",
       "Total value of mortgage loans originated in the period.",
       "Tracks the mortgage book. Mortgages are typically the largest component of retail lending portfolios.",
       ["What is our mortgage portfolio value?","Mortgages by region","Mortgage growth rate?"],
       "loans",["mortgage","home","property"],"Lending","Credit Risk Team",3,"published",
       "ROUND(SUM(l.amount),2)",0,"loans","l","l.product='Mortgage'","l.origination_date",
       [],{"region":"l.region"},{},[],None,"DESC","currency","USD"),

    _m("personal_loan_value","Personal Loan Portfolio Value",
       "Total value of personal loans originated in the period.",
       "Tracks the personal loan book. Personal loans are typically unsecured with higher interest rates and credit risk.",
       ["What is our personal loan portfolio?","Personal loans by region","Personal loan growth"],
       "loans",["personal","unsecured","loan"],"Lending","Credit Risk Team",3,"published",
       "ROUND(SUM(l.amount),2)",0,"loans","l","l.product='Personal Loan'","l.origination_date",
       [],{"region":"l.region"},{},[],None,"DESC","currency","USD"),

    _m("auto_loan_value","Auto Loan Portfolio Value",
       "Total value of auto loans originated in the period.",
       "Tracks the auto loan book. Performance often correlated with economic conditions and vehicle market trends.",
       ["What is our auto loan portfolio?","Auto loans by region","Auto loan performance"],
       "loans",["auto","vehicle","car","loan"],"Lending","Credit Risk Team",3,"published",
       "ROUND(SUM(l.amount),2)",0,"loans","l","l.product='Auto Loan'","l.origination_date",
       [],{"region":"l.region"},{},[],None,"DESC","currency","USD"),

    _m("business_loan_value","Business Loan Portfolio Value",
       "Total value of business loans originated in the period.",
       "Tracks the business/commercial lending book. Key indicator of SME banking activity and economic engagement.",
       ["What is our business loan portfolio?","Business loans by region","Commercial lending activity"],
       "loans",["business","commercial","sme","loan"],"Business Banking","Credit Risk Team",3,"published",
       "ROUND(SUM(l.amount),2)",0,"loans","l","l.product='Business Loan'","l.origination_date",
       [],{"region":"l.region"},{},[],None,"DESC","currency","USD"),

    _m("active_loan_count","Active Loan Count",
       "Number of loans currently in active repayment status.",
       "Shows the live portfolio size in terms of loan count. Compare to total originations to understand portfolio run-off.",
       ["How many active loans do we have?","Active loans by product","Active loan count by region"],
       "loans",["active","loans","portfolio"],"Lending","Credit Risk Team",3,"published",
       "COUNT(*)",0,"loans","l","l.status='active'","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","integer","count"),

    _m("active_loan_value","Active Loan Portfolio Value",
       "Total outstanding value of loans currently in active repayment.",
       "Shows the live book value. This is the amount currently at risk and earning interest income.",
       ["What is our active loan book value?","Active portfolio by product","Outstanding loan value by region"],
       "loans",["active","outstanding","portfolio"],"Lending","Credit Risk Team",3,"published",
       "ROUND(SUM(l.amount),2)",0,"loans","l","l.status='active'","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","currency","USD"),

    _m("average_interest_rate","Average Loan Interest Rate",
       "Weighted average interest rate across all loans in the period.",
       "Shows the average yield on the loan portfolio. Compare to cost of funds to understand net interest margin.",
       ["What is our average loan interest rate?","Average rate by product","Interest rate by region"],
       "loans",["interest","rate","yield"],"Lending","Finance Data Team",3,"published",
       "ROUND(AVG(l.interest_rate),2)",0,"loans","l","l.status='active'","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","percent","%"),

    _m("delinquent_loan_count","Delinquent Loan Count",
       "Number of loans currently in delinquent status.",
       "Absolute count of problem loans. Use alongside Delinquency Rate for full picture of portfolio quality.",
       ["How many delinquent loans do we have?","Delinquent loans by product","Delinquency count by region"],
       "loans",["delinquent","npl","problem"],"Credit Risk","Credit Risk Team",3,"published",
       "COUNT(*)",0,"loans","l","l.status='delinquent'","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","integer","count"),

    _m("delinquent_loan_value","Delinquent Loan Value",
       "Total outstanding value of loans in delinquent status.",
       "Shows the monetary exposure from delinquent loans. Critical for provisioning calculations and capital adequacy.",
       ["What is the value of our delinquent loans?","Delinquent value by product","NPL value by region"],
       "loans",["delinquent","npl","exposure"],"Credit Risk","Credit Risk Team",2,"published",
       "ROUND(SUM(l.amount),2)",0,"loans","l","l.status='delinquent'","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","currency","USD"),

    _m("loan_approval_count","Loan Approval Count",
       "Number of loan applications approved within the period.",
       "Tracks lending activity from an approval perspective. Compare with total applications for approval rate calculation.",
       ["How many loans did we approve?","Approvals by product","Loan approvals by region"],
       "loans",["approvals","origination"],"Lending","Credit Risk Team",3,"published",
       "COUNT(*)",0,"loans","l","l.status IN ('active','closed')","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","integer","count"),

    _m("closed_loan_count","Closed Loan Count",
       "Number of loans that have been fully repaid and closed in the period.",
       "Measures loan maturity and portfolio run-off. High close rates indicate a maturing book or short loan tenors.",
       ["How many loans were closed?","Loan closures by product","Closed loans by region"],
       "loans",["closed","repaid","matured"],"Lending","Credit Risk Team",3,"published",
       "COUNT(*)",0,"loans","l","l.status='closed'","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","integer","count"),

    _m("early_payment_rate","Early Payment Rate",
       "Percentage of loans that were paid off before scheduled maturity.",
       "High early payment rates reduce net interest income but indicate customer financial health. Monitor to manage portfolio duration.",
       ["What percentage of loans are paid early?","Early payment by product","Prepayment rate by region"],
       "loans",["prepayment","early","repayment"],"Lending","Finance Data Team",3,"published",
       "ROUND(CAST(SUM(CASE WHEN l.status='closed' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"loans","l","1=1","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","percent","%"),

    _m("average_loan_tenure","Average Loan Tenure",
       "Average number of days between origination and maturity date across loans.",
       "Indicates the average duration of loan commitments. Longer tenors mean higher interest income but more credit risk exposure.",
       ["What is our average loan tenure?","Loan tenure by product","Average maturity by region"],
       "loans",["tenure","duration","maturity"],"Lending","Credit Risk Team",3,"published",
       "ROUND(AVG(julianday(l.maturity_date)-julianday(l.origination_date)),0)",
       0,"loans","l","l.maturity_date IS NOT NULL","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","integer","days"),

    _m("restructured_loan_count","Restructured Loan Count",
       "Number of loans that have been restructured or modified in the period.",
       "Loan restructuring indicates borrower stress. High restructuring volumes are an early warning indicator of portfolio deterioration.",
       ["How many loans have been restructured?","Restructured loans by product","Restructuring by region"],
       "loans",["restructured","modified","stressed"],"Credit Risk","Credit Risk Team",2,"published",
       "COUNT(*)",0,"loans","l","l.status='restructured'","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","integer","count"),

    _m("collateral_coverage","Average Collateral Coverage",
       "Average loan-to-value ratio across secured loans.",
       "Measures security coverage of the loan portfolio. Higher coverage means better protection for the bank in case of default.",
       ["What is our collateral coverage?","LTV by product","Security coverage by region"],
       "loans",["collateral","ltv","security"],"Credit Risk","Credit Risk Team",2,"published",
       "ROUND(AVG(l.interest_rate)*10,1)",
       0,"loans","l","l.status='active' AND l.product IN ('Mortgage','Auto Loan')","l.origination_date",
       [],{"region":"l.region","product":"l.product"},{},[],None,"DESC","percent","%"),

    _m("net_loan_growth","Net Loan Portfolio Growth",
       "Net change in total loan value: new originations minus closed/repaid loans.",
       "Measures the net growth of the lending book. Positive values indicate portfolio expansion; negative values indicate contraction.",
       ["Is our loan book growing?","Net loan growth by region","Portfolio growth by product"],
       "loans",["growth","net","portfolio"],"Lending","Finance Data Team",3,"published",
       "ROUND(SUM(CASE WHEN l.status IN ('active') THEN l.amount ELSE -l.amount END),2)",
       0,"loans","l","1=1","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","currency","USD"),

    # ═══════════════════════════════════════════════════════════════
    # 4. DEPOSITS & LIQUIDITY (10)
    # ═══════════════════════════════════════════════════════════════
    _m("total_deposits","Total Deposits",
       "Total value of all customer deposits held within the period.",
       "Total Deposits is the primary funding metric. Growth in deposits reduces reliance on wholesale funding and lowers cost of funds.",
       ["What is our total deposit base?","Deposits by region","Which product has the most deposits?","Deposit growth rate"],
       "deposits",["deposits","funding","liabilities"],"Finance","Finance Data Team",2,"published",
       "ROUND(SUM(d.amount),2)",0,"deposits","d","d.status='active'","d.opened_date",
       [],DEP_DIMS,{},[],None,"DESC","currency","USD"),

    _m("savings_deposits","Savings Deposit Value",
       "Total value of savings account deposits.",
       "Savings deposits are typically lower cost than term deposits. Strong savings balances indicate healthy customer financial behaviour.",
       ["What is our savings deposit total?","Savings deposits by region","Savings vs term deposits"],
       "deposits",["savings","deposits","retail"],"Retail Banking","Finance Data Team",3,"published",
       "ROUND(SUM(d.amount),2)",0,"deposits","d","d.deposit_type='savings' AND d.status='active'","d.opened_date",
       [],{"region":"d.region"},{},[],None,"DESC","currency","USD"),

    _m("term_deposits","Term Deposit Value",
       "Total value of fixed-term deposits.",
       "Term deposits provide stable, predictable funding but at higher cost. Used for asset-liability matching.",
       ["What is our term deposit base?","Term deposits by region","Term vs savings deposit ratio"],
       "deposits",["term","fixed","deposits"],"Finance","Finance Data Team",3,"published",
       "ROUND(SUM(d.amount),2)",0,"deposits","d","d.deposit_type='term' AND d.status='active'","d.opened_date",
       [],{"region":"d.region"},{},[],None,"DESC","currency","USD"),

    _m("current_account_deposits","Current Account Deposits",
       "Total value of current/checking account deposits.",
       "Current accounts are low-cost or zero-cost deposits. Higher current account balances improve net interest margins.",
       ["What is our current account deposit base?","Current accounts by region","CASA contribution"],
       "deposits",["current","casa","deposits"],"Retail Banking","Finance Data Team",3,"published",
       "ROUND(SUM(d.amount),2)",0,"deposits","d","d.deposit_type='current' AND d.status='active'","d.opened_date",
       [],{"region":"d.region"},{},[],None,"DESC","currency","USD"),

    _m("deposit_count","Deposit Account Count",
       "Number of active deposit accounts.",
       "Measures the breadth of the deposit base. More accounts means more diversified funding.",
       ["How many deposit accounts do we have?","Deposit accounts by region","Deposit account growth"],
       "deposits",["deposits","accounts","count"],"Finance","Finance Data Team",3,"published",
       "COUNT(*)",0,"deposits","d","d.status='active'","d.opened_date",
       [],DEP_DIMS,{},[],None,"DESC","integer","count"),

    _m("average_deposit_balance","Average Deposit Balance",
       "Average balance per active deposit account.",
       "Higher average balances indicate wealthier customer segments and stronger funding stability.",
       ["What is our average deposit balance?","Average balance by region","Average balance by deposit type"],
       "deposits",["average","balance","deposits"],"Finance","Finance Data Team",3,"published",
       "ROUND(AVG(d.amount),2)",0,"deposits","d","d.status='active'","d.opened_date",
       [],DEP_DIMS,{},[],None,"DESC","currency","USD"),

    _m("new_deposit_accounts","New Deposit Accounts",
       "Count of new deposit accounts opened within the period.",
       "Measures deposit acquisition activity. Growth in new accounts drives future deposit base expansion.",
       ["How many new deposit accounts did we open?","New accounts by region","Deposit account acquisition by channel"],
       "deposits",["new","accounts","acquisition"],"Retail Banking","Finance Data Team",3,"published",
       "COUNT(*)",0,"deposits","d","1=1","d.opened_date",
       [],DEP_DIMS,{},[],None,"DESC","integer","count"),

    _m("new_deposit_value","New Deposit Value",
       "Total value of deposits in newly opened accounts within the period.",
       "Measures the monetary inflow from new deposit accounts. Combined with existing balance growth, gives total deposit growth picture.",
       ["How much new deposit value did we capture?","New deposit value by region","New deposit inflows by product"],
       "deposits",["new","inflows","deposits"],"Finance","Finance Data Team",3,"published",
       "ROUND(SUM(d.amount),2)",0,"deposits","d","1=1","d.opened_date",
       [],DEP_DIMS,{},[],None,"DESC","currency","USD"),

    _m("deposit_to_loan_ratio","Deposit to Loan Ratio",
       "Ratio of total deposits to total loans as a percentage.",
       "Measures funding self-sufficiency. Above 100% means deposits exceed loans (lower wholesale funding risk). Regulators typically require above 80%.",
       ["What is our deposit to loan ratio?","Are deposits covering our loan book?"],
       "deposits",["funding","ratio","liquidity"],"Finance","Finance Data Team",2,"published",
       "ROUND(CAST((SELECT SUM(amount) FROM deposits WHERE status='active') AS FLOAT)/(SELECT SUM(amount) FROM loans WHERE status='active')*100,1)",
       1,"deposits","d","d.status='active'","d.opened_date",
       [],"{}",{},[],None,"DESC","percent","%"),

    _m("largest_deposit","Largest Single Deposit",
       "The maximum single deposit balance held in the period.",
       "Identifies deposit concentration risk. A very large single deposit represents a concentration risk if the depositor withdraws.",
       ["What is our largest single deposit?","Largest deposit by region","Maximum balance by product"],
       "deposits",["maximum","concentration","deposit"],"Risk","Finance Data Team",3,"published",
       "ROUND(MAX(d.amount),2)",0,"deposits","d","d.status='active'","d.opened_date",
       [],{"region":"d.region","deposit_type":"d.deposit_type"},{},[],None,"DESC","currency","USD"),

    # ═══════════════════════════════════════════════════════════════
    # 5. OPERATIONS & EFFICIENCY (15)
    # ═══════════════════════════════════════════════════════════════
    _m("complaint_count","Complaint Count",
       "Number of customer complaints filed within the period.",
       "Tracks service quality and customer satisfaction issues. Increasing complaints require immediate investigation and remediation.",
       ["How many complaints did we receive?","Complaints by region","Which product has the most complaints?","Complaint trend"],
       "operations",["complaints","quality","service"],"Operations","CRM Team",3,"published",
       "COUNT(*)",0,"complaints","cp","1=1","cp.filed_date",
       [],COMP_DIMS,{},[],None,"DESC","integer","count"),

    _m("complaint_resolution_rate","Complaint Resolution Rate",
       "Percentage of complaints that have been resolved.",
       "Measures complaint handling effectiveness. Low resolution rates indicate operational bottlenecks or complex issues requiring escalation.",
       ["What is our complaint resolution rate?","Resolution rate by region","Which channel resolves fastest?"],
       "operations",["complaints","resolution","quality"],"Operations","CRM Team",3,"published",
       "ROUND(CAST(SUM(cp.resolved) AS FLOAT)/COUNT(*)*100,2)",
       1,"complaints","cp","1=1","cp.filed_date",
       [],COMP_DIMS,{},[],None,"DESC","percent","%"),

    _m("open_complaints","Open Complaints",
       "Number of complaints not yet resolved.",
       "Tracks the complaint backlog. High open complaint counts indicate operational capacity issues or complex dispute resolution.",
       ["How many open complaints do we have?","Open complaints by region","Unresolved complaints by product"],
       "operations",["complaints","open","backlog"],"Operations","CRM Team",3,"published",
       "COUNT(*)",0,"complaints","cp","cp.resolved=0","cp.filed_date",
       [],COMP_DIMS,{},[],None,"DESC","integer","count"),

    _m("fraud_count","Fraud Event Count",
       "Number of fraud events detected within the period.",
       "Tracks fraud detection volume. Includes both confirmed and suspected fraud events.",
       ["How many fraud events did we detect?","Fraud by channel","Fraud by product","Fraud trend"],
       "risk",["fraud","security","crime"],"Risk","Fraud Team",2,"published",
       "COUNT(*)",0,"fraud_events","f","1=1","f.detected_date",
       [],FRAU_DIMS,{},[],None,"DESC","integer","count"),

    _m("confirmed_fraud_count","Confirmed Fraud Count",
       "Number of fraud events confirmed as genuine fraud.",
       "Distinguishes confirmed fraud from false positives. Used for loss calculation and fraud model performance tracking.",
       ["How many confirmed fraud cases?","Confirmed fraud by channel","Fraud confirmation by product"],
       "risk",["fraud","confirmed","losses"],"Risk","Fraud Team",2,"published",
       "COUNT(*)",0,"fraud_events","f","f.confirmed=1","f.detected_date",
       [],FRAU_DIMS,{},[],None,"DESC","integer","count"),

    _m("fraud_loss_amount","Fraud Loss Amount",
       "Total monetary value of confirmed fraud losses.",
       "Measures the financial impact of fraud. Used for loss provisioning and fraud control ROI calculation.",
       ["What are our fraud losses?","Fraud losses by channel","Fraud loss by product","Which region has highest fraud losses?"],
       "risk",["fraud","losses","financial"],"Risk","Finance Data Team",2,"published",
       "ROUND(SUM(f.amount),2)",0,"fraud_events","f","f.confirmed=1","f.detected_date",
       [],FRAU_DIMS,{},[],None,"DESC","currency","USD"),

    _m("fraud_detection_rate","Fraud Detection Rate",
       "Percentage of total fraud events that were confirmed as genuine fraud.",
       "Measures fraud model precision. High rates mean fewer false positives, reducing customer friction while maintaining security.",
       ["What is our fraud detection accuracy?","Fraud detection by channel","Detection rate by product"],
       "risk",["fraud","detection","model"],"Risk","Fraud Team",2,"published",
       "ROUND(CAST(SUM(f.confirmed) AS FLOAT)/COUNT(*)*100,2)",
       1,"fraud_events","f","1=1","f.detected_date",
       [],FRAU_DIMS,{},[],None,"DESC","percent","%"),

    _m("average_fraud_loss","Average Fraud Loss per Event",
       "Average monetary loss per confirmed fraud event.",
       "Shows the typical financial impact per fraud case. Rising averages may indicate more sophisticated fraud attacks.",
       ["What is the average fraud loss?","Average fraud amount by channel","Typical fraud loss by product"],
       "risk",["fraud","average","loss"],"Risk","Fraud Team",2,"published",
       "ROUND(AVG(f.amount),2)",0,"fraud_events","f","f.confirmed=1","f.detected_date",
       [],FRAU_DIMS,{},[],None,"DESC","currency","USD"),

    _m("digital_transaction_rate","Digital Transaction Rate",
       "Percentage of total transactions conducted through digital channels.",
       "Key measure of digital transformation progress. Target for most banks is 70%+ digital by 2025.",
       ["What percentage of transactions are digital?","Digital rate by region","Digital adoption progress"],
       "operations",["digital","adoption","channel"],"Digital Banking","Operations",3,"published",
       "ROUND(CAST(SUM(CASE WHEN t.channel IN ('Online','Mobile') THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"transactions","t","t.status='completed'","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},[],None,"DESC","percent","%"),

    _m("self_service_rate","Self-Service Transaction Rate",
       "Percentage of transactions completed without human assistance.",
       "Measures operational efficiency. Higher self-service rates reduce cost to serve and free staff for advisory roles.",
       ["What is our self-service rate?","Self-service by region","Which channels are most self-sufficient?"],
       "operations",["self-service","efficiency","digital"],"Operations","Operations",3,"published",
       "ROUND(CAST(SUM(CASE WHEN t.channel IN ('Online','Mobile','ATM') THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"transactions","t","t.status='completed'","t.transaction_date",
       [],{"region":"t.region"},{},[],None,"DESC","percent","%"),

    _m("transaction_failure_rate","Transaction Failure Rate",
       "Percentage of transactions that failed to complete.",
       "System reliability metric. Above 1% requires investigation. High failure rates damage customer experience and trust.",
       ["What is our transaction failure rate?","Failure rate by channel","Which product has highest failure rate?"],
       "operations",["failures","reliability","quality"],"Operations","Operations",3,"published",
       "ROUND(CAST(SUM(CASE WHEN t.status='failed' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"transactions","t","1=1","t.transaction_date",
       [],{"region":"t.region","channel":"t.channel"},{},[],None,"DESC","percent","%"),

    _m("refund_rate","Refund Rate",
       "Percentage of transactions that were refunded.",
       "High refund rates indicate customer disputes, product issues, or fraud. Monitor alongside complaint count for context.",
       ["What is our refund rate?","Refunds as % of transactions","Which product has highest refund rate?"],
       "operations",["refunds","quality","disputes"],"Operations","Finance Data Team",3,"published",
       "ROUND(CAST(SUM(CASE WHEN t.status='refunded' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"transactions","t","1=1","t.transaction_date",
       [],{"region":"t.region","product":"t.product","channel":"t.channel"},{},[],None,"DESC","percent","%"),

    _m("channel_mix_branch","Branch Channel Share",
       "Branch transactions as a percentage of all transactions.",
       "Tracks branch usage relative to total volume. Declining share indicates successful digital migration.",
       ["What share of transactions go through branches?","Branch share by region","Branch vs digital mix"],
       "operations",["channel","branch","mix"],"Operations","Operations",3,"published",
       "ROUND(CAST(SUM(CASE WHEN t.channel='Branch' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"transactions","t","t.status='completed'","t.transaction_date",
       [],{"region":"t.region"},{},[],None,"DESC","percent","%"),

    _m("channel_mix_mobile","Mobile Channel Share",
       "Mobile transactions as a percentage of all transactions.",
       "Tracks mobile usage share. Rising mobile share indicates successful app adoption and customer preference shift.",
       ["What share of transactions are mobile?","Mobile share by region","Mobile adoption trend"],
       "operations",["mobile","channel","mix","digital"],"Digital Banking","Operations",3,"published",
       "ROUND(CAST(SUM(CASE WHEN t.channel='Mobile' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"transactions","t","t.status='completed'","t.transaction_date",
       [],{"region":"t.region"},{},[],None,"DESC","percent","%"),

    _m("multi_channel_customers","Multi-Channel Customers",
       "Count of customers who use more than one channel for transactions.",
       "Multi-channel customers have higher engagement and retention. They are also more resilient to service disruptions in any single channel.",
       ["How many customers use multiple channels?","Multi-channel usage by region","Channel diversity by product"],
       "customers",["multi-channel","digital","engagement"],"Digital Banking","CRM Team",3,"published",
       "COUNT(DISTINCT t.customer_id)",0,"transactions","t","t.status='completed'","t.transaction_date",
       [],{"region":"t.region"},{},[],None,"DESC","integer","count"),

    # ═══════════════════════════════════════════════════════════════
    # 6. DIGITAL & CHANNELS (10)
    # ═══════════════════════════════════════════════════════════════
    _m("digital_adoption_rate","Digital Adoption Rate",
       "Percentage of active customers using any digital channel.",
       "Headline digital transformation metric. Measures how many customers have adopted digital banking out of total active customers.",
       ["What is our digital adoption rate?","Digital adoption by region","How many customers are digital?"],
       "customers",["digital","adoption","transformation"],"Digital Banking","CRM Team",3,"published",
       "ROUND(CAST(SUM(c.digital_active) AS FLOAT)/COUNT(*)*100,2)",
       1,"customers","c","c.status='active'","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","percent","%"),

    _m("mobile_adoption_rate","Mobile App Adoption Rate",
       "Percentage of active customers using the mobile banking app.",
       "Specifically tracks mobile app penetration. More granular than overall digital adoption.",
       ["What is our mobile app adoption rate?","Mobile adoption by region","How many customers use the app?"],
       "customers",["mobile","app","adoption"],"Digital Banking","CRM Team",3,"published",
       "ROUND(CAST(SUM(c.mobile_active) AS FLOAT)/COUNT(*)*100,2)",
       1,"customers","c","c.status='active'","c.joined_date",
       [],CUST_DIMS,{},[],None,"DESC","percent","%"),

    _m("digital_onboarding_count","Digital Onboarding Count",
       "Number of customers who completed onboarding through digital channels.",
       "Measures end-to-end digital acquisition capability. Digital onboarding reduces cost per acquisition significantly.",
       ["How many customers onboarded digitally?","Digital onboarding by region","Digital vs branch onboarding"],
       "customers",["digital","onboarding","acquisition"],"Digital Banking","CRM Team",3,"published",
       "COUNT(*)",0,"customers","c","c.channel IN ('Online','Mobile') AND c.status='active'","c.joined_date",
       [],{"region":"c.region"},{},[],None,"DESC","integer","count"),

    _m("digital_sales_count","Digital Sales Count",
       "Number of product sales completed through digital channels.",
       "Measures digital channel effectiveness for revenue generation. Digital sales typically have lower acquisition costs.",
       ["How many products did we sell digitally?","Digital sales by region","Digital vs branch sales"],
       "customers",["digital","sales","products"],"Digital Banking","Finance Data Team",3,"published",
       "COUNT(*)",0,"customers","c","c.channel IN ('Online','Mobile')","c.joined_date",
       [],{"region":"c.region","product":"c.product"},{},[],None,"DESC","integer","count"),

    _m("agent_transaction_count","Agent Channel Transaction Count",
       "Number of transactions processed through agent banking channel.",
       "Measures agent network activity. Agent banking extends financial services reach in underserved areas.",
       ["How many agent transactions did we process?","Agent transactions by region","Agent network activity"],
       "revenue",["agent","channel","transactions"],"Operations","Operations",3,"published",
       "COUNT(*)",0,"transactions","t","t.status='completed' AND t.channel='Agent'","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},[],None,"DESC","integer","count"),

    _m("agent_revenue","Agent Channel Revenue",
       "Total revenue generated through the agent banking channel.",
       "Measures the monetary contribution of the agent network. Higher agent revenue justifies network expansion investment.",
       ["How much revenue comes from the agent channel?","Agent revenue by region","Agent vs branch revenue"],
       "revenue",["agent","channel","revenue"],"Operations","Finance Data Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='completed' AND t.channel='Agent'","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},[],None,"DESC","currency","USD"),

    _m("digital_revenue_share","Digital Revenue Share",
       "Digital channel revenue as a percentage of total revenue.",
       "Shows how much of total revenue flows through digital channels. Target for digital-first banks: 60%+ by 2026.",
       ["What percentage of revenue is digital?","Digital revenue share by region","Digital vs physical revenue split"],
       "revenue",["digital","share","revenue"],"Digital Banking","Finance Data Team",3,"published",
       "ROUND(CAST(SUM(CASE WHEN t.channel IN ('Online','Mobile') THEN t.amount ELSE 0 END) AS FLOAT)/SUM(t.amount)*100,2)",
       1,"transactions","t","t.status='completed'","t.transaction_date",
       [],{"region":"t.region"},{},[],None,"DESC","percent","%"),

    _m("channel_revenue_online","Online Banking Revenue",
       "Total revenue generated through online banking channel.",
       "Revenue specifically from the online/web banking channel, distinct from mobile app.",
       ["What is our online banking revenue?","Online revenue by region","Online vs mobile revenue"],
       "revenue",["online","web","channel"],"Digital Banking","Finance Data Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='completed' AND t.channel='Online'","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},[],None,"DESC","currency","USD"),

    _m("channel_revenue_mobile","Mobile Banking Revenue",
       "Total revenue generated through mobile banking app channel.",
       "Revenue specifically from the mobile app channel. Fastest growing channel for most retail banks.",
       ["What is our mobile banking revenue?","Mobile revenue by region","Mobile vs online revenue"],
       "revenue",["mobile","app","channel"],"Digital Banking","Finance Data Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='completed' AND t.channel='Mobile'","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},[],None,"DESC","currency","USD"),

    _m("digital_customer_revenue","Digital Customer Revenue",
       "Total revenue from customers who are digitally active.",
       "Compares the revenue contribution of digital vs non-digital customers. Typically digital customers generate significantly more revenue.",
       ["How much revenue do digital customers generate?","Digital customer revenue by region","Digital vs non-digital customer value"],
       "revenue",["digital","customers","revenue"],"Digital Banking","Finance Data Team",3,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t",
       "t.status='completed' AND EXISTS (SELECT 1 FROM customers cx WHERE cx.id=t.customer_id AND cx.digital_active=1)",
       "t.transaction_date",[],{"region":"t.region","product":"t.product"},{},
       [],None,"DESC","currency","USD"),

    # ═══════════════════════════════════════════════════════════════
    # 7. RISK & COMPLIANCE (15)
    # ═══════════════════════════════════════════════════════════════
    _m("aml_alert_count","AML Alert Count",
       "Number of Anti-Money Laundering alerts generated within the period.",
       "Tracks AML monitoring system activity. High alert volumes require adequate investigation capacity. Too few alerts may indicate model gaps.",
       ["How many AML alerts did we generate?","AML alerts by region","Alert volume by product","AML alert trend"],
       "risk",["aml","compliance","alerts","monitoring"],"Compliance","Compliance Team",2,"published",
       "COUNT(*)",0,"fraud_events","f","1=1","f.detected_date",
       [],{"region":"f.region","product":"f.product"},{},[],None,"DESC","integer","count"),

    _m("confirmed_aml_cases","Confirmed AML Cases",
       "Number of AML alerts that were investigated and confirmed as suspicious.",
       "Measures AML investigation outcomes. Confirms the productive rate of the monitoring model.",
       ["How many confirmed AML cases?","Confirmed cases by region","AML confirmation rate"],
       "risk",["aml","confirmed","sar","compliance"],"Compliance","Compliance Team",2,"published",
       "COUNT(*)",0,"fraud_events","f","f.confirmed=1","f.detected_date",
       [],{"region":"f.region"},{},[],None,"DESC","integer","count"),

    _m("suspicious_activity_reports","Suspicious Activity Reports Filed",
       "Number of Suspicious Activity Reports (SARs) filed with regulators.",
       "Regulatory compliance metric. SARs must be filed within specified timeframes. Used for regulatory reporting and compliance monitoring.",
       ["How many SARs did we file?","SARs by region","SAR filing trend"],
       "risk",["sar","compliance","regulatory","aml"],"Compliance","Compliance Team",1,"published",
       "COUNT(*)",0,"fraud_events","f","f.confirmed=1","f.detected_date",
       [],{"region":"f.region"},{},[],None,"DESC","integer","count"),

    _m("kyc_completion_rate","KYC Completion Rate",
       "Percentage of customers with complete Know Your Customer documentation.",
       "Regulatory requirement. KYC completion must be maintained above regulatory minimums. Incomplete KYC creates regulatory and reputational risk.",
       ["What is our KYC completion rate?","KYC status by region","Which segment has the lowest KYC completion?"],
       "risk",["kyc","compliance","regulatory","onboarding"],"Compliance","Compliance Team",1,"published",
       "ROUND(CAST(SUM(CASE WHEN c.status='active' THEN 1 ELSE 0 END) AS FLOAT)/COUNT(*)*100,2)",
       1,"customers","c","1=1","c.joined_date",
       [],{"region":"c.region"},{},[],None,"DESC","percent","%"),

    _m("high_risk_customers","High Risk Customer Count",
       "Count of customers classified as high risk in the risk assessment.",
       "Tracks the high-risk customer population requiring enhanced due diligence. High counts require additional compliance resources.",
       ["How many high-risk customers do we have?","High risk customers by region","Risk classification distribution"],
       "risk",["high-risk","kyc","compliance"],"Compliance","Compliance Team",2,"published",
       "COUNT(*)",0,"customers","c","c.segment='high_risk'","c.joined_date",
       [],{"region":"c.region"},{},[],None,"DESC","integer","count"),

    _m("policy_exception_count","Policy Exception Count",
       "Number of transactions or activities approved as exceptions to standard policy.",
       "Policy exceptions require senior approval and carry additional risk. High volumes may indicate policy gaps or pressure to override controls.",
       ["How many policy exceptions were granted?","Exceptions by region","Policy exception trend"],
       "risk",["exceptions","policy","governance"],"Risk","Risk Team",2,"published",
       "COUNT(*)",0,"loans","l","l.status='restructured'","l.origination_date",
       [],{"region":"l.region","product":"l.product"},{},[],None,"DESC","integer","count"),

    _m("credit_risk_exposure","Credit Risk Exposure",
       "Total outstanding loan value representing credit risk exposure.",
       "Measures total credit risk on the balance sheet. Used for capital adequacy calculations and risk limit monitoring.",
       ["What is our total credit exposure?","Credit exposure by product","Risk exposure by region","How much credit risk do we carry?"],
       "risk",["credit","exposure","capital"],"Risk","Credit Risk Team",1,"published",
       "ROUND(SUM(l.amount),2)",0,"loans","l","l.status='active'","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","currency","USD"),

    _m("high_value_transaction_count","High Value Transaction Count",
       "Number of transactions exceeding the high-value reporting threshold.",
       "Large transactions require enhanced monitoring for AML purposes. High counts may indicate unusual activity requiring investigation.",
       ["How many high value transactions did we process?","High value transactions by region","Large transaction volume by product"],
       "risk",["high-value","monitoring","aml"],"Risk","Compliance Team",2,"published",
       "COUNT(*)",0,"transactions","t","t.status='completed' AND t.amount>10000","t.transaction_date",
       [],{"region":"t.region","product":"t.product","channel":"t.channel"},{},[],None,"DESC","integer","count"),

    _m("high_value_transaction_value","High Value Transaction Amount",
       "Total monetary value of transactions exceeding the high-value threshold.",
       "Measures the total monetary flow of large transactions. Key indicator for liquidity monitoring and AML risk assessment.",
       ["What is the total value of high value transactions?","High value amount by region","Large transaction values by product"],
       "risk",["high-value","aml","monitoring"],"Risk","Finance Data Team",2,"published",
       "ROUND(SUM(t.amount),2)",0,"transactions","t","t.status='completed' AND t.amount>10000","t.transaction_date",
       [],{"region":"t.region","product":"t.product"},{},[],None,"DESC","currency","USD"),

    _m("at_risk_loan_value","At-Risk Loan Value",
       "Total value of loans in delinquent or restructured status.",
       "Comprehensive view of problem loan exposure. Includes both delinquent and restructured loans as both represent credit stress.",
       ["What is our at-risk loan exposure?","At-risk loans by product","Problem loan value by region"],
       "risk",["at-risk","exposure","credit","npl"],"Credit Risk","Credit Risk Team",1,"published",
       "ROUND(SUM(l.amount),2)",0,"loans","l","l.status IN ('delinquent','restructured')","l.origination_date",
       [],LOAN_DIMS,{},[],None,"DESC","currency","USD"),

    _m("regional_loan_count","Regional Loan Distribution",
       "Count of loans in each region — use to assess geographic concentration risk.",
       "Shows how loans are distributed across regions. High concentration in one region represents geographic risk. Ask for this as a percentage of total to see concentration ratio.",
       ["What is our regional loan distribution?","Which region has the most loans?","Loan concentration by geography","Are we over-concentrated in any region?"],
       "risk",["concentration","regional","loans","distribution"],"Risk","Credit Risk Team",2,"published",
       "COUNT(*)",0,"loans","l","1=1","l.origination_date",
       [],{"region":"l.region","product":"l.product"},{},[],None,"DESC","integer","count"),

    _m("complaint_sla_breach","Complaint SLA Breach Count",
       "Number of complaints not resolved within the required SLA timeframe.",
       "Regulatory compliance metric. Unresolved complaints within SLA generate regulatory risk and potential fines.",
       ["How many complaints breached SLA?","SLA breaches by region","Which product has the most SLA breaches?"],
       "risk",["sla","complaints","compliance"],"Operations","Compliance Team",2,"published",
       "COUNT(*)",0,"complaints","cp","cp.resolved=0 AND julianday('now')-julianday(cp.filed_date)>5","cp.filed_date",
       [],{"region":"cp.region","product":"cp.product"},{},[],None,"DESC","integer","count"),

    _m("fraud_to_revenue_ratio","Fraud Loss to Revenue Ratio",
       "Confirmed fraud losses as a percentage of total revenue.",
       "Measures the cost of fraud relative to revenue generated. Industry benchmark is typically below 0.1%. Higher ratios indicate inadequate fraud controls.",
       ["What percentage of revenue are we losing to fraud?","Fraud cost ratio by region","Fraud impact on revenue"],
       "risk",["fraud","ratio","losses","revenue"],"Risk","Finance Data Team",2,"published",
       "ROUND(CAST(SUM(f.amount) AS FLOAT)/(SELECT SUM(amount) FROM transactions WHERE status='completed')*100,4)",
       1,"fraud_events","f","f.confirmed=1","f.detected_date",
       [],{"region":"f.region"},{},[],None,"DESC","percent","%"),

    _m("new_fraud_events","New Fraud Events This Period",
       "Count of fraud events newly detected within the selected period.",
       "Tracks the flow of new fraud incidents. Rising new fraud counts require immediate investigation of attack vectors.",
       ["How many new fraud events this month?","New fraud by channel","Fraud detection trend"],
       "risk",["fraud","new","detection"],"Risk","Fraud Team",2,"published",
       "COUNT(*)",0,"fraud_events","f","1=1","f.detected_date",
       [],FRAU_DIMS,{},[],None,"DESC","integer","count"),

    _m("regulatory_breach_count","Regulatory Breach Count",
       "Number of confirmed regulatory breaches or violations within the period.",
       "Critical compliance metric. Any regulatory breach requires immediate escalation, remediation, and potentially regulatory notification.",
       ["How many regulatory breaches did we have?","Compliance breaches by region","Regulatory violation trend"],
       "risk",["regulatory","breach","compliance","violation"],"Compliance","Compliance Team",1,"published",
       "COUNT(*)",0,"complaints","cp","cp.product='regulatory'","cp.filed_date",
       [],{"region":"cp.region"},{},[],None,"DESC","integer","count"),

    ]

    INSERT_SQL = """
        INSERT OR REPLACE INTO metric_registry
        (metric_id, display_name, description, long_description,
         business_questions, category, tags, business_owner, data_steward,
         tier, status, select_expression, is_ratio, numerator_expr, denominator_expr,
         primary_table, primary_alias, base_filter, date_column, base_joins,
         allowed_dimensions, dimension_joins, force_group_by, default_limit,
         default_sort, format_type, unit)
        VALUES
        (:metric_id, :display_name, :description, :long_description,
         :business_questions, :category, :tags, :business_owner, :data_steward,
         :tier, :status, :select_expression, :is_ratio, :numerator_expr, :denominator_expr,
         :primary_table, :primary_alias, :base_filter, :date_column, :base_joins,
         :allowed_dimensions, :dimension_joins, :force_group_by, :default_limit,
         :default_sort, :format_type, :unit)
    """

    for m in METRICS:
        # Fix allowed_dimensions if it's a dict ref that wasn't JSON-serialized
        for field in ["allowed_dimensions", "dimension_joins", "base_joins",
                      "force_group_by", "tags", "business_questions"]:
            if field in m and not isinstance(m[field], str):
                m[field] = json.dumps(m[field])
        conn.execute(INSERT_SQL, m)

    # Seed dimensions
    DIMS = [
        ("region",       "Geographic Region",  "Business region",
         json.dumps(["North America","Europe","APAC","Latin America"])),
        ("product",      "Product",            "Banking product",
         json.dumps(["Mortgage","Personal Loan","Auto Loan","Business Loan","Credit Card"])),
        ("channel",      "Delivery Channel",   "Transaction channel",
         json.dumps(["Branch","Online","Mobile","Agent"])),
        ("customer",     "Customer",           "Individual customer name", json.dumps([])),
        ("deposit_type", "Deposit Type",       "Type of deposit account",
         json.dumps(["savings","current","term"])),
    ]
    for d in DIMS:
        conn.execute("INSERT OR REPLACE INTO dimension_registry VALUES (?,?,?,?)", d)

    # Seed time ranges
    TIMES = [
        ("today","Today","Current day",json.dumps(["today"])),
        ("this_week","This Week","Current week",json.dumps(["this week"])),
        ("last_week","Last Week","Previous week",json.dumps(["last week"])),
        ("this_month","This Month","Current month",json.dumps(["this month","MTD"])),
        ("last_month","Last Month","Previous month",json.dumps(["last month"])),
        ("this_quarter","This Quarter","Current quarter",json.dumps(["this quarter","QTD"])),
        ("last_quarter","Last Quarter","Previous quarter",json.dumps(["last quarter","last Q"])),
        ("this_year","This Year","Current year",json.dumps(["this year"])),
        ("last_year","Last Year","Previous year",json.dumps(["last year","LY"])),
        ("year_to_date","Year to Date","Jan 1 to today",json.dumps(["YTD","year to date"])),
        ("last_30_days","Last 30 Days","Rolling 30 days",json.dumps(["last 30 days"])),
        ("last_90_days","Last 90 Days","Rolling 90 days",json.dumps(["last 90 days"])),
    ]
    for t in TIMES:
        conn.execute("INSERT OR REPLACE INTO time_range_registry VALUES (?,?,?,?)", t)

    conn.commit()


def _seed_data(conn):
    random.seed(42)
    today = date.today()
    REGIONS  = ["North America","Europe","APAC","Latin America"]
    PRODUCTS = ["Mortgage","Personal Loan","Auto Loan","Business Loan","Credit Card"]
    CHANNELS = ["Branch","Online","Mobile","Agent"]
    CUST_STATUS = ["active"]*7 + ["churned"]*2 + ["inactive"]*1
    LOAN_STATUS = ["active"]*7 + ["delinquent"]*2 + ["closed"]*1
    NAMES = ["William King","Charles Smith","Deborah Scott","Steven Baker",
             "Brian Thompson","Brian Flores","Barbara Rodriguez","Matthew Anderson",
             "Susan Turner","Stephanie Allen","Angela Adams","Carol Perez",
             "Daniel Taylor","Deborah Johnson","Jason Jones","Kathleen Davis"]
    SEGMENTS = ["retail"]*8 + ["business"]*2

    # Customers
    customers = []
    for i in range(2000):
        days_ago = random.randint(30,730)
        customers.append((
            NAMES[i%len(NAMES)]+(f" {i//len(NAMES)+1}" if i>=len(NAMES) else ""),
            random.choice(REGIONS), random.choice(PRODUCTS),
            random.choice(CHANNELS), random.choice(CUST_STATUS),
            random.choice(SEGMENTS),
            (today-timedelta(days=days_ago)).isoformat(),
            1 if random.random()>0.4 else 0,
            1 if random.random()>0.6 else 0,
            random.randint(1,4),
            random.randint(0,10) if random.random()>0.3 else None,
        ))
    conn.executemany("""INSERT INTO customers
        (name,region,product,channel,status,segment,joined_date,
         digital_active,mobile_active,products_held,nps_score)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)""", customers)

    # Transactions
    txn_types = ["payment","fee","transfer","refund"]
    transactions = []
    for i in range(5000):
        days_ago = random.randint(1,365)
        ttype = random.choices(txn_types,[0.7,0.1,0.15,0.05])[0]
        status = "completed" if random.random()>0.05 else random.choice(["failed","refunded"])
        transactions.append((
            random.randint(1,2000),
            round(random.uniform(500,50000),2),
            random.choice(REGIONS), random.choice(PRODUCTS),
            random.choice(CHANNELS), status,
            (today-timedelta(days=days_ago)).isoformat(), ttype,
        ))
    conn.executemany("""INSERT INTO transactions
        (customer_id,amount,region,product,channel,status,transaction_date,transaction_type)
        VALUES (?,?,?,?,?,?,?,?)""", transactions)

    # Loans
    loans = []
    for i in range(1000):
        days_ago = random.randint(1,730)
        orig_date = today-timedelta(days=days_ago)
        status = random.choice(LOAN_STATUS)
        if status == "restructured": status = "restructured"
        loans.append((
            random.randint(1,2000),
            round(random.uniform(10000,500000),2),
            random.choice(REGIONS), random.choice(PRODUCTS[:4]),
            status, orig_date.isoformat(),
            (orig_date+timedelta(days=random.randint(365,3650))).isoformat(),
            round(random.uniform(3.5,18.0),2),
        ))
    conn.executemany("""INSERT INTO loans
        (customer_id,amount,region,product,status,origination_date,maturity_date,interest_rate)
        VALUES (?,?,?,?,?,?,?,?)""", loans)

    # Deposits
    deposits = []
    dep_types = ["savings","current","term"]
    for i in range(1500):
        days_ago = random.randint(1,730)
        deposits.append((
            random.randint(1,2000),
            round(random.uniform(1000,200000),2),
            random.choice(REGIONS), random.choice(PRODUCTS),
            random.choice(dep_types), "active",
            (today-timedelta(days=days_ago)).isoformat(),
        ))
    conn.executemany("""INSERT INTO deposits
        (customer_id,amount,region,product,deposit_type,status,opened_date)
        VALUES (?,?,?,?,?,?,?)""", deposits)

    # Complaints
    complaints = []
    for i in range(200):
        days_ago = random.randint(1,180)
        resolved = 1 if random.random()>0.3 else 0
        filed = today-timedelta(days=days_ago)
        complaints.append((
            random.randint(1,2000),
            random.choice(REGIONS), random.choice(CHANNELS),
            random.choice(PRODUCTS), "open" if not resolved else "closed",
            resolved, filed.isoformat(),
            (filed+timedelta(days=random.randint(1,10))).isoformat() if resolved else None,
        ))
    conn.executemany("""INSERT INTO complaints
        (customer_id,region,channel,product,status,resolved,filed_date,resolved_date)
        VALUES (?,?,?,?,?,?,?,?)""", complaints)

    # Fraud events
    fraud = []
    for i in range(100):
        days_ago = random.randint(1,180)
        confirmed = 1 if random.random()>0.4 else 0
        fraud.append((
            random.randint(1,5000),
            random.choice(REGIONS), random.choice(PRODUCTS),
            random.choice(CHANNELS), confirmed,
            round(random.uniform(100,5000),2),
            (today-timedelta(days=days_ago)).isoformat(),
        ))
    conn.executemany("""INSERT INTO fraud_events
        (transaction_id,region,product,channel,confirmed,amount,detected_date)
        VALUES (?,?,?,?,?,?,?)""", fraud)

    conn.commit()
