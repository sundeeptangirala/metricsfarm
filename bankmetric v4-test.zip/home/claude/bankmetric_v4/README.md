# BankMetric v4

## What's new in v4
- LLM is the ONLY parser — no rule-based system competing with it
- Clarification questions for ambiguous input (buttons, not errors)
- Conversation turn limit: warning at turn 8, forced reset at turn 12
- Session summary carried to new conversation as context
- "Has anything changed?" works across sessions
- SQL injection protection
- Empty result handling with helpful suggestions

## Setup (one time)
```bash
brew install ollama
ollama pull llama3.2:3b
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Running
Terminal 1:  ollama serve
Terminal 2:  source venv/bin/activate && python main.py
Terminal 3:  source venv/bin/activate && streamlit run streamlit_app/app.py

Open: http://localhost:8501

## Running tests
```bash
source venv/bin/activate
python tests/test_full.py
```
110 offline tests pass without Ollama.
15 LLM tests run automatically when Ollama is running.

## Project structure
```
bankmetric_v4/
├── main.py                    FastAPI entry point
├── requirements.txt
├── db/
│   └── database.py            SQLite seed data
├── parser/
│   ├── llm_parser.py          LLM parser + validation + prompt
│   └── conversation.py        Turn counter + summary generation
├── api/
│   ├── resolver.py            Pure SQL resolver (no strawberry)
│   └── graphql_api.py         GraphQL schema (wraps resolver)
├── streamlit_app/
│   └── app.py                 Chat UI
└── tests/
    └── test_full.py           125 tests
```
